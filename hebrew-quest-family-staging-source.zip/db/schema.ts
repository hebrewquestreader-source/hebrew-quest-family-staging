import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';

// Provider keys are encrypted; vocabulary records are scoped to the signed-in account.
export const languageSettings = sqliteTable('language_settings', {
  id: text('id').primaryKey(),
  encryptedKey: text('encrypted_key').notNull(),
  updatedAt: integer('updated_at').notNull(),
});
export const languageLimits = sqliteTable('language_limits', {
  bucket: text('bucket').primaryKey(),
  hits: integer('hits').notNull(),
  expiresAt: integer('expires_at').notNull(),
});

export const vocabularyEntries = sqliteTable('vocabulary_entries', {
  id: text('id').primaryKey(), owner: text('owner').notNull(),
  expression: text('expression').notNull(), nikud: text('nikud').notNull(),
  translation: text('translation').notNull(), lemma: text('lemma').notNull(),
  lemmaTranslation: text('lemma_translation').notNull(), incomplete: integer('incomplete').notNull().default(0), status: text('status').notNull(),
  createdAt: text('created_at').notNull(), updatedAt: text('updated_at').notNull(),
});
export const vocabularyExamples = sqliteTable('vocabulary_examples', {
  id: text('id').primaryKey(), entryId: text('entry_id').notNull(), owner: text('owner').notNull(),
  expression: text('expression').notNull(), nikud: text('nikud').notNull(), translation: text('translation').notNull(),
  sentence: text('sentence').notNull(), sourceType:text('source_type').notNull().default('article'), title: text('title').notNull(), url: text('url').notNull(), savedAt: text('saved_at').notNull(),
});

export const languageReports = sqliteTable('language_reports', {
 id:text('id').primaryKey(),owner:text('owner').notNull(),selected:text('selected').notNull(),sentence:text('sentence').notNull(),title:text('title').notNull(),url:text('url').notNull(),kind:text('kind').notNull(),note:text('note').notNull(),resultJson:text('result_json').notNull(),savedAt:text('saved_at').notNull(),
});

export const readingSessions=sqliteTable('reading_sessions',{
 id:text('id').primaryKey(),owner:text('owner').notNull(),articleKey:text('article_key').notNull(),title:text('title').notNull(),url:text('url').notNull(),articleJson:text('article_json').notNull(),stateJson:text('state_json').notNull(),revision:integer('revision').notNull().default(0),busyUntil:integer('busy_until').notNull().default(0),updatedAt:text('updated_at').notNull(),
});
export const readingCompletions=sqliteTable('reading_completions',{
 id:text('id').primaryKey(),owner:text('owner').notNull(),articleKey:text('article_key').notNull(),title:text('title').notNull(),url:text('url').notNull(),completedAt:text('completed_at').notNull(),difficulty:text('difficulty').notNull(),coverage:text('coverage').notNull(),
});

export const readerAccounts=sqliteTable('reader_accounts',{
 id:text('id').primaryKey(),email:text('email').notNull(),dataOwner:text('data_owner').notNull().unique(),legacyOwner:integer('legacy_owner').notNull().default(0),preferencesJson:text('preferences_json').notNull().default('{}'),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull(),
});
export const importedArticles=sqliteTable('imported_articles',{
 id:text('id').primaryKey(),owner:text('owner').notNull(),title:text('title').notNull(),url:text('url').notNull(),articleJson:text('article_json').notNull(),importedAt:text('imported_at').notNull(),lastOpenedAt:text('last_opened_at').notNull(),
});
export const vocabularyReviews=sqliteTable('vocabulary_reviews',{
 id:text('id').primaryKey(),owner:text('owner').notNull(),entryId:text('entry_id').notNull(),status:text('status').notNull(),reviewedAt:text('reviewed_at').notNull(),
});
