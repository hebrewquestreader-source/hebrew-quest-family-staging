import fs from 'node:fs';
fs.writeFileSync('public/expression-validator.js',fs.readFileSync('lib/expressions.js','utf8').replace("import {HebrewText} from './hebrew-text.js';\n",'').replace('export const ExpressionText','globalThis.ExpressionText'));
