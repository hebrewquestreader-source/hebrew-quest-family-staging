import fs from 'node:fs';
const source=fs.readFileSync(new URL('../lib/semantic-hints.js',import.meta.url),'utf8').replace("import {HebrewText} from './hebrew-text.js';\n",'').replace('export const SemanticHints','globalThis.SemanticHints');
fs.writeFileSync(new URL('../public/semantic-hints-client.js',import.meta.url),source);
