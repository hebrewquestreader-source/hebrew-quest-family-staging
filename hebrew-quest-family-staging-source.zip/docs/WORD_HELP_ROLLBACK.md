# Word Help stability release rollback

No database migration or user-data rewrite is part of this release.
Existing immutable source commits and deployable Sites archives are retained.

- Preferred-layout reference: version 25, commit `1d75a4711a5a35f194d0277060edd3c7f76c6f11`, saved version `appgprj_6ae384b7c5c881919edf628295267217~appgver_eff1515a0a54819196c1bcffa345d7f9`.
- Exact pre-stabilisation release: version 27, commit `7750c2a4eeebfd03eb3e36011553c3bd5a752da3`, saved version `appgprj_6ae384b7c5c881919edf628295267217~appgver_728f4d3a5de88191afdfeec6ebc729e0`.
- Local rollback branch: `rollback/word-help-v27-before-stabilisation`.

Rollback uses the existing saved version and deployment operation; do not rebuild or reset user data. Preserve audience, identity, provider settings and storage bindings. Version 25 predates later appearance/breakdown preferences; do not migrate or delete those stored fields when comparing/rolling back. Version 27 is the exact deployed baseline, not a claim that its reported Word Help defects were absent.

## Diagnosed defects and evidence

- Screenshots confirm root errors, genuine U+064A rejection, duplicate technical messages, large translation boxes and intrusive controls.
- Original production provider bodies were not retained. Fixtures in `tests/fixtures/word-help-stability.json` are explicitly constructed, not captured personal responses.
- Reproduced: valid root separators rejected; initial-yod Hifil roots withheld; no adverb category; dropped boundary comma rejected; nested breakdown overflow; held-word vertical swipe interception; floating desktop layout; pronunciation output moved out of Word Help; no article-scroll dismissal.
- The exact original cause of the intermittent phrase failure is unknown. Tests exercise malformed, truncated and transient responses with one bounded recovery attempt, never a paid/model fallback.
- Ordinary punctuation can be copied only from the source token when missing. Different punctuation and changed lexical letters remain invalid. Original source text is never replaced.
- Root notation is validated separately from vowelled Hebrew words. Technical diagnostics contain only bounded service/field/code/Unicode metadata and can accompany an explicit report; no provider body, source sentence or key is logged.
- Real-browser/device behaviour requires testing; the browser runtime failed to start during this task.

## Version 29 correction baseline

Version 28 is retained at commit `b7761cf68fd20f36598b13c8d572e22184333c24`, saved version `appgprj_6ae384b7c5c881919edf628295267217~appgver_591dad1f106481919bc0fbecf70ac00f`, local branch `rollback/word-help-v28-before-correction`. No storage migration.

## Version 30 correction baseline

Version 29 remains deployable at saved version `appgprj_6ae384b7c5c881919edf628295267217~appgver_32530c0365d08191a73d6362836c5465`, commit `d8a96a9eb34a1cca31a7f60b577da8fee01bbe57`, local branch `rollback/word-help-v29-before-mixed-text`. No database or user-data migration. Version 30 changes disposable analysis-cache versions only, preserving vocabulary, articles and progress.

## Version 31 reliability/layout baseline

Version 30 remains deployable as saved version `appgprj_6ae384b7c5c881919edf628295267217~appgver_42925369da908191ac4073b3d0387086`, source `9af48833471d623482352324c0800b42c3588654`, local branch `rollback/v30-before-request-layout`. Version 31 does not migrate tables or reset counters, vocabulary, history or drafts. Its allowance changes preserve existing bucket names and ceilings while charging each actual provider attempt.

## Version 32 interactive-budget baseline

Version 31 remains deployable as saved version `appgprj_6ae384b7c5c881919edf628295267217~appgver_03d7744b1b1081919b706d0b266f880a`, source `5ee5f8af588e7b2b60d7bdb66e0c9dd6cbf6b8cf`, branch `rollback/v31-before-interactive-priority`. Version 32 does not migrate or delete data, reset counters, change their original ceilings, authentication or model configuration. The reserve is additive preference JSON; old preferences and caches remain valid.
