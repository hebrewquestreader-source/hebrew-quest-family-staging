# Reading/language correction — version 30

Scope: mixed Hebrew/English rendering, language-field isolation and useful-expression recognition. No Discover, authentication changes, database migration, article-import change or reading-progress rewrite.

## Evidence and causes

Inspected the three supplied Samsung screenshots. The imported renderer assigned every whitespace token Hebrew language/RTL attributes and a vocabulary button role. English quotations were therefore fragmented into separate RTL contexts. The correction uses contiguous isolated LTR runs and RTL Hebrew runs, with a paragraph base direction selected from its text. English runs, including handles/URLs, are not Hebrew vocabulary buttons. Stored text and original token order are unchanged. Directional isolation follows W3C inline-bidi guidance: https://www.w3.org/International/articles/inline-bidi-markup/

The screenshot's technical notice is emitted by `applyAssistance` when the Hebrew hint field is withheld. The guide text comes from a separate pronunciation field; its heading was hidden by CSS. Reproduced a provider-shaped response with Latin transliteration in `hint` and a valid independent Latin pronunciation guide. Rejected hints now preserve valid nikud, translations, related forms and pronunciation. Optional malformed hints are withheld whole, including Arabic-contaminated hints, rather than stripping characters or corrupting other fields. Hebrew lemma/nikud/root checks remain strict. Progressive-hint validation failures are also translated to a friendly message. Pronunciation has a visible section label, field label and explicit preference gating.

The exact original provider response was not retained and was not recoverable here. A fixture reproduction proves the processing behaviour, not the contents of the user's original completion. Safe server diagnostics now record only rejected field names and reason categories, never provider bodies, article text or keys.

The old automatic expression mechanism contained five two-word entries, inspected only adjacent pairs on tap and did not annotate imported paragraphs. The new shared dictionary and boundary validator support the seven requested expressions, exact punctuation-bearing ranges, conservative literal-use exclusions and non-overlap. A source-integrity check also exposed one stale curated practice range; it is corrected and all curated ranges must match underlying words exactly.

## Implementation

- Default-on “Highlight useful expressions” preference uses existing per-account preferences JSON; no schema migration.
- Subtle dotted underlines annotate word nodes without altering rows, word IDs or paragraph IDs. Tapping any member selects the exact whole phrase. Tapping it again clears selection/nikud.
- A secondary “Look up ‘…’ only” link is shown only for an automatic selection. Manual long-press, tap-based and keyboard phrase selection remain available. Turning highlighting off restores ordinary word selection, including the practice passage.
- Additional contextual AI candidates share existing bounded nikud/meaning preparation requests. Candidates require exact text and contiguous 2–5-word indices within one source row. Foreign/script-corrupt candidates, sentence-crossing punctuation, mismatched text and overlapping highlights are rejected. There are at most three highlights per paragraph. Dictionary entries take priority over conflicting AI ranges.
- AI annotations are cached per account/article, with full source-signature verification, bounded cache size and generation checks against stale responses. Detection failure leaves text readable. Normal taps repaint only changed nodes after initial detection.
- Structured reusable-form kinds distinguish infinitives, deliberately reusable conjugated forms, dictionary forms and expressions. A finite form labelled as an infinitive is withheld, never relabelled or guessed. Context is preserved in language-service requests. Hitpael root consistency now accounts for the vowel-letter spelling in forms such as להתמודד without hard-coding that word/root.
- No extra per-tap detection request or new paid service. Additional structured output increases token usage in existing preparation calls. New analysis-cache versions cause a one-time re-preparation; saved vocabulary/history/progress are not touched. Preparation disabled/unavailable means dictionary-only automatic detection.

## Verification

Complete automated suite: **250 passed, 0 failed, 0 skipped**. Tests include mixed paragraphs and the English quotation pattern from the screenshot; names, URLs, dates and handles; source/DOM order; English non-interactivity; all seven requested expressions; literal lookalikes; boundary punctuation; overlaps; independent-word lookup; whole-expression vocabulary and breakdown; hidden translations; preference persistence/isolation; stale AI results; invalid cache/response handling; script/type-specific validation; diagnostic privacy; and repaint bounds. Existing importing/completeness, nikud, vocabulary, challenges, drafts, accounts and continuity suites also ran. TypeScript and production-build results are recorded in the release operation.

These are simulated DOM/Worker/SQLite and provider-fixture tests, not rendered-browser/device tests. Browser runtime startup failed with “trusted Node process exited unexpectedly; kernel reset.” No physical Samsung verification occurred. No development AI API key was available, so no fresh live provider completions were tested. The supplied screenshots were inspected, but the corrected visual ordering, line wrapping, toolbar behaviour and real model accuracy require Samsung/browser confirmation.

## Limitations and manual checks

The dictionary is intentionally conservative and does not cover every inflection. AI semantics and morphology can remain uncertain; range validation cannot independently prove an idiomatic meaning or every irregular root. Some literal-context exclusions can suppress a legitimate use. AI additions arrive progressively only for prepared reading windows; the entire long article is not analysed up front. Manual phrase selection is always available.

Samsung: reopen the English quotation/social post; verify word order, punctuation and wrapping. Select שהתמודד in its original sentence; verify hidden English, infinitive/reusable-form labelling and a guide only when enabled. Tap both words of נוגע ללב and the seven sample expressions; test repeat tap, individual-word link, Save, Word Breakdown, manual drag and highlighting off/on. Continue reading/close should preserve position and saved vocabulary.
