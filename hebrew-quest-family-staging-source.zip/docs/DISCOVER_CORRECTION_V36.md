# Discover correction and editorial release

## Release sequence and evidence

Version 33 rollback: commit `764cfc5038f3173fe317b0d0720efebd55fb30f9`, branch `rollback/v33-before-discover-correction`, saved version `appgprj_6ae384b7c5c881919edf628295267217~appgver_c7cfe72d0f5c8191b526ec7ac0492d18`.

Backend-only version 34 was checked with 300 passing tests, TypeScript and production build, then deployed to verify the actual hosted environment before the final editorial release. Its source is `128f7a066f95f140c8189cafed01cfaaedd12c5b`, saved version `appgprj_6ae384b7c5c881919edf628295267217~appgver_9921930fa9548191a8622f7e22ebf865`.

The hosted nonpersonal metadata status endpoint returned HTTP 200 at 11:59 UTC on 1 November 2026: 175 unique real articles, 60 recommendation candidates, seven working feeds. Ynet supplied 120 entries across four feeds, Globes 15, N12/mako 40 across two feeds. Israel Hayom's access-rule request returned HTTP 403. Default-cache diagnostics returned `default_cache_disabled`; isolated named caching worked. This was a real deployed Worker request, not a Node mock or browser simulation. No visitor identity was forged and no private account data or AI key was read. The status route exposes fixed publisher metadata only; existing Site access policy and protected account routes are unchanged.

## Confirmed root cause

Version 33 used `caches.default`, which is disabled for namespaced Workers. The edge cache read sat inside the outer feed-fetch try block: its exception stopped execution before the publisher fetch. Promise.allSettled converted each exception into an unavailable publisher. The UI then presented a generic HTTP-200 empty list as no topic matches. The normal test harness and direct Node experiments omitted the deployed cache and therefore missed this failure. The original production logs show all topics and all publishers selected, HTTP 200 and 32–38 ms requests; this is consistent with an early cache rejection. The new deployed probe confirms the cache failure.

Primary platform documentation: https://developers.cloudflare.com/cloudflare-for-platforms/workers-for-platforms/reference/limits/ — Cache API section states caches.default is disabled for namespaced scripts.

The fix uses an isolated named cache, catches cache read/open failures independently, and continues with actual publisher requests. Cache entries with empty arrays are not accepted as successes. Failure backoff remains separate from successful metadata. Empty states now distinguish no selected sources, disabled sources, network/access failure, restrictive interests and completed articles. Broadening is explicit; no blanket filter relaxation was used. Difficulty remains a soft ordering preference and does not exclude unknown-length items. Completed-article exclusions stay account-scoped.

## Publisher and image handling

Ynet, Globes and N12/mako remain active. Israel Hayom is temporarily disabled after the deployed 403, not fetched repeatedly, and its saved preference is retained. It is visibly paused inside Personalise. No alternative endpoint, paywall workaround or publisher authentication is used.

Images come only from the exact article's RSS media thumbnail/content/enclosure or description image. HTTPS, publisher image-host allowlists, supported raster types and the Globes Cloudinary namespace are validated. No generated news imagery or unrelated stock images are used. Images stay on publisher hosts; feed credits are preserved. Featured images are eager, remaining card images lazy, with fixed aspect ratios and asynchronous decoding. Failed or intrinsically tiny photos fall back to labelled topic artwork and lose the publisher-photo credit. HTML image display dimensions are not invented as natural resolution. Large declared media dimensions help choose the feature photograph.

Live image checks: Ynet JPEG 200, 320×180, 7,951 bytes; Globes JPEG 200, 800×392, 81,033 bytes; N12 sample JPEG 200, 82×62, 3,132 bytes. The tiny N12 thumbnail is unsuitable for enlargement and is rejected by the display fallback. Other N12 entries can still use a suitable image if supplied; no larger URL is fabricated. Browser image rendering is unverified.

## Editorial interface

Discover now leads with its heading, a brief welcome, compact Surprise me and Personalise actions, one large featured story and five further cards. Desktop uses a feature spanning the grid and three smaller columns; medium screens use two columns and phones one column. The navy, teal and paper palette is retained. Personalise is a closed section by default, with explicit controls, saved preferences and clear paused-source information. Editing does not discard displayed recommendations before Apply. A neutral static loading placeholder contains no invented headlines or fake article data.

Cards preserve exact Hebrew headlines, source/date, short feed description, topic and optional supported reading-time estimate. Unsupported time/difficulty estimates are omitted. RTL text is isolated from LTR interface controls. Placeholder lettering is not treated as vocabulary. Original-only publishers link to the publisher and offer permitted-text paste. Ynet/Globes say import not yet checked rather than promising success. A short-lived account-scoped device marker is shown only after an actual successful Reader import. This marker does not write reading completion or change history.

The guarded importer is reused without changing its implementation in this release. Failed/cancelled/stale imports preserve the current article. Vocabulary, challenges, progress, Word Help, quotas, billing, AI configuration and the stable desktop side panel are untouched. Discover uses zero generative AI requests and does not prepare language data merely to show cards.

## Verification

The complete suite passed 310 automated tests before final packaging, including existing Reader regression tests and new realistic cache-failure, source-disable, Atom-link/date, image-provenance, tiny-image, failure-fallback, personalisation, explicit-broadening, difficulty, completion-history, import-status and simulated responsive interaction cases. TypeScript passed. Production build is required by packaging before deployment.

Live HTTP importer checks: Ynet `https://www.ynet.co.il/news/article/r115iieamg` imported 8 paragraphs / 414 words. Globes `https://www.globes.co.il/news/article.aspx?did=1001561454` correctly refused subscription-only content. These use the existing import code in development and are separate from browser UI verification.

Real browser automation could not start: read-only runtime session path. No physical Samsung testing, rendered mobile/desktop screenshots, actual sticky-header/scroll behaviour or browser-image appearance is claimed. CSS and DOM simulations do not prove visual quality. Deployed metadata verification is genuine and separate from this limitation. Final source-specific counts and public-filter probes are to be recorded in the Word release notes after the final deployment.

## Samsung checks

1. Refresh. Discover should show a featured story/image and cards, not open checkboxes.
2. Open Personalise, check saved choices and Israel Hayom paused state, then Apply. Try a narrow interest and the explicit Broaden action.
3. Try Surprise me repeatedly; it should not repeat the previous single suggestion or make AI calls.
4. Open a Ynet story in Reader. Try a restricted Globes story and check the original/paste recovery leaves current reading intact.
5. Check photo failures show labelled artwork, Hebrew headlines wrap, there is no sideways scrolling, and Reader/Close remains reachable at enlarged text sizes.
6. On desktop, check the larger feature/grid and the unchanged stationary Reader Word Help panel.

Final empty-state regression: applying no topics now clears old recommendations and disables Surprise/Different suggestions until a valid selection is applied.
