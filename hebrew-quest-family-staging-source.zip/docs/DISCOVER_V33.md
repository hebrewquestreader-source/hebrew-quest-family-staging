# Version 33 — optional, metadata-only Discover

Version 32 is the preserved baseline, commit `8e56112c7ea3338024131cf3c7992b3fcdb0c1c8`, saved version `appgprj_6ae384b7c5c881919edf628295267217~appgver_1bc55c76130c8191bab04f397b22f304`, local branch `rollback/v32-before-discover`.

## User experience

`Find me something to read` near the top of Reader and `Discover` in navigation open the same optional view. Reader’s compact URL bar, paste option, collapsed guide and stable desktop Word Help tracks remain. Six recommendations appear at a time, without infinite scrolling. `Surprise me` chooses from the real metadata pool locally and avoids repeating the previous single suggestion; `Different suggestions` advances to unseen candidates. No timers, streaks, reminders or completion credit are introduced.

Preferences offer all eight requested topics, multiple publishers and Easy/Normal/Challenge. They use the existing account-scoped preferences JSON and durable preference-write path. No schema migration or new service is added. Existing preference keys and user data are retained. Account separation and completion filtering are checked on the server. Up to the latest 1,000 completed URLs are excluded; importing or merely viewing Discover never marks anything complete.

Topics use publisher section identity plus transparent headline/summary/URL keyword matching. Ranking prefers recent timestamps, spreads suggestions across publishers/topics and uses a requested difficulty only where an explicit publisher word count exists. It is not an AI assessment of Hebrew proficiency. Current feeds generally omit full article word counts: cards state that reading time/difficulty were not supplied. Summary length is not presented as full article length. If explicit word count is provided, time uses 150 words/minute, with length-only categories ≤300 / ≤700 / >700 words, clearly approximate. The difficulty preference is not a strict filter; unknown-length articles remain eligible. Science/history availability depends on relevant current feed entries; no content is invented to fill a topic.

## Verified publishers and import distinctions

Checked with direct public HTTP requests on 1 November 2026:

| Publisher | Verified discovery | Reader import |
|---|---|---|
| Ynet | News, digital, culture and economy RSS | Existing URL importer. One live news sample imported successfully: 13 paragraphs, 591 words, including its ending. Availability remains article-specific. |
| Globes | Homepage RSS | Existing importer for accessible public text; paywall checks remain. The tested RSS recommendation was subscription-only and correctly refused. Broad success is not claimed. |
| N12 / mako | Officially linked politics and world RSS | Original-site and permitted-text paste actions; importer is not extended to these domains. |
| Israel Hayom | Public RSS XML, 100 items at verification | Original-site and permitted-text paste actions; importer is not extended. |

Exact feeds are declared in `lib/discover-catalog.ts`. No endpoints or article links are generated. Primary publisher documentation:

- https://www.ynet.co.il/articles/0,7340,L-3136256,00.html
- https://www.ynet.co.il/articles/0,7340,L-3369891,00.html
- https://www.globes.co.il/webservice/rss/rssfeeder.asmx?op=FeederNode
- https://www.mako.co.il/rss/Article-64159d874b70221004.htm
- https://www.israelhayom.co.il/rss-feed

The official Ynet legacy directory labels/IDs were verified against actual channel titles: 544 is digital, 538 culture, 6 economy, 2 news. Other old IDs did not match expected categories and were not guessed into the catalogue. For example, 550 is cars, not science. The N12/mako official directory’s politics link points to `news-military.xml`; it is used exactly as published.

Calcalist’s older `GeneralRSS/0,16335,L-8,00.xml` and Haaretz’s `feed/newsRss.xml` returned 404 in these checks. Kan and TheMarker did not have a sufficiently verified integration in this pass. They are omitted, not shown as functioning preferences. Their existing manual-import support, where present, is untouched. N12 metadata can link to mako’s news domain, so it is labelled N12 / mako rather than inventing an N12-only source.

Live importer checks used the actual unmodified `lib/importer.ts` with robots and visible-body/paywall checks:

- https://www.ynet.co.il/news/article/h1ri3yeagx — success, 13 paragraphs / 591 words. The recorded last paragraph ends with the explanation of a further election if no government is sworn in.
- https://www.globes.co.il/news/article.aspx?did=1001561393 — correctly rejected as subscription-only.

RSS discovery never conveys subscription rights. No publisher credentials/cookies, hidden article state, alternate access endpoint, paywall workaround or third-party extraction service is used. Descriptions are publisher RSS summaries, rendered as plain text only when short enough (≤400 characters); longer summaries are omitted rather than rewritten. Headlines remain exact decoded publisher text. Dates are omitted when absent/unparseable. No images or full bodies are downloaded for recommendation cards.

## Caching, costs and resilience

Discover uses **zero generative AI calls**, no paid service and no AI scheduler/quota/key/model/billing changes. It does not prepare discovered articles. Only choosing Read in Hebrew Quest loads a single article through the existing importer, after which ordinary v32 Reader behaviour applies.

Public RSS metadata is cached for 10 minutes in the Worker isolate and Cloudflare’s existing Cache API where available. These cache entries contain publisher metadata only, never preferences, account identities, learner answers or completion history. Authenticated recommendations are filtered per account after cache lookup and returned with private/no-store headers. Concurrent identical cold feed requests are deduplicated. Up to eight declared feeds are fetched concurrently; requests have bounded eight-second timeouts, bounded 750 KB downloads, and no arbitrary URL input or automatic redirect following. Robots rules are fetched once per origin/window; 404 means no published rules, other rule-fetch failures fail closed. Publisher disallow rules are respected.

A failed feed backs off for one minute separately from the successful metadata cache. Existing metadata up to one hour old can be shown with an explicit cached/stale notice. After that it is omitted. Partial failure is labelled and working publishers remain available. Empty results offer changing preferences or using Reader; no fallback articles are invented. No automatic polling or retry loop is introduced.

Direct live service experiment in this development environment at 13:33 Israel time: all four publishers yielded 60 bounded candidate recommendations, no unavailable publishers; cold request took 12,300ms / 12 outbound feed-or-robots fetches, warm request 16ms / zero outbound fetches. Earlier checks had intermittent timeouts and a 29-second cold fetch; parallel fetches and negative caching removed the repeated slow warm fetch. These are Node/development-network measurements, not production-browser or Samsung latency guarantees. Cold performance still depends on publisher/network response; a first visit may take several seconds. Surprise me and Different suggestions use the returned pool and make no network requests.

## Import and data safeguards

The existing guarded click-handler body is exposed as `importUrlFromReader()` so both entry paths use identical cancellation, stale-response protection, loading, import validation and failure behaviour. Its original URL button calls that same function. Added boolean success/failure results let Discover show an original-site link and paste recovery after a failed import. A stale/cancelled response returns no result and does not trigger recovery for a newer import. Existing import race, duplicate, cancel, content-completeness and 100+ paragraph tests run unchanged.

Discover reads completed URLs, never modifies vocabulary, progress, challenge state, article completion or AI limits. Closing the view restores focus/scroll; original-site-only cards do not pretend to support URL import. Paste recovery opens the existing paste controls without replacing article text or existing pasted text. Preferences are additive fields in existing JSON, not a migration. An exact v32 rollback predates these preference names and its strict validator may ignore a JSON object containing them; retain preference JSON before a rollback and use a compatible rollback if preferences need to remain visible. Article/vocabulary/progress records are unaffected.

## Verification and limitations

The full automated suite passed **297 tests, 0 failed, 0 skipped**; TypeScript passed. The final packaging run repeats the suite and TypeScript, and requires a successful production build before publishing. Discovery tests exercise real captured RSS samples (two actual items from each of the eight feeds), source URL validation, dates, metadata omission, topic/publisher filtering, completion canonicalisation, account isolation, cache/dedup/backoff/stale recovery, blocked feeds, exhausted AI quota, no speculative language requests, local Surprise choices, preference persistence, real importer integration/failure recovery, cancellation of late view results, scripted focus/scroll and responsive markup. Existing Reader tests cover v32 request protection, Unicode, morphology, English LTR, popup, vocabulary, challenge drafts, continuity and import completeness.

**No real-browser or physical-device verification:** browser automation could not start because its runtime session path is read-only. CSS and simulated-DOM tests do not prove actual layout, sticky positioning, Android Back behaviour or scrolling. No live Word Help requests were made. Publisher metadata and the two importer HTTP outcomes above were tested live separately from the simulated tests.

Samsung checklist:

1. Refresh and open Find me something to read; try Back to Reader and the Discover navigation entry.
2. Choose two topics and publishers, select Show articles; close/reopen and refresh to check preferences.
3. Try Surprise me several times; check different suggestions, source/date and original links.
4. Open a Ynet article in Reader, then verify its headline/source, nikud interactions, URL bar and saved reading position.
5. Try a restricted Globes article: confirm current reading survives and original/paste recovery works.
6. With AI still paused, confirm Discover browsing and Surprise continue working. Check one-column cards, long Hebrew headlines, large text, Close visibility and desktop two-column cards separately.
