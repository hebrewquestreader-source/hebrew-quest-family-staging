# Word Help correction — version 29

Scope: contextual translation placement and breakdown reliability only. No account, import, reading-progress, provider/model or storage migration changes.

## Findings

The v28 validator rejects a provider-shaped response for `שאימץ` with lemma `לְאַמֵּץ` at `lemma`. Independently, suppressing that lemma reproduces a component-reconstruction failure for `שֶׁ־` plus `אִמֵּץ`: the selected full spelling contains a yod represented by hiriq in the pointed stem. These are deterministic failures in our processing, not proof of the contents of the original production completion. Production request logs confirm HTTP 422 breakdown failures but retain no response bodies, so the exact originally failing field is unknown.

The shared popup markup placed both contextual translation slots after the reusable form. This is corrected in the shared markup for both responsive layouts. Only one contextual slot is displayed, and both remain hidden until Translate.

Root-template checks also lacked quadriliteral Piel, hollow Paal, assimilated-nun Paal and passive-binyan surface evidence. Adjectives were absent from the schema. Checks now cover these patterns without deriving or replacing a root. Unsupported roots remain withheld. This is structural validation of a model proposal, not independent grammatical verification.

## Corrections

- Piel finite/infinitive relationships accept their constrained vowel/spelling alternation, with attached prefixes and existing suffix handling.
- Component reconstruction uses validated nikud alignment and consecutive source-word boundaries. No arbitrary letters are removed. No original selection is rewritten.
- Strict Hebrew Unicode validation precedes alignment. English, metadata and root notation retain their separate field rules.
- Prompt explains finite verbs, affixes, adjectives and absent passive infinitives explicitly. Model, provider and retry budget are unchanged.
- Invalid cache entries are discarded and re-fetched. Failed or uncertain completions are not stored as successful analyses. Old cached analyses are isolated by the new analysis-cache version; vocabulary and reading data are untouched.
- Component failures carry a field-specific diagnostic. No provider body or credentials are logged.

## Verification

Complete automated suite: 227 passed, 0 failed, 0 skipped. Includes semantic assertions for all seven requested examples, all seven binyanim, prefixed Piel, weak/irregular root patterns, final root letters, quadriliterals, adjectives, phrase boundaries, Unicode corruption, malformed responses, transient errors, bounded retry, invalid cache recovery and request deduplication. The mobile/desktop ordering tests use simulated DOMs at 360 and 1280 pixels; they are not rendered-browser tests. Existing import, vocabulary, challenge and continuity tests also ran.

No live provider completion was obtained: the development environment has no configured test API key. Fixtures are constructed provider-shaped responses, not captured production answers. No credentials were extracted or identity restrictions bypassed. Real AI accuracy for these forms must therefore still be checked with the user's configured service.

Browser/device testing was unavailable: the browser runtime failed at startup with “trusted Node process exited unexpectedly; kernel reset.” Samsung scrolling, actual typography and live AI behaviour remain manual checks. Structural pattern checks cannot guarantee all irregular roots or resolve every contextual ambiguity; unsupported/uncertain analyses remain withheld. A lexicon-backed morphological analyser would provide stronger independent checks, but no new service or model configuration is introduced in this correction.
