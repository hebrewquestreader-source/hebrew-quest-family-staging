# Word Family and Word Origins catalogue, edition 1

Checked on 4 November 2026. A match requires the existing validated Breakdown
dictionary form, part of speech and a compatible dictionary gloss for the
contextual analysis. Matching is deliberately conservative. A root by itself
does not qualify. This static catalogue does not call AI or send lookup data
to the references.

| Headword and sense | Catalogue content | References |
| --- | --- | --- |
| להזכיר (mention or remind) | לזכור, זיכרון, תזכורת, מזכרת | [Pealim verb](https://www.pealim.com/dict/35-lehazkir/), [Pealim noun](https://www.pealim.com/he/dict/3403-mazkeret/) |
| לכתוב (write) | כתיבה, מכתב, כתבה, התכתבות | [Pealim](https://www.pealim.com/he/dict/3035-michtav/) |
| טלפון (phone or telephone) | Greek elements for distance and voice, and modern Hebrew verb formation | [Hebrew Wiktionary](https://he.wiktionary.org/wiki/טלפון), [Académie française](https://www.dictionnaire-academie.fr/article/A9T0581), [Academy of the Hebrew Language](https://terms.hebrew-academy.org.il/munnah?kodErekhIvrit=8178) |
| טרור (terror or terrorism) | International loanword ultimately traceable to Latin | [Wiktionary contributors, checked revision](https://en.wiktionary.org/w/index.php?title=טרור&oldid=91750653) |

The catalogue uses individual lexical facts, independently written short English
glosses and original summaries. References are credited in the interface. No
dictionary entries, tables, recordings or bulk datasets were imported. No rights
to redistribute Pealim or academy material are assumed. Wiktionary entry prose
is distributed by its contributors under
[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) and/or GFDL
according to its [copyright notice](https://en.wiktionary.org/wiki/Wiktionary:Copyrights).
Any future reuse of protected text must follow the relevant source terms.

Open issues outside this release: the unexplained core failure for בטרור,
the article spelling and meaning of מונשט, and Edge access.

## Edition 2

- נדל״ן expands to נכסי דלא ניידי. The construction dictionary by Saul
  Rotstein and the Academy's entry for immovable property corroborate the term.
- מנכ״ל expands to מנהל כללי and דו״ח to דין וחשבון, both checked against
  the Academy's terminology entries.
- לצאת לאור in its publishing sense is a figurative expression, separately
  labelled and checked against the Academy's publishing glossary.

Explicitly marked catalogue abbreviations can open locally without a grammar
request. Unmarked spellings require a matching validated dictionary sense.
Loanwords retain a separately labelled origin and historical note.
