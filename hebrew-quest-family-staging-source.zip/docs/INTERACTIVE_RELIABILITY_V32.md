# Version 32 — interactive assistance before speculation

## Confirmed causes and limits

The live owner daily application counter was **100/100 on 1 November 2026 at 09:51 UTC**, expiring at the server's next UTC bucket, **2 November 00:00 UTC**. It had not reset. This release does not reset, increase or rename counters; no billing/provider/key/authentication changes are made. The configured provider/model remains Google Gemini `gemini-3.5-flash-lite`. A counter of 100 confirms an application daily ceiling, not a separate provider quota exhaustion. Production counters do not contain service attribution, so the fraction of the owner's actual historical use caused by preparation cannot be reconstructed.

Reproduced in retained source/fixtures: v31 partitions a cold 602-token fixture (600 body plus headline) into 16 requests and queues all visible/nearby windows. Its two-per-minute pacing caps speed, not total consumption. Generated Hebrew hints and breakdowns can then create preparation requests of their own. In the retained reading script, 21 of 26 calls are preparation. The availability manager deduplicates but has no priority queue or reserved daily admission threshold. Independent hint/breakdown error panels duplicate the shared outage notice and offer ineffective retries.

## Changes

- One account-scoped request queue, two concurrent client requests maximum, at most one background job. Queued foreground jobs run first. A foreground job can use the second slot while a background call finishes. Existing in-flight calls are never aborted simply to change priorities; duplicate queued work is promoted. Queued old-article/hidden-page jobs are discarded before fetch.
- Server admission reserves **80% by default** of the unchanged 100/day and eight/minute allowance. Background stops once **total daily use reaches 20**, or total current-minute use reaches one; foreground can still use the original 100/eight. This is intentionally conservative: a background allowance is not a separate pool that could spend the final requests after heavy interactive use. Configurable account preferences offer 75%, 80%, 90% or 100% reservation. At 100%, preparation makes no provider calls. For nonzero background budgets, minute admission rounds to at least one slot; the daily reservation remains exact. These settings change priority allocation, never the original ceilings.
- One 12-token initial preparation batch after two seconds of idle time; no blocking article render. Additional nearby batches are earned after each four new uncached word analyses, with a maximum of three speculative batches/article opening and one/minute pacing. Thus up to 36 speculative tokens rather than all 600. Exact older paragraph and global-window caches remain usable; a warm cached reopening gets no speculative initial request. Hints, feedback and grammar text are interactive on demand, without recursive background preparation.
- A tap reuses prepared/cached data or requests its selection directly; it waits only for preparation already in flight for those tokens, not a queued full window. Meanings remain context-keyed and hidden until requested.
- A selected-word request can return optional bounded basic morphology in a shared structured schema. Server and browser independently validate it using the existing strict Hebrew/root/component rules. Valid morphology is reused by Word Breakdown, requested or displayed only through the existing explicit control. Invalid/uncertain optional grammar is withheld without throwing away valid nikud/meaning or spending an automatic retry just on that optional field. A separate breakdown request remains available when a prepared/older result lacks reliable grammar. Progressive, quality-checked two-clue hints remain one explicitly requested call.
- One shared compact availability notice. Future-deadline retries are hidden; only unknown reset times offer one shared manual retry. Uncached actions are disabled during the pause, while cached meanings/clues and Save remain usable. A server-supplied deadline clears the hold and re-enables controls without a refresh or an automatic AI request. The next explicit Translate can request missing information. No reset time is invented.
- Automatically resumed incomplete-vocabulary enrichment also uses background priority and the server reservation; explicit enrichment/sync retries use foreground priority. This priority is transient, not persisted into vocabulary records. Vocabulary writes and durable retry recovery are retained. An AI-only enrichment retry is hidden while it cannot run; a failed original vocabulary write still has its own retry. Stored selection/context and pending enrichment remain intact.

The default reserve favours reliable reader actions over broad prewarming. A user who reads very slowly and never asks for help now spends at most one initial preparation request per uncached opening; a user who makes scattered cold lookups will encounter more on-demand requests than someone whose entire article was prewarmed. Cache hits remain local. Live latency should be measured on the phone before further tuning.

## Reproducible request measurements

`tests/helpers/selective-audit.mjs` and `docs/REQUEST_AUDIT_V32.json` record **scripted simulated-DOM/provider-fixture experiments**, not live Gemini, a physical Samsung or a timed human session. Idle/minute time is advanced by the test; an artificial 12ms provider response delay is used. No real quota is consumed by the experiments. v30/v31 code is retained under tests/fixtures and their original same-workload counts are checked by the regression suite.

| Same 600-word workload | v30 | v31 | v32 |
|---|---:|---:|---:|
| Article preparation before word selection, after draining allowed queued work | 25 | 16 | 1 |
| Entire scripted session | 37 | 26 | 7 |
| Session background preparation | 32 | 21 | 1 |
| Selected-word requests | 0 | 0 | 2 |
| Three requested hint pairs | 3 | 3 | 3 |
| Two requested breakdowns, extra calls | 2 | 2 | 1 |
| Repeating the last lookup, extra calls | 0 | 0 | 0 |

This synthetic article deliberately repeats שלום in each paragraph: exact sentence-context cache reuse yields **20/20 local hits** in the initial 20 contiguous token-position selections. It is not a representative estimate of distinct unfamiliar words in an authentic article. v32 immediate rendering uses zero AI requests; after the initial idle batch, cumulative calls after 5/10/20 selections are 1/1/1 in this fixture.

A second script selects 20 token positions across **ten distinct sentence contexts**. Cumulative calls after 5/10/20 positions are **3/5/11**, then **16 total** including three hint pairs, two requested breakdowns (one reused), and earned preparation. Nine selected-word calls, three background calls, three hint calls and one separate breakdown call are made. Eleven of 20 lookups (55%) are served locally. Repeating a lookup and reloading cached article text each add zero calls. Displaying generated content adds zero preparation calls. These scripts use successful responses; every actual malformed/transient retry still counts individually on the server, as tested.

Timing in the JSON is **test-harness wall time**, including fake-DOM work, not phone/browser/provider latency. Same-workload median/P95 were 121/242ms; spread-context median/P95 114/124ms in the recorded run. The 12ms artificial provider delay and simulated idle advancement make these unsuitable for predicting a real lookup. There are no comparable live v30/v31 latency samples, so no measured live-speed improvement is claimed. Architectural latency changes: warm hits stay local, a cold lookup no longer waits for queued preparation, streamed nikud remains first, and reused grammar avoids a second provider round trip. Optional morphology increases some response tokens; live token/cost impact is not yet measured.

## Non-AI resources: recommendation, not an installed dependency

Keep the existing curated, context-checked phrase dictionary as the immediate quota-independent layer. It recognises phrases and supplies existing curated help locally, including נוגע ללב, without calling AI or revealing English automatically. Generated contextual caches stay account-scoped: sharing subscriber/private sentences across accounts is not introduced.

Candidate future evaluations:

| Resource | Potential use | Constraints before adoption |
|---|---|---|
| HebPipe | Hebrew segmentation, lemmas, POS/morphological features | Python/model deployment is not a small browser/Worker dependency. Code Apache 2.0; resource licences may differ. Benchmark ambiguous news inflections before displaying answers. |
| YAP / HEBLEX | Morphological candidates and contextual disambiguation | Go/model service or adaptation would need deployment evaluation. Apache code licence explicitly excludes the BGU lexicon; separate permission/licence investigation is required. |
| Hspell | Spelling and lexical/morphological candidates | Not a complete context-aware reading tutor, translation engine or nikud solution. Authors apply AGPL/GPL terms to programs, dictionary and generated lists; obtain licensing review before embedding it. |

Primary sources checked 1 November 2026:
- https://github.com/amir-zeldes/HebPipe
- https://github.com/amir-zeldes/HebPipe/blob/master/LICENSE.md
- https://github.com/OnlpLab/yap/blob/master/README-orig.md
- https://hspell.sourceforge.net/download.html

Recommendation: separately approve a small offline accuracy/licensing study on a fixed Hebrew news benchmark; do not ship an analyser or third-party dictionary merely because it is free to download. These tools can supply candidates but cannot replace contextual disambiguation, verified nikud, phrase meaning and pedagogical hint quality without validation. No new dependency, service or licence obligation was added in v32.

## Verification and remaining limits

Full automated suite: **281 passed, 0 failed, 0 skipped**. Tests run actual Worker route modules in a local harness, not against production. The suite covers route code against SQLite and realistic structured fixtures, atomic reservations, separate users, quota exhaustion/reset, scheduler priority and deduplication, transient/invalid responses, preserved caches and vocabulary writes, zero automatic requests at reset, dictionary recognition without AI, existing Unicode/morphology cases, article completeness/import races, saved positions and challenge drafts, and simulated mobile/desktop interactions. TypeScript and production build must also pass before publishing.

Browser automation failed to start (read-only runtime session path). No browser geometry, actual mobile scrolling, physical Samsung, live provider response, live lookup speed or live post-reset account access was verified. Existing geometry checks remain simulated; the v31 desktop CSS is unchanged. No production API key was extracted and no exhausted allowance was reset for QA. Authentication, article import, user records and storage schemas are unchanged.

Samsung checklist:
1. Refresh once for new client scripts. With the current outage, check one notice, hidden ineffective retries, cached help, local נוגע ללב recognition, and saving an unfamiliar word.
2. After the stated server UTC boundary, tap a new word, request Translate/Hint/Word Breakdown, and check controls recover without a page refresh. A separate provider limit can still pause new requests.
3. Import a fresh article; confirm immediate reading and no rising background counter beyond the small initial batch while simply reading. Repeatedly tap the same word and reopen the article to check reuse.
4. Verify English stays hidden until requested; long-press phrases, nikud, reusable form, pronunciation settings, Continue reading and vocabulary still behave normally.
5. In Settings, confirm the default 80% reservation. Test 100% to disable speculation while keeping explicit requests; restore 80% afterwards if preferred.
