# Word Help reliability release 40

Baseline saved version 39, commit 0535e4a434c8cf8a9c7d52d32681179eed5b6490. Rollback tag rollback-v39-before-language-v40. No data migration.

## Evidence and limits
Nine owner-provided Samsung screenshots were inspected. They show a finite הזכיר labelled infinitive, repeated failures for האהובים and ייזכר, a literal shadows-unit translation, and redundant noun components for קנצלר. No historical raw provider completions are retained. Production log request 277e4329c1fd8f6719f4bbbe99dbaedf at 04:23 UTC on 2 November 2026 has two provider HTTP 200 completions and a final breakdown HTTP 422. It establishes local validation/parsing failure for that request, not the exact word or field. Several optional morphology analyses were rejected with only a generic old diagnostic. Other background preparation requests separately returned 429; these are not evidence that the pictured analysis errors were quota failures.

## Confirmed code defects and corrections
- Breakdown accepted a related finite verb as lemma and the renderer labelled every verb lemma infinitive. Non-infinitive proposals lacking infinitive prefix are now withheld whole; reliable surface features remain. No guessed lamed, replacement lemma or root.
- The relation guard rejected valid full-to-pointed Nifal future/infinitive pairings, and Paal active-participle/infinitive relationships. Bounded pointed-template checks now cover these patterns. This is relation evidence, not a morphology generator or proof of semantic accuracy.
- A malformed optional lemma or per-token analysis could discard independently valid main help. Optional fields are now rejected whole and flagged; valid nikud and contextual meaning survive. Preparation retains its previous malformed-form rejection/notice contract, without changing its scheduling, limits or requests.
- A later response failure restored earlier text even after valid streamed nikud. Checked early nikud now survives; invalid nikud is still rejected.
- Failure and optional-analysis logs now record bounded field/code/reason/attempt metadata without sentences, raw responses or keys. Historic missing diagnostics cannot be reconstructed.
- Repeated automatic-retry failure/success prose was removed. Uncertainty, service unavailability, access and quota remain distinguishable. Existing one-retry ceiling and no quota retries are unchanged; partial usable results do not trigger an automatic repeat.
- Breakdown omits person on present participles/infinitives and gender/number on infinitives, labels common gender as not distinguished, removes redundant whole-word noun components and absolute-state display, and keeps optional manual retry for withheld infinitive/root.
- Prompts distinguish finite headword/infinitive, adjectival passive participles, ordinary construct phrases/names and genuine idioms. Contextual translation must use natural English; literal component glosses remain separate. No word-specific runtime answers added.

## Scope
Modified shared Hebrew and morphology validators and browser mirrors; assist/breakdown instructions and parsing; safe language diagnostics; Word Help labels/messages; static script versions; one preparation validation condition; fixtures/tests/notes. Model, billing, quotas/accounting/scheduler, database, vocabulary persistence, reading progress, account management, Discover, importing, navigation, typography and desktop Word Help geometry are unchanged. Existing caches are retained and revalidated, not deleted. Old structurally valid but semantically wrong cached translations require the existing manual Retry language help action.

## Verification
21 human-authored sentence-specific benchmark cases and provider-shaped synthetic responses assert selected spelling, nikud, contextual meaning, reusable form, category, applicable features and root separately. Mutation tests cover bad finite headwords, malformed optional data, script contamination, cache revalidation, failures, retries, retained early nikud and labels. These test pipeline behaviour, not live Gemini accuracy. Complete suite: 370 pass, 0 fail, 1 existing unavailable publisher-fixture skip; 371 total. Focused run: 89 pass. TypeScript and production build passed. Live Gemini calls consumed: 0. Browser preview start/status failed because the relay is unavailable; no physical Samsung or rendered-browser verification.

## Remaining limits
The exact original האהובים field failure is unresolved; the valid adjective fixture passes and optional-data failure mechanisms are fixed. The phrase translation improvement is an instruction and regression expectation, not a verified new live completion. Root and relation checks are bounded safeguards, not a full licensed Hebrew morphological analyser. Plausible but wrong vowel/tense/meaning proposals can still pass structural validation. Some irregular roots may be withheld. No new linguistic dependency or dictionary content integration.
