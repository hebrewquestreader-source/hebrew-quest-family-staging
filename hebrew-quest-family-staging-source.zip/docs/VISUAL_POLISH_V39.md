# Version 39 visual polish

Baseline: deployed version 38, source f741ee467d42b49e53e1650f42957a49da9fa15d.
Local rollback tag: rollback-v38-before-visual-polish-20261102. Saved version 38 remains available for rollback.

Scope: CSS only, plus stylesheet cache URL, regression tests and these notes. No JavaScript, API, account, persistence, learning or importing changes. No data migration or dependencies.

Reader: slightly stronger proportional headline, consistent paragraph rhythm, quieter secondary controls, source metadata and status text. Existing article size/line-height variables and Word Help geometry remain unchanged. Reading tools remains fixed rather than taking document space.

Discover: 16:9 landscape covers, with square compact mobile thumbnails; consistent headline and metadata spacing, quieter topic labels, readable importability labels and existing primary action. Image cropping may trim photograph edges; sources, captions and metadata remain unchanged. Existing three-line summary clamp remains.

Vocabulary: clearer Hebrew expression hierarchy, consistent collapsed/expanded padding, secondary metadata/meaning typography, restrained review buttons. Native hidden/reveal states are unchanged.

Shared controls: existing palette, 44px minimum buttons, consistent radii, visible focus/pressed/disabled/busy states, and reduced-motion override. Word Help and navigation geometry are excluded. No animation added.

Verification: see release report for executed test counts. Simulated DOM tests at 320/412/768/1440px do not apply CSS or establish actual visual layout. Managed preview start/status failed because preview relay is unavailable. Genuine before/after screenshots, mobile/desktop visual checks, zoom, screen-reader and physical Samsung tests could not be performed. No live AI calls or destructive production tests.

Deferred: navigation, Word Help, feed/import logic, persistence, AI/provider/quota work, icon replacement and broader redesign. Existing public-publisher fixture test requires an unavailable environment fixture.
