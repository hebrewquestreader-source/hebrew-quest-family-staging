# Version 38 focused presentation polish

## Baseline and rollback

- Deployed baseline: version 37, source commit `c09eef583ff7236a40814bb47984dd5b8db32066`.
- Local rollback tag: `rollback-v37-before-ui-polish-20261101`.
- Roll back by deploying saved version 37. No schema or data migration is required.
- Existing custom audience is preserved.

## UI changes

- One compact **AI help paused** disclosure beside Change article. The original availability controller owns visibility, Retry eligibility, expiry and accounting. The presentation reads its existing snapshot only. Details show a service-supplied retry time, or explicitly say none was supplied.
- Article, headline/source and Change article remain prominent. Challenges and article-completion actions stay available below the article. **Reading options and help**, collapsed by default, contains continuation/history, the existing help guide, article actions, diagnostic counts and explanatory footer.
- Reading tools explains that it is for quick adjustments, with an **Open full Settings** link. Full Settings explains its preference/configuration purpose. All controls and saved values are retained.
- Save messages distinguish Waiting to save, Saving, Saved to account, Sync paused, and Action required. Error details remain expandable; unsafe storage/recovery states remain visible. Retry is not displayed for an in-progress write or unreadable recovery data. The existing retry action is otherwise unchanged.
- Confirmed success messages disappear after five seconds. Repeated identical updates do not resurrect them; an older success timer cannot erase a newer error. Pending optional language enrichment is labelled **Language details pending** rather than presented as an unsaved original selection.
- Discover changes are CSS only: slightly tighter card gaps, improved Hebrew headline wrapping, clearer publisher/date metadata, and a maximum three displayed lines for descriptions. Full metadata remains unchanged. Existing mobile suppression of nonfeatured summaries is retained.

## Verification actually run

- Baseline full suite: 326 passed, 0 failed, 1 skipped (327 total).
- Focused suite including 10 new regression cases: 51 passed, 0 failed.
- Final full suite: 336 passed, 0 failed, 1 skipped (337 total).
- The skipped existing test needs `HEBREW_QUEST_PUBLISHER_FIXTURE`; its recorded real-publisher fixture is not supplied in this environment.
- TypeScript: `node node_modules/typescript/bin/tsc --noEmit` passed.
- Production build: Sites build helper passed.
- `git diff --check` passed.
- Browser preview start and status both report `preview relay unavailable: No such file or directory`. No alternative browser/server route was used. Real layout, touch, zoom and physical Samsung behaviour remain unverified for this release.
- Automated language-response tests use fixtures/simulated responses. No live AI call, quota reset, allowance increase or paid fallback was attempted.

## Scope boundaries and findings left unchanged

The old pending-save indicator combined ordinary writes and optional language enrichment. Only its description and controls were changed; queue serialization, persistence, retry execution, request payloads and acknowledgement rules are unchanged. No new underlying persistence defect was confirmed in this scoped investigation.

The recorded Library lookalike copies, possible Word Help relocation and floating-navigation overlap remain outside this small polish release. No fixes to AI analysis, Word Breakdown, account/authentication logic, article importing, publisher feeds, caching, recommendations, progress calculations, data structures, existing preferences, or desktop Word Help geometry are included. The account bootstrap diff only refreshes the static sync script URL so the UI update is loaded.

## Samsung verification

1. Resume a saved article. Confirm the headline/source and article text remain first; Change article and Reading tools are accessible.
2. Expand AI help paused. Check the availability explanation and retry information, then close it. Do not test new live assistance until the allowance is available.
3. Open Reading options and help. Find continuation, Recent articles, the guide and article actions. Close it and verify the article and draft remain unchanged.
4. Change text size/spacing in Reading tools, open full Settings, and return. Confirm values and reading position remain intact.
5. Save a word using cached/practice assistance or without AI. Confirm Saving precedes server-confirmed success, and incomplete language details remain distinguished. On a controlled network failure, verify the sync warning, details and existing Retry action.
6. Browse Discover. Check featured and smaller headlines, metadata, summary lengths, images and narrow-screen wrapping. Verify Show more, Surprise and Reader import still behave as before.
