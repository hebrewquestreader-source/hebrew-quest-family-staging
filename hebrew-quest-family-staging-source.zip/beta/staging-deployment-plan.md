# Safe staging release plan — 5 November 2026

State: prepared only. No deployment, provider activation, billing or invitations.
Original ChatGPT-hosted Hebrew Quest and its data remain outside this plan.

## Preserved versions

- Current hosted staging: observed deployment 28ea373f-7b93-4e5b-9864-e558a0065c23.
  This must be rechecked in Cloudflare immediately before a future rollout.
- Last source supplied for that deployment: local source commit 0baff23.
- Candidate: importer optimization 57f29b7 and data-saving fixes 3ac7169.
- Keep candidate archive distinct from the current staging-source download.
  Do not commit a replacement deployment ZIP to GitHub main before approval:
  the existing Cloudflare integration deploys that branch automatically.

## Gates before approval

1. Preserve the known working source ZIP, active version ID and current beta
   database reference. Reconfirm target is only hebrew-quest-family-staging and
   D1 7d079326-66f7-4089-8b16-b87cad64f8e6.
2. Recheck a clean candidate build, TypeScript and 31 beta regressions, plus fresh
   local Worker/D1 checks. Latest full suite: 408 passed, 41 documented inherited
   failures, one skipped. Do not report the entire suite as green.
3. Review the diff and deployed bundle: mock-only provider, no new secrets,
   no model/hosting/auth policy changes, no live traffic switch or billing setup.
4. No schema changes or production data migration. Preserve existing invitation
   rows, sessions and all browser-local data. Export the tester's guest backup
   before any future on-device migration/rollback test; do not clear site data.
5. Enrichment from an older pending job without a current record ID fails safely;
   it must be retried manually from the current vocabulary entry. Existing saved
   words, dates, statuses and examples are retained.

## Future staged rollout, only after explicit approval

A mock-only staging release does not require Gemini approval or billing, but
requires separate deployment authorization. Confirm it is acceptable to replace
only the beta Worker with the candidate while retaining the previous version for
rollback. Do not publish another public preview URL or create another database.
Use the existing private-repository/Cloudflare build process after approval.
Do not instruct a main-branch upload until the user authorizes its auto-deploy.

After deployment, verify invitation gate, existing-session recovery, mobile
Reader/Discover, exact article endings, Word Help/Breakdown simulator messages,
Origins catalogue, vocabulary save/review/reload, stale-save protection and
storage-failure recovery. Use existing tester access; no family invitations.
Run bounded hosted importing across the same short/medium/long sources; record
CPU, elapsed time, status, request ID and active deployment. Compare against the
current Worker and local measurements separately. Stay on Free unless billing
is explicitly approved; do not sacrifice features/phone performance to fit it.

For hosted isolation/revocation tests, use dedicated synthetic tester invitations
only when authorized; do not revoke the owner's working invitation. Hosted daily
quota testing should not consume or reset the owner's allowance or change caps.
If access is unavailable, report it rather than asking for credentials in chat.

## Stop and rollback

Stop on new unauthorized access, lost/corrupted data, incorrect save status,
incomplete articles, duplicate requests or a meaningful responsiveness regression.
Roll the beta Worker back to its recorded pre-release version through Cloudflare.
There is no database/schema rollback because this release changes no schema/data.
Do not delete or overwrite browser-local data; rollback cannot undo client writes
or restore erased browser storage. Preserve backups and investigate first.
Keep Gemini mocked and family access closed throughout.

## Work independent of Google's response

- Review/package candidate and maintain this rollback checklist.
- Test queued saves, simultaneous tabs, refresh/reload, backup export/import and
  error messages using mocks/local fixtures.
- Review remaining old tests for applicable guest equivalents, accessibility and
  mobile layout; no claim of hosted or Samsung results from local simulations.
- Prepare international adult-access, minimal context, privacy and country/tier
  requirements without activating them or assuming Google's interpretation.
- Hosted mock-only verification can follow deployment approval independently of
  the eventual Gemini eligibility decision.

## Family-launch gates

Google's response and a recorded eligibility decision; agreed international adult,
location and privacy controls; approved hosting/AI budgets and secure operator
setup; approved bounded live-provider tests; hosted access/revocation/isolation,
usage limits and importer measurements; Samsung/desktop acceptance. No family
invitations until these have been reviewed. No Google sign-in in this phase.
