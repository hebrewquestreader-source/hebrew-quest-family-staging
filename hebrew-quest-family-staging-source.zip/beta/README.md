# Family beta staging

This checkout is separate from ChatGPT-hosted Hebrew Quest. Never deploy it to
the original site or database. This build has mocked Gemini only. Server-backed
challenges and account sync are outside staging scope.

## Cloudflare Workers Builds

- Worker and repository: hebrew-quest-family-staging
- Branch: main
- Root: repository root
- Build command: pnpm exec vinext build
- Deploy command: pnpm exec wrangler deploy --config dist/server/wrangler.json
- Dependency tool: pnpm pinned by package.json
- D1: existing beta database wired as DB in wrangler.jsonc
- Restrict the GitHub authorization to this private repository.
- Keep Workers Free, preview URLs off, and use no live API secrets.

Cloudflare's first hosted build will verify database authorization and runtime.
The local Wrangler dry run verifies packaging, not remote resource access.
Hosted CPU limits and live publisher requests still require staging tests.

## Local verification

Run TypeScript, build, then beta/test-local.sh. It uses a fresh local D1 and
synthetic invitations. Its access checks replace Sites-specific identity tests
for this deployment. No real invitations or secrets are in this repository.

## Before family invitations

- Verify arbitrary selections in real article context through the approved live
  provider, including core help and Breakdown independently. The six simulated
  fixtures prove integration only and cannot demonstrate arbitrary-word support.
- Keep live Gemini disabled until terms, geographic eligibility, privacy,
  server-side security and costs have been reviewed and access approved.
- Word Origins is a checked catalogue. Unsupported words must omit the section
  safely. Historical explanations cannot be promised for every Hebrew word.
- Verify missing simulator selections show an accurate staging message
  (reported examples: נשענים and ליחידות), with no provider or key advice.

## Samsung staging findings, 5 November 2026

Verified by the owner on Samsung Chrome: invitation redemption, unauthenticated
incognito gate, one Discover article import, simulated הודיעה help and Breakdown,
local vocabulary persistence, review status, review answer, JSON merge import,
article position recovery and navigation recovery. Gesture selection worked
inside a saved sentence. These observations do not verify arbitrary AI help.

Fixes prepared: missing simulator messages, browser-local vocabulary wording,
ignore word-only self-examples on repeated saves, and a same-site Continue
reading link on the invitation gate for existing Strict-cookie sessions.
The cookie protections and seven-day session lifetime are retained.
Existing stored examples are preserved. The extra example already saved during
testing is not removed automatically.

Remaining release gates: independent guest isolation and revocation on staging,
server quotas on staging, measured short/medium/long importer CPU, live terms,
security/cost approval and approved bounded real-provider verification.

## Regression isolation

`legacy-test-baseline.json` records the exact 41 inherited failing test names
reproduced on commit 72f3ef8 with the JSON-capable test loader. These concern the
original Sites identity/account runtime, server account sync and account UI.
They are retained, not deleted or marked passing. The full suite is not green.
The beta Worker security checks run separately against fresh local D1, covering
revocation, isolation, CSRF, spoofed identity rejection and atomic quotas.

Latest local validation: 393 full-suite tests: 351 passed, 41 unchanged inherited
failures, 1 skipped. Seven new targeted checks passed. TypeScript and vinext
production build passed. Local Wrangler/D1 checks passed, including simulator
misses through both actual endpoints, same-site recovery link, local-storage
notice, expired/revoked sessions, redemption race, CSRF and per-guest/global
quotas. These are local measurements, not Samsung or hosted Worker CPU results.
One local Wrangler run terminated with a network-connection-lost runtime error;
a fresh local run completed all checks. No live Gemini calls were made.
