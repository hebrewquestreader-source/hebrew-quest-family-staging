# Gemini API eligibility: private international adult family beta

Hello Google Gemini API team,

I am developing Hebrew Quest, a private, invitation-only, noncommercial Hebrew-reading application for 3–10 adult relatives in Israel, the United States and potentially other supported countries, including the UK and EU. There would be no public registration, advertising, subscriptions or under-18 access.

Gemini would provide contextual meanings, hints and grammar from selected text and limited article context. One developer-managed key would remain server-side, with strict usage limits.

Before enabling Gemini, please clarify:

1. Is this development and ongoing private family use permitted under the professional/business-purpose rather than consumer-use restriction?
2. May one Israel-based developer and centrally managed API key serve invited adults internationally?
3. Do paid-tier requirements depend on the visitor’s current physical location, residence, developer/billing location or server location? In particular, must visitors in the UK/EU/EEA/Switzerland use a billing-enabled Gemini project, including during temporary travel?
4. What age, geographic-access and privacy notices or controls are required, and how do free and paid tiers differ for this use?

Please refer this enquiry to the Google team authorized to clarify the applicable terms if necessary. Live Gemini remains disabled in the beta pending clarification.

Thank you.
