#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export WRANGLER_SEND_METRICS=false NODE_USE_ENV_PROXY=0
state=$(mktemp -d)
seed=$(mktemp)
worker=''
port=$(node --input-type=module -e 'import net from "node:net"; const s=net.createServer(); s.listen(0,"127.0.0.1",()=>{console.log(s.address().port);s.close()});')
export HQ_BETA_TEST_ORIGIN=http://127.0.0.1:$port
cleanup(){ if [[ -n "$worker" ]]; then kill "$worker" 2>/dev/null || true; wait "$worker" 2>/dev/null || true; fi; rm -rf "$state"; rm -f "$seed"; }
trap cleanup EXIT
cat beta/schema.sql >"$seed"
node --input-type=module <<'JS' >>"$seed"
import {createHash} from 'node:crypto';
const now=Date.now(),hash=i=>createHash('sha256').update(i.toString(16).padStart(64,'0')).digest('hex');
for(let i=1;i<=8;i++){
 const active=i>=7,deadline=i===5?now-1000:now+600000;
 console.log(`INSERT INTO beta_invites VALUES ('guest-${i}','${hash(i+10*(+active))}',${deadline},${active?"'"+hash(i)+"'":'NULL'},${active?i===8?now-1000:now+600000:'NULL'},${[6,7].includes(i)?now:'NULL'});`);
}
JS
node_modules/.bin/wrangler d1 execute hebrew-quest-family-staging --local --config wrangler.jsonc --persist-to "$state" --file "$seed" >/dev/null
node_modules/.bin/wrangler dev --local --config dist/server/wrangler.json --persist-to "$state" --ip 127.0.0.1 --port "$port" --inspector-port 0 < <(sleep 180) > /tmp/hq-rebuilt-worker.log 2>&1 &
worker=$!
for i in {1..45}; do if curl --noproxy '*' -fsS "$HQ_BETA_TEST_ORIGIN/" >/dev/null 2>&1; then break; fi; sleep 1; done
node beta/check.mjs
