import { load } from 'cheerio/slim';
import {MAX_ARTICLE_CHARACTERS,ARTICLE_LIMIT_MESSAGE} from '../../lib/article-limits.ts';

const domains = ['globes.co.il','calcalist.co.il','ynet.co.il','timesofisrael.com'];
const agent = 'HebrewQuestReader/1.0 (personal article reading)';
const maxBytes = 3_000_000;
export function validateUrl(value:string) {
  const u = new URL(value);
  // Exact publisher hosts only; never fetch arbitrary subdomains or IP addresses.
  if (!['https:','http:'].includes(u.protocol) || u.username || u.password || u.port ||
    !domains.some(d => u.hostname === d || u.hostname === 'www.'+d || u.hostname === 'en.'+d)) {
    throw new Error('Use a Globes, Calcalist, Ynet or Times of Israel article URL.');
  }
  u.hash=''; return u;
}

async function readBounded(response:Response, limit=maxBytes) {
  const limitMessage=limit===maxBytes?'The publisher page exceeds the 3 MB download safety limit. Nothing was imported or shortened. Open the original article, or paste text you are permitted to use.':'Publisher access rules exceed the download safety limit. Open the original article, or paste permitted text.';
  if (Number(response.headers.get('content-length'))>limit) throw new Error(limitMessage);
  const reader=response.body?.getReader(); if(!reader) throw new Error('Empty publisher response.');
  const chunks:Uint8Array[]=[]; let size=0;
  try { while(true) {const {done,value}=await reader.read(); if(done) break; size+=value.length;
    if(size>limit) throw new Error(limitMessage); chunks.push(value);}
  } finally { await reader.cancel(); }
  const bytes=new Uint8Array(size); let offset=0; for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  const charset=response.headers.get('content-type')?.match(/charset=["']?([^\s;"']+)/i)?.[1] || 'utf-8';
  try{return new TextDecoder(charset).decode(bytes)}catch{return new TextDecoder().decode(bytes)}
}

// Respect the publisher's rules for this identified reader, including wildcard rules.
export function robotsAllowed(text:string,u:URL) {
  const groups:{agents:string[],rules:{allow:boolean,path:string}[]}[]=[];
  let group:{agents:string[],rules:{allow:boolean,path:string}[]}|null=null;
  for (const raw of text.split(/\r?\n/)) {
    const line=raw.split('#')[0].trim(); const colon=line.indexOf(':'); if(colon<0)continue;
    const key=line.slice(0,colon).trim().toLowerCase(),value=line.slice(colon+1).trim();
    if(key==='user-agent'){if(!group||group.rules.length){group={agents:[],rules:[]};groups.push(group)} group.agents.push(value.toLowerCase());}
    else if(group && ['allow','disallow'].includes(key) && value) group.rules.push({allow:key==='allow',path:value});
  }
  const named=groups.filter(g=>g.agents.some(a=>a!=='*'&&agent.toLowerCase().includes(a)));
  const matched=named.length?named:groups.filter(g=>g.agents.includes('*'));
  let best=-1,allowed=true; const path=u.pathname+u.search;
  for(const g of matched)for(const rule of g.rules){
    const escaped=rule.path.replace(/[.+?^{}()|[\]\\]/g,'\\$&').replace(/\*/g,'.*');
    const pattern='^'+escaped.replace(/\$$/,'$');
    if(new RegExp(pattern).test(path)){const length=rule.path.replace(/[*$]/g,'').length;
      if(length>best || (length===best&&rule.allow)){best=length;allowed=rule.allow;}}
  }
  return allowed;
}
async function checkRobots(u:URL,signal:AbortSignal) {
  const res=await fetch(new URL('/robots.txt',u),{headers:{'User-Agent':agent},redirect:'manual',signal});
  if(res.status===404) return;
  if(!res.ok) throw new Error(`Publisher access rules returned HTTP ${res.status}. Open the original article or paste text you are permitted to use.`);
  if(!robotsAllowed(await readBounded(res,500_000),u))throw new Error('The publisher disallows automated access to this URL. Use the original website or paste permitted text.');
}
export function extractArticle(html:string,url:string) {
  const $=load(html);
  // Never extract subscription text from JSON, hidden state, caches or alternate endpoints.
  let subscription=false;
  $('script[type="application/ld+json"]').each((_,el)=>{
    const raw=$(el).text();
    if(/"isAccessibleForFree"\s*:\s*(?:false|"false")/i.test(raw)) subscription=true;
  });
  if(subscription || $('[data-paywall="true"], [data-premium="true"]').length) throw new Error('This article is marked subscription-only. Importing cannot bypass its paywall.');
  const title=($('h1').first().text()||$('meta[property="og:title"]').attr('content')||'Imported article').replace(/\s+/g,' ').trim().slice(0,300);
  $('script,style,nav,footer,header,aside,form,iframe,noscript,svg,[hidden],[aria-hidden="true"],[style*="display:none"],[style*="display: none"]').remove();
  $('[class*="advert"],[class*="banner"],[class*="recommend"],[id*="advert"],[class*="related"],[class*="promo"],.ad,.ads,.ad-container,[role="navigation"],[role="complementary"],[data-ad],[data-ad-slot]').remove();
  // Scope first, then retain every non-empty visible paragraph in that body.
  // Length/language filters and text deduplication lose real quotations and endings.
  const blocks='p,.text_editor_paragraph,blockquote,li,h2,h3,h4';
  function paragraphsIn(root:ReturnType<typeof $>){
    const all=root.find(blocks).toArray(),blockNodes=new Set(all);
    const nodes=all.filter(el=>!$(el).parents().toArray().some(parent=>blockNodes.has(parent)));
    const ps:string[]=[];
    for(const el of nodes){let buffer='';
      const flush=()=>{const text=buffer.replace(/\s+/g,' ').trim();if(text)ps.push(text);buffer='';};
      const visit=(node:any)=>{if(node.type==='text'){buffer+=node.data;return;}if(node.type!=='tag')return;if(node.name==='br'){flush();return;}const block=$(node).is(blocks);if(block)flush();for(const child of node.children||[])visit(child);if(block)flush();};
      visit(el);flush();
    }
    return ps;
  }
  const selectors=['[itemprop="articleBody"],#articleBody,#ArticleBodyComponent','[class*="article-body"],[class*="articleBody"]','.text_editor,.text-editor,.textEditor_container','article'];
  let paragraphs:string[]=[];
  for(const selector of selectors){
    const candidates:string[][]=[];$(selector).each((_,el)=>{const ps=paragraphsIn($(el));if(/[א-ת]/.test(ps.join(' '))&&ps.join(' ').length>=180)candidates.push(ps);});
    if(candidates.length){paragraphs=candidates.sort((a,b)=>b.join(' ').length-a.join(' ').length)[0];break;}
  }
  // Publisher Draft.js blocks sometimes lack an article wrapper. Restrict this
  // fallback to those blocks; never collect arbitrary page-wide short text.
  if(!paragraphs.length){$('.text_editor_paragraph').filter((_,el)=>!$(el).parents('.text_editor_paragraph').length).each((_,el)=>{paragraphs.push(...paragraphsIn($('<div>').append($(el).clone())));});}
  if(paragraphs.join(' ').length<180||!/[א-ת]/.test(paragraphs.join(' '))) throw new Error('No accessible Hebrew article body found. The page may restrict importing; use the original website or paste permitted text.');
  if(paragraphs.join('\n').length>MAX_ARTICLE_CHARACTERS)throw new Error(ARTICLE_LIMIT_MESSAGE);
  return {title,paragraphs,url};
}
export async function importArticle(value:string) {
  let u=validateUrl(value);const signal=AbortSignal.timeout(20_000);
  for(let hop=0;hop<5;hop++){
    await checkRobots(u,signal);
    const res=await fetch(u,{headers:{'User-Agent':agent,'Accept':'text/html,application/xhtml+xml'},redirect:'manual',signal});
    if([301,302,303,307,308].includes(res.status)) {u=validateUrl(new URL(res.headers.get('location')||'',u).href);continue;}
    if(!res.ok)throw new Error(`Publisher returned HTTP ${res.status}. No access restriction was bypassed.`);
    if(!res.headers.get('content-type')?.toLowerCase().includes('html'))throw new Error('Publisher did not return an HTML article.');
    return extractArticle(await readBounded(res),u.href);
  }
  throw new Error('Too many publisher redirects.');
}
