# Importer optimization evaluation — 5 November 2026

Status: local candidate only. No Cloudflare deployment, billing change, live
Gemini request or production access. Current staging 28ea373f stays available.

The candidate combines repeated DOM-cleanup scans, avoids temporary ancestor
arrays and repeated selector checks, and selects the longest article candidate
without sorting and repeatedly joining full article text. All work remains on
the server. HTML parsing, all paragraphs, repeated quotations, headings, title,
robots rules, redirect/host validation, byte/character limits and paywall checks
are retained. No publisher-content cache or phone-side processing was introduced.

## Measurement

results.json contains 100 measured extraction runs and 50 measured complete
replayed-import runs per implementation per real article, after warm-up, with
alternating before/after execution order. All returned title/paragraph/URL objects
matched exactly. Each implementation completed 300/300 extraction and 150/150
replayed-import runs. The original source is retained in importer-before.ts for
reproducibility, with only its relative article-limits import adapted.

The short article is a recorded October 29 Ynet weather page (256 words), medium
is a November 5 snapshot of a political article (639 words), and long is a
November 5 snapshot of a US election article (1,689 words). These labels describe
this modest sample, not publisher-wide size categories. Results include source
URLs, HTML sizes, paragraph counts and SHA-256 hashes. Full publisher snapshots
are kept outside the repository and are not redistributed in source packages.

Node process CPU is not deployed Worker CPU. Replayed-import wall time includes
robots handling, reading/decoding and extraction but uses mocked fetch responses,
so it excludes internet latency, session/D1 overhead and browser rendering.
To reproduce, run run.mjs with HQ_IMPORT_BENCHMARK_DIR pointing to the three
snapshots named short.html, medium.html and long.html (no live AI is used).

live-network.json records one actual full import per sample per implementation,
including robots requests. Baseline: 2/3 succeeded, one 20-second timeout;
candidate: 3/3 succeeded. Order, connection reuse and proxy/network variation
confound those six observations: they do not demonstrate a reliability or
Samsung latency improvement. Do not infer causation or a production percentile.

## Validation and decision

TypeScript and production build passed. 33 new baseline-equivalence tests passed.
Full suite: 426 tests, 384 passed, 41 unchanged documented Sites/account-runtime
failures, one optional recorded fixture skipped. No newly failing tests.
Local Worker/D1 invitation, isolation and quota checks passed on a fresh rerun.
The first run returned a local 503 during an invitation test; it is recorded as
an intermittent local-runtime limitation, not dismissed as proof of reliability.
The optional recorded Ynet paragraph-equivalence check was also run separately
and passed, including its final paragraph.

Median CPU reduction is about 15–27% in this run. This is worthwhile, but not
proof that deployed CPU will drop below Workers Free's 10 ms allowance. Earlier
hosted imports measured 24 and 60 ms; hosted candidate CPU is unmeasured.
Recommend keeping the safe optimization, but prefer Workers Paid for predictable
family use if subsequent isolated staging measurements still exceed Free limits.
Do not enable billing or deploy without discussing these findings with the owner.
