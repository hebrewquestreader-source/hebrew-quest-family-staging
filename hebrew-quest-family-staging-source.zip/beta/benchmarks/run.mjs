import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import assert from 'node:assert/strict';import {performance} from 'node:perf_hooks';
const root=fileURLToPath(new URL('../../',import.meta.url));
const fixtures=process.env.HQ_IMPORT_BENCHMARK_DIR;if(!fixtures)throw Error('Set HQ_IMPORT_BENCHMARK_DIR to a local folder containing short.html, medium.html and long.html snapshots.');
const before=await import(root+'/beta/benchmarks/importer-before.ts'),after=await import(root+'/lib/importer.ts');
const samples=[{size:'short',path:path.join(fixtures,'short.html'),url:'https://www.ynet.co.il/news/article/rkk005oepfl'},{size:'medium',path:path.join(fixtures,'medium.html'),url:'https://www.ynet.co.il/news/article/h1ri3yeagx'},{size:'long',path:path.join(fixtures,'long.html'),url:'https://www.ynet.co.il/news/article/hjvukke6gl'}];
const percentile=(values,p)=>[...values].sort((a,b)=>a-b)[Math.floor((values.length-1)*p)];
const summary=values=>({medianMs:+percentile(values,.5).toFixed(3),p95Ms:+percentile(values,.95).toFixed(3)});
const output=[];
for(const sample of samples){
 const html=fs.readFileSync(sample.path,'utf8'),original=before.extractArticle(html,sample.url);assert.deepEqual(after.extractArticle(html,sample.url),original);
 const results={before:{cpu:[],wall:[],flow:[],flowCpu:[],successes:0},after:{cpu:[],wall:[],flow:[],flowCpu:[],successes:0}};
 for(let i=0;i<120;i++)for(const label of i%2?['before','after']:['after','before']){
  const api=label==='before'?before:after;const cpu=process.cpuUsage(),t=performance.now();const value=api.extractArticle(html,sample.url);const wall=performance.now()-t,used=process.cpuUsage(cpu);assert.deepEqual(value,original);
  if(i>=20){results[label].cpu.push((used.user+used.system)/1000);results[label].wall.push(wall);results[label].successes++;}
 }
 const native=globalThis.fetch;globalThis.fetch=async input=>String(input).endsWith('/robots.txt')?new Response('User-agent: *\nAllow: /'):new Response(html,{headers:{'Content-Type':'text/html; charset=utf-8'}});
 try{for(let i=0;i<70;i++)for(const label of i%2?['before','after']:['after','before']){const api=label==='before'?before:after;const cpu=process.cpuUsage(),t=performance.now();assert.deepEqual(await api.importArticle(sample.url),original);const wall=performance.now()-t,used=process.cpuUsage(cpu);if(i>=20){results[label].flow.push(wall);results[label].flowCpu.push((used.user+used.system)/1000);}}}finally{globalThis.fetch=native;}
 output.push({size:sample.size,url:sample.url,htmlBytes:Buffer.byteLength(html),words:original.paragraphs.join(' ').split(/\s+/).length,paragraphs:original.paragraphs.length,characters:original.paragraphs.join('\n').length,identical:true,...Object.fromEntries(Object.entries(results).map(([name,r])=>[name,{extractionCpu:summary(r.cpu),extractionWall:summary(r.wall),replayedImportCpu:summary(r.flowCpu),replayedImportWall:summary(r.flow),extractionSuccesses:r.successes,extractionRuns:100,replayedImportRuns:50}]))});
}
fs.writeFileSync(path.join(fixtures,'results.json'),JSON.stringify({environment:'Node.js '+process.version+' local container; CPU is process CPU, not Cloudflare invocation CPU. Replayed import includes decoding and robots checks with mocked network; excludes internet latency, D1/auth and phone rendering.',samples:output},null,2));console.log(JSON.stringify(output,null,2));
