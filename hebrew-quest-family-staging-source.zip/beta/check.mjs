import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const origin=process.env.HQ_BETA_TEST_ORIGIN;
const samples=JSON.parse(readFileSync('tests/fixtures/word-help-stability.json')).cases;
const get=(path,cookie,headers)=>fetch(origin+path,{headers:{...headers,...(cookie?{Cookie:cookie}:{})}});
const post=(path,value,cookie,from=origin)=>fetch(origin+path,{method:'POST',redirect:'manual',headers:{Origin:from,'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},body:JSON.stringify(value)});
const token=i=>i.toString(16).padStart(64,'0');
const redeem=i=>post('/beta/redeem',{token:token(i)});
const gate=await (await get('/')).text();assert.match(gate,/Invitation required/);assert.match(gate,/<a href="\/">Continue reading<\/a>/);
assert.equal((await get('/api/discover',null,{'oai-authenticated-user-id':'spoofed'})).status,401);
assert.equal((await get('/api/import')).status,401);
assert.equal((await post('/api/assist',samples[0].input)).status,401);
assert.equal((await post('/beta/redeem',{token:token(1)},null,'https://evil.invalid')).status,403);
assert.equal((await redeem(5)).status,403);
assert.equal((await redeem(6)).status,403);
assert.equal((await get('/api/discover','__Host-hq-beta='+token(7))).status,401);
assert.equal((await get('/api/discover','__Host-hq-beta='+token(8))).status,401);
const racing=await Promise.all([redeem(1),redeem(1)]);
assert.deepEqual(racing.map(r=>r.status).sort(),[200,403]);
function cookie(r){const header=r.headers.get('Set-Cookie');assert.match(header,/Path=\/; Secure; HttpOnly; SameSite=Strict; Max-Age=/);return header.split(';')[0];}
const a=cookie(racing.find(r=>r.ok)),b=cookie(await redeem(2)),c=cookie(await redeem(3)),d=cookie(await redeem(4));
assert.equal((await get('/api/articles',a)).status,404);
assert.equal((await get('/api/vocabulary',a)).status,404);
assert.equal((await post('/api/language/setup',{},a)).status,405);
const html=await (await get('/',a)).text();assert.match(html,/beta-storage.js/);assert.match(html,/guest-1/);assert.match(html,/Saved in this browser on this device/);assert.doesNotMatch(html,/Saved privately to your signed-in account/);
assert.match(await (await get('/',b)).text(),/guest-2/);
for(const word of ['נשענים','ליחידות'])for(const endpoint of ['assist','breakdown']){const response=await post('/api/'+endpoint,{tokens:[word],context:word+' על הקיר.'},d);assert.equal(response.status,422);const body=await response.json();assert.equal(body.code,'simulator_missing');assert.doesNotMatch(body.error,/key|rejected/i);}
const results=await Promise.all(Array.from({length:5},()=>post('/api/assist',samples[0].input,a)));
assert.deepEqual(results.map(r=>r.status).sort(),[200,200,200,200,429]);
for(const guest of [b])for(let i=0;i<4;i++)assert.equal((await post('/api/breakdown',samples[0].input,guest)).status,200);
for(const guest of [c,d])assert.equal((await post('/api/assist',samples[0].input,guest)).status,429);
const out=await post('/beta/sign-out',{},a);assert.equal(out.status,303);
assert.equal((await get('/api/discover',a)).status,401);
assert.equal((await redeem(1)).status,403);
console.log('Worker: access gate, CSRF, expiry, revocation, concurrent redemption, cookie flags, local-only routes, mocked AI, atomic guest/global minute quotas, sign-out');

const storage=new Map(),clientSource=readFileSync('public/beta-storage.js','utf8');
function client(id){
 const context=vm.createContext({HQ_ACCOUNT:{id},Response,URL,crypto,location:{origin},localStorage:{getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},fetch:()=>{throw Error('Browser-local data must not go to the server.');}});
 vm.runInContext(clientSource,context);return context;
}
const first=client('first'),second=client('second');
const save=(browser,path,body)=>browser.fetch(path,{method:'POST',body:JSON.stringify(body)});
assert.equal((await save(first,'/api/vocabulary',{expression:'שלום',examples:[{expression:'שלום',sentence:'שלום לכם.'}]})).status,200);
const stored=await (await save(first,'/api/articles',{title:'חדשות',url:'https://example.invalid',paragraphs:['טקסט'],readingPosition:{index:4}})).json();
assert.equal((await (await client('first').fetch('/api/articles?id='+stored.id)).json()).article.readingPosition.index,4);
assert.equal((await (await second.fetch('/api/articles?id='+stored.id)).json()).article,null);
assert.equal((await (await second.fetch('/api/vocabulary')).json()).entries.length,0);
assert.equal((await (await client('first').fetch('/api/vocabulary')).json()).entries.length,1);
console.log('Browser storage simulation: reload persistence, guest isolation, no network writes');
