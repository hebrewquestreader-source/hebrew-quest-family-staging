CREATE TABLE IF NOT EXISTS beta_invites (
 id TEXT PRIMARY KEY, token_hash TEXT NOT NULL UNIQUE, redeem_until INTEGER NOT NULL,
 session_hash TEXT UNIQUE, session_until INTEGER, revoked_at INTEGER
);
CREATE TABLE IF NOT EXISTS language_limits (
 bucket TEXT PRIMARY KEY NOT NULL, hits INTEGER NOT NULL, expires_at INTEGER NOT NULL
);
