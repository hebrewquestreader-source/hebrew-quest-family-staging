## Update: three data-saving fixes verified locally

All three release-gate reproductions below now pass. The beta adapter preserves
newer timestamped reading positions while allowing genuine later backward reading;
enrichment requires the current record ID and creation time, which are retained
through manual AI analysis and its recovery journal; and the reading-position
notice remains a failure until a successful durable retry.

31/31 focused beta tests pass. Full suite: 450 tests, 408 passed, the same 41
legacy failures, one optional publisher-fixture skipped. TypeScript and production
build pass. Fresh local Worker/D1 invitation, isolation and quota checks pass.
No application was deployed and no original-site files/data, hosting plan,
billing settings, live AI or invitations were changed. The earlier assessment
below is retained as history, not the current fixed-code test result.

Remaining before family launch: Gemini eligibility clarification and international
adult/privacy/location requirements; explicit hosting/deployment and live-AI
approval; bounded actual-provider tests and hosted security/quota/importer checks;
Samsung verification of the newly fixed saving paths. No claim that all 41 old
account tests are resolved or that live-provider reliability is proven.

---

# Guest beta test assessment — 5 November 2026

Scope: local tests only, mocked AI, isolated SQLite/D1. No hosting, production,
billing, invitation distribution, external contact or deployment changes.
Importer optimization remains retained on the local evaluation branch.

## Results

27 beta tests: 24 passed, 3 failed. Full suite: 446 tests, 401 passed,
44 failed (41 unchanged inherited tests plus 3 new release-gate reproductions),
1 optional publisher-fixture test skipped. The recorded publisher equivalence
check passed separately in the importer evaluation. Actual local Worker/D1
smoke checks passed: unauthenticated rejection, spoofed identity rejection,
CSRF, expiry, revocation, concurrent single-use redemption, cookie flags,
local-only data routes, simulator misses, guest/global minute quotas and signout.
No claim is made about hosted revocation/isolation/daily quota verification.

New coverage includes real beta session functions with SQLite: hashed sessions,
forged/malformed/revoked/expired credentials, cross-origin requests, one-use
redemption, signout isolation, persistent daily guest/global quotas, rollover,
concurrent quota admission and URL fragment removal before redemption.

The actual beta storage adapter and shipped UI scripts were tested for guest
namespacing, cross-guest application read/review/delete refusal, save without
AI, dedupe, enrichment, dates/source/context retention, review/delete persistence,
exact article/paragraph recovery, changed articles, anchor mismatch, unavailable
browser storage and retained unreadable recovery data. These are DOM simulations,
not an independent browser security audit or Samsung performance measurements.
Namespaces do not provide encryption or protection from someone inspecting the
same browser profile. Server article/vocabulary routes are not exposed.

## Three genuine risks reproduced from legacy coverage

1. Old reading-position writes overwrite newer positions in the beta adapter.
   Related legacy test: "positions remain private, and an older retried position
   cannot overwrite a newer account position". Guest isolation passes, but stale
   ordering protection does not. Relevant to multiple tabs and delayed recovery.
2. Late enrichment can overwrite a replacement record of the same word after
   delete/re-save. Related legacy test: "failed, unrelated, cross-account or late
   enrichment cannot replace or resurrect the original entry". A deleted word
   with no replacement is not resurrected, and cross-guest operations fail; the
   delete/recreate generation boundary remains missing.
3. Storage failures trigger an explicit recovery warning and block safe leaving,
   but ReaderContinuity.record then overwrites its own failure notice with
   "Reading place is saved automatically by paragraph." Related legacy test:
   "storage failures are not presented as device/account saves and block unsafe
   sign-out". The contradictory saved notice is a real UX/data-loss risk.

All three desired-safety tests remain normal failing tests, not skipped or
rewritten to accept current behavior. Application code was not changed in this
assessment. Fixes are required before launch.

## What the 41 inherited failures mean

The original test harness sends Sites identity headers and expects server account
storage; the family beta requires an invitation cookie and keeps data local.
Many old route tests therefore stop at 401 instead of testing their named
behavior. Unchanged failure names do not prove unchanged underlying safety.

Original-owner migration, personal key setup, Google/ChatGPT sign-in, cross-device
account sync, original account UI, server challenge drafts/completion tracking
and background preparation policy are outside the present guest-beta scope.
Their old tests are not evidence of a failure in invitation authentication.
Other old tests cover applicable outcomes: guest isolation, saves without AI,
deduplication, paragraph restoration, recovery-data retention and quotas. These
now have beta-specific checks above, with the three reproduced failures kept
explicit. Live provider failures/retries, actual token spending, arbitrary-word
linguistic output and hosted session/quota behavior remain unverified here.

## Google enquiry channel

Official starting point: https://discuss.ai.google.dev/c/gemini-api/4
Google staff on that forum have declined binding contractual interpretations:
https://discuss.ai.google.dev/t/request-for-written-clarification-gemini-api-use-in-a-commercial-consumer-music-app/196639
Request escalation to the team authorized to interpret the terms. No dedicated
public private-address or guaranteed binding-clarification process was verified.
Do not invent an email address or imply community advice is authorization.
Nothing was submitted or sent.
