# Approved mock-only staging release — 5 November 2026

Target: hebrew-quest-family-staging only.

Candidate source: 796e505bc76959990c108d250f49ba01f4aae489.
Archive SHA-256: c77f8ef9dc22dc39181c7d82d11464249cad4057ce6bfeb93b7cc473c9f5e0a6.
GitHub release commit: 0320c539a993caf4eec9efa83aaa005d700cdc00.
Cloudflare build: 47adc712-cc81-423d-8d7d-8e5d0939d3a8.

Pre-release active Worker: 28ea373f-7b93-4e5b-9864-e558a0065c23, 100% traffic, reconfirmed in dashboard immediately before commit.
Rollback source retained in GitHub commit 9dffc585e3fd87e083ab43641e5bd56a2217af39 and separate preserved source ZIP.
Previous Worker versions retained in Cloudflare deployment/rollout history.

Preflight: 64/64 beta and importer tests rerun successfully; production build, TypeScript and local Worker/D1 security checks passed earlier in this release session. 41 inherited full-suite failures remain documented.
No schema/configuration diff from previous staging source. No production data migration.
Gemini metered transport uses mockGemini unconditionally; no live key is used.
Original Hebrew Quest, billing and family invitations untouched.

Cloudflare build completed successfully; active version 8b772e3c confirmed Ready and serving 100% of staging traffic. Previous version 28ea373f remains Ready in deployment history. GitHub build status is success; uploaded ZIP displayed as 644 KB, consistent with candidate size.

Hosted checks: fresh root load and Continue reading in a browser without a beta invitation both retain the invitation-required gate and simulated-help notice. No new invitation or owner-session transfer was performed. No important failure was observed, so rollback was not triggered.

Limits: this desktop has no existing beta invitation session. Authenticated Reader, importing, vocabulary and saved-progress acceptance must be checked using the existing Samsung session; these behaviors passed local tests but have not been claimed as hosted acceptance. New hosted importer CPU/latency benchmark is not available. A terminal read of an asset was blocked with HTTP 403 and was not counted as an application regression.

Single Samsung acceptance check: reload the existing staging tab, open Vocabulary and confirm saved הודיעה still appears with its existing review status. Do not clear browser storage.

