import {env} from 'cloudflare:workers';
import {AssistanceError} from './language';
import type {Account} from './accounts';
import {betaSession} from './beta-session';
import {admit,quotaBuckets} from './beta-quota';
import {mockGemini} from './beta-mock';
export type {Account};
function db(){if(!env.DB)throw new AssistanceError('setup_unavailable','Beta storage unavailable.',503);return env.DB;}
export async function requireAccount(request:Request,mutation=true):Promise<Account>{
 if(mutation&&request.headers.get('Origin')!==new URL(request.url).origin)throw new AssistanceError('bad_origin','Use this beta page.',403);
 const guest=await betaSession(db(),request);
 if(!guest)throw new AssistanceError('sign_in','A current invitation is required.',401);
 return {id:guest.id,email:'Beta guest',dataOwner:'beta:'+guest.id,keyId:guest.id,legacyOwner:false,preferences:{wordBreakdown:true,prepareAhead:false},preferencesSet:true};
}
export async function isConfigured(_account:Account){return true;}
export async function getLanguageKey(_account:Account){return 'mock-not-a-credential';}
export async function saveLanguageKey(_account:Account,_key:string){throw new AssistanceError('disabled','Beta only.',403);}
export async function removeLanguageKey(_account:Account){throw new AssistanceError('disabled','Beta only.',403);}
export async function quotaUsage(account:Account){
 const buckets=quotaBuckets(account.id,Date.now());
 const rows=await db().prepare('SELECT bucket,hits FROM language_limits WHERE bucket IN (?,?,?,?)').bind(...buckets.map(x=>x.bucket)).all<{bucket:string;hits:number}>();
 return buckets.map(({bucket,...info})=>({...info,used:rows.results.find(row=>row.bucket===bucket)?.hits||0}));
}
export function preparationPolicy(_account:Account){return {reservePercent:100,backgroundDailyCeiling:0,backgroundMinuteCeiling:0};}
export async function takeQuota(account:Account,_kind='assist',priority:'interactive'|'background'='interactive'){
 if(priority==='background')throw new AssistanceError('background_paused','Background language preparation is disabled.',429);
 if(await admit(db(),account.id,Date.now()))return;
 const blocked=(await quotaUsage(account)).filter(x=>x.used>=x.limit).sort((a,b)=>b.resetAt-a.resetAt)[0];
 if(!blocked)throw new AssistanceError('sign_in','A current invitation is required.',401);
 const error=new AssistanceError('local_quota','Beta language help is temporarily unavailable.',429);
 error.quota={source:'application',...blocked};error.retryAt=blocked.resetAt;throw error;
}
export function meteredFetch(account:Account,_service:string,kind='assist',_fetcher:typeof fetch=fetch,priority:'interactive'|'background'='interactive'):typeof fetch{
 return async(input,init)=>{await takeQuota(account,kind,priority);return mockGemini(input,init);};
}
