const aad=new TextEncoder().encode('hebrew-quest/gemini-key/v1');
function decode(s:string){return Uint8Array.from(atob(s),c=>c.charCodeAt(0));}
function encode(b:Uint8Array){return btoa(String.fromCharCode(...b));}
async function aes(secret:string){
  if(!/^[0-9a-f]{64}$/.test(secret))throw new Error('Language key encryption is not configured.');
  return crypto.subtle.importKey('raw',Uint8Array.from(secret.match(/../g)!,c=>parseInt(c,16)),{name:'AES-GCM'},false,['encrypt','decrypt']);
}
export async function encryptKey(value:string,secret:string){
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:aad},await aes(secret),new TextEncoder().encode(value));
  return JSON.stringify({v:1,iv:encode(iv),ciphertext:encode(new Uint8Array(ciphertext))});
}
export async function decryptKey(value:string,secret:string){
  const data=JSON.parse(value);if(data.v!==1)throw new Error('Unknown key encryption version.');
  return new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:decode(data.iv),additionalData:aad},await aes(secret),decode(data.ciphertext)));
}
