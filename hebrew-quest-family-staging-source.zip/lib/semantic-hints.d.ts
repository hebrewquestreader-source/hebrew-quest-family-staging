export const SemanticHints:{validate(text:string,input:{expression:string;mode?:string;answer?:string}):string;pair(value:any,input:{expression:string;mode?:string;answer?:string}):{hints:string[]}};
