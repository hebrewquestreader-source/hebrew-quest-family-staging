import {HebrewText} from './hebrew-text.js';
export class VocabularyError extends Error {}
// Account-scoped records. Exact article forms and contextual examples stay separate from lemmas.
export type VocabularyExample={sourceType?:string;expression:string;nikud:string;translation:string;sentence:string;title:string;url:string;savedAt:string};
export type VocabularyEntry={id?:string;incomplete?:boolean;validationNote?:string;quarantined?:Record<string,string>;expression:string;nikud:string;translation:string;lemma:string;lemmaTranslation:string;status:'needs_review'|'recognised';createdAt:string;updatedAt:string;examples:VocabularyExample[]};
export function vocabularyKey(text:string){return text.normalize('NFD').replace(/[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]/g,'').normalize('NFC').replace(/^[\s.,!?;:״׳"'()\[\]{}–—־-]+|[\s.,!?;:״׳"'()\[\]{}–—־-]+$/g,'').replace(/\s+/g,' ').toLowerCase();}
function text(v:unknown,max:number,required=false){if(typeof v!=='string'||v.length>max||(required&&!v.trim()))throw new VocabularyError('The vocabulary record has missing or oversized text.');return v.trim();}
function date(v:unknown){const s=text(v,40,true);if(!Number.isFinite(Date.parse(s)))throw new VocabularyError('Invalid vocabulary date.');return new Date(s).toISOString();}
export function validateVocabulary(value:unknown):VocabularyEntry{
 const v=value as VocabularyEntry;if(!v||typeof v!=='object')throw new VocabularyError('Invalid vocabulary entry.');
 const expression=text(v.expression,600,true);if(!/[א-ת]/.test(expression)||!vocabularyKey(expression))throw new VocabularyError('Save a Hebrew word or expression.');
 if(!['needs_review','recognised'].includes(v.status))throw new VocabularyError('Invalid review status.');
 if(!Array.isArray(v.examples)||v.examples.length<1||v.examples.length>20)throw new VocabularyError('Each entry must have 1–20 sentence examples per request.');
 const examples=v.examples.map(e=>{
  if(!e||typeof e!=='object')throw new VocabularyError('Invalid sentence example.');
  const sourceType=e.sourceType??'article';if(!['article','comprehension','hint','vocabulary','application','feedback','review','instruction'].includes(sourceType))throw new VocabularyError('Invalid vocabulary source type.');
  const original=text(e.expression,600,true),sentence=text(e.sentence,16000,true);
  if(vocabularyKey(original)!==vocabularyKey(expression)||!vocabularyKey(sentence).includes(vocabularyKey(original)))throw new VocabularyError('The sentence must contain the saved expression.');
  const url=text(e.url,2048);if(url){const u=new URL(url);if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw new VocabularyError('Use a safe http(s) source URL.');}
  const nikud=text(e.nikud,1200);if(nikud&&!HebrewText.validNikud(original,nikud))throw new VocabularyError('Invalid nikud: it must match the exact selected text and contain only valid marks.');
  return {expression:original,nikud:nikud.normalize('NFC'),translation:text(e.translation,700),sentence,sourceType,title:text(e.title,300,true),url,savedAt:date(e.savedAt)};
 });
 const nikud=text(v.nikud,1200),lemma=text(v.lemma,700);if(nikud&&!HebrewText.validNikud(expression,nikud))throw new VocabularyError('Invalid nikud: the exact selected text must be retained.');
 try{HebrewText.validate(lemma,{source:expression,mixed:true});}catch{throw new VocabularyError('Invalid Hebrew characters in the dictionary form. Nothing was silently stripped.');}
 if(!HebrewText.related(expression,lemma))throw new VocabularyError('The dictionary form is unrelated to the exact selected expression.');
 return {expression,nikud:nikud.normalize('NFC'),translation:text(v.translation,700),lemma:lemma.normalize('NFC'),lemmaTranslation:text(v.lemmaTranslation,700),incomplete:!!v.incomplete||!nikud||!v.translation,status:v.status,createdAt:date(v.createdAt),updatedAt:date(v.updatedAt),examples};
}
async function hash(value:string){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))].map(n=>n.toString(16).padStart(2,'0')).join('');}
export async function saveVocabulary(db:D1Database,owner:string,entry:VocabularyEntry){
 const id=await hash(owner+'\n'+vocabularyKey(entry.expression));
 const exists=await db.prepare('SELECT id FROM vocabulary_entries WHERE id=? AND owner=?').bind(id,owner).first();
 if(!exists){const count=await db.prepare('SELECT COUNT(*) AS n FROM vocabulary_entries WHERE owner=?').bind(owner).first<{n:number}>();if((count?.n||0)>=2000)throw new VocabularyError('Your bank has reached 2,000 expressions. Export a backup before removing entries.');}
 const statements=[db.prepare(`INSERT INTO vocabulary_entries (id,owner,expression,nikud,translation,lemma,lemma_translation,incomplete,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)
 ON CONFLICT(id) DO UPDATE SET expression=excluded.expression,nikud=COALESCE(NULLIF(excluded.nikud,''),nikud),translation=COALESCE(NULLIF(excluded.translation,''),translation),lemma=COALESCE(NULLIF(excluded.lemma,''),lemma),lemma_translation=COALESCE(NULLIF(excluded.lemma_translation,''),lemma_translation),incomplete=CASE WHEN COALESCE(NULLIF(excluded.nikud,''),nikud)<>'' AND COALESCE(NULLIF(excluded.translation,''),translation)<>'' THEN 0 ELSE 1 END,updated_at=excluded.updated_at`).bind(id,owner,entry.expression,entry.nikud,entry.translation,entry.lemma,entry.lemmaTranslation,entry.incomplete?1:0,entry.status,entry.createdAt,new Date().toISOString())];
 for(const e of entry.examples){const exampleId=await hash(id+'\n'+e.url+'\n'+e.title+'\n'+e.sentence+(e.sourceType&&e.sourceType!=='article'?'\n'+e.sourceType:'' ));statements.push(db.prepare(`INSERT INTO vocabulary_examples (id,entry_id,owner,expression,nikud,translation,sentence,source_type,title,url,saved_at) VALUES (?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET nikud=COALESCE(NULLIF(excluded.nikud,''),nikud),translation=COALESCE(NULLIF(excluded.translation,''),translation)`).bind(exampleId,id,owner,e.expression,e.nikud,e.translation,e.sentence,e.sourceType||'article',e.title,e.url,e.savedAt));}
 // A single entry and its examples are committed together.
 await db.batch(statements);return {id,merged:!!exists};
}
export async function enrichVocabulary(db:D1Database,owner:string,entry:VocabularyEntry){
 const id=await hash(owner+'\n'+vocabularyKey(entry.expression));
 const exists=await db.prepare('SELECT id FROM vocabulary_entries WHERE id=? AND owner=?').bind(id,owner).first();if(!exists)throw new VocabularyError('The original vocabulary entry is unavailable. It has not been recreated.');
 const statements=[db.prepare("UPDATE vocabulary_entries SET nikud=COALESCE(NULLIF(?,''),nikud),translation=COALESCE(NULLIF(?,''),translation),lemma=COALESCE(NULLIF(?,''),lemma),lemma_translation=COALESCE(NULLIF(?,''),lemma_translation),updated_at=? WHERE id=? AND owner=? AND expression=?").bind(entry.nikud,entry.translation,entry.lemma,entry.lemmaTranslation,new Date().toISOString(),id,owner,entry.expression)];
 for(const e of entry.examples){const exampleId=await hash(id+'\n'+e.url+'\n'+e.title+'\n'+e.sentence+(e.sourceType&&e.sourceType!=='article'?'\n'+e.sourceType:''));statements.push(db.prepare("UPDATE vocabulary_examples SET nikud=COALESCE(NULLIF(?,''),nikud),translation=COALESCE(NULLIF(?,''),translation) WHERE id=? AND owner=? AND expression=?").bind(e.nikud,e.translation,exampleId,owner,e.expression));}
 statements.push(db.prepare("UPDATE vocabulary_entries SET incomplete=CASE WHEN nikud<>'' AND translation<>'' THEN 0 ELSE 1 END WHERE id=? AND owner=?").bind(id,owner));await db.batch(statements);return {id,merged:true};
}
export async function listVocabulary(db:D1Database,owner:string):Promise<VocabularyEntry[]>{
 const entries=await db.prepare('SELECT * FROM vocabulary_entries WHERE owner=? ORDER BY updated_at DESC').bind(owner).all<Record<string,string>>();
 const examples=await db.prepare('SELECT * FROM vocabulary_examples WHERE owner=? ORDER BY saved_at DESC').bind(owner).all<Record<string,string>>();
 const grouped=new Map<string,VocabularyExample[]>();for(const e of examples.results){if(!grouped.has(e.entry_id))grouped.set(e.entry_id,[]);grouped.get(e.entry_id)!.push({expression:e.expression,nikud:e.nikud,translation:e.translation,sentence:e.sentence,sourceType:e.source_type||'article',title:e.title,url:e.url,savedAt:e.saved_at});}
 return entries.results.map(e=>HebrewText.vocabulary({id:e.id,incomplete:Number(e.incomplete)===1,expression:e.expression,nikud:e.nikud,translation:e.translation,lemma:e.lemma,lemmaTranslation:e.lemma_translation,status:e.status as VocabularyEntry['status'],createdAt:e.created_at,updatedAt:e.updated_at,examples:grouped.get(e.id)||[]}));
}
export async function changeVocabulary(db:D1Database,owner:string,id:string,status?:string,review=false){
 if(!/^[a-f0-9]{64}$/.test(id))throw new VocabularyError('Invalid vocabulary ID.');
 if(status!==undefined){if(!['needs_review','recognised'].includes(status))throw new VocabularyError('Invalid review status.');if(review){const entry=await db.prepare('SELECT id FROM vocabulary_entries WHERE id=? AND owner=?').bind(id,owner).first();if(!entry)throw new VocabularyError('That expression was not found in your bank.');const at=new Date().toISOString();await db.batch([db.prepare('UPDATE vocabulary_entries SET status=?,updated_at=? WHERE id=? AND owner=?').bind(status,at,id,owner),db.prepare('INSERT INTO vocabulary_reviews (id,owner,entry_id,status,reviewed_at) VALUES (?,?,?,?,?)').bind(crypto.randomUUID(),owner,id,status,at)]);}else await db.prepare('UPDATE vocabulary_entries SET status=?,updated_at=? WHERE id=? AND owner=?').bind(status,new Date().toISOString(),id,owner).run();}
 else await db.batch([db.prepare('DELETE FROM vocabulary_reviews WHERE entry_id=? AND owner=?').bind(id,owner),db.prepare('DELETE FROM vocabulary_examples WHERE entry_id=? AND owner=?').bind(id,owner),db.prepare('DELETE FROM vocabulary_entries WHERE id=? AND owner=?').bind(id,owner)]);
}
