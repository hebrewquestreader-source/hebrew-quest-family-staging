import {AssistanceError} from './language.ts';
import fixtures from '../tests/fixtures/word-help-stability.json' with {type:'json'};
export const mockGemini:typeof fetch=async(input,init)=>{
 const url=new URL(typeof input==='string'?input:input instanceof URL?input.href:input.url);
 if(url.hostname!=='generativelanguage.googleapis.com')return new Response('No mock available',{status:404});
 const envelope=JSON.parse(String(init?.body)),source=JSON.parse(envelope.contents[0].parts[0].text);
 const sample=fixtures.cases.find(row=>row.input.tokens.join(' ')===source.tokens?.join(' '));
 if(!sample)throw new AssistanceError('simulator_missing','This staging test has no simulated help for this selection. Live language assistance is disabled.',422);
 const value=envelope.generationConfig?.responseSchema?.properties?.selected?sample.breakdown:sample.assist;
 const body={candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(value)}]}}]};
 return url.pathname.endsWith(':streamGenerateContent')?new Response('data: '+JSON.stringify(body)+'\n\n'):Response.json(body);
};
