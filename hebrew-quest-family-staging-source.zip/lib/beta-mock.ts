import fixtures from '../tests/fixtures/word-help-stability.json';
export const mockGemini:typeof fetch=async(input,init)=>{
 const url=new URL(typeof input==='string'?input:input instanceof URL?input.href:input.url);
 if(url.hostname!=='generativelanguage.googleapis.com')return new Response('No mock available',{status:404});
 const envelope=JSON.parse(String(init?.body)),source=JSON.parse(envelope.contents[0].parts[0].text);
 const sample=fixtures.cases.find(row=>row.input.tokens.join(' ')===source.tokens?.join(' '));
 if(!sample)return new Response('No fixture for this selection',{status:400});
 const value=envelope.generationConfig?.responseSchema?.properties?.selected?sample.breakdown:sample.assist;
 const body={candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(value)}]}}]};
 return url.pathname.endsWith(':streamGenerateContent')?new Response('data: '+JSON.stringify(body)+'\n\n'):Response.json(body);
};
