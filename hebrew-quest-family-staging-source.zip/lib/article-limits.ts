// Bound complete article text, never a paragraph count or a silent excerpt.
export const MAX_ARTICLE_CHARACTERS=120000;
export const ARTICLE_LIMIT_MESSAGE='This article exceeds the 120,000-character text safety limit. Nothing was imported or shortened. Open the original article, or paste a shorter section you are permitted to use.';
