// Diagnostics contain field/reason codes only, never selected text, provider bodies or keys.
const malformed=new Set(['invalid_result','invalid_hebrew','incomplete_result','invalid_breakdown']);
export function retryable(error:any){return malformed.has(error?.code)||['provider_unavailable','breakdown_unavailable'].includes(error?.code)&&[408,500,502,503,504].includes(error?.status);}
export function diagnostic(error:any,code='invalid_result'){
 const message=error instanceof Error?error.message:'',candidate=error?.field||message.match(/^(hint|lemma|root|tokens\.nikud|parts\.text)\b/)?.[1]||'analysis',field=['hint','lemma','root','tokens.nikud','tokens.original','parts.text','lemmaMeaning','parts.meaning','features','selected','analysis'].includes(candidate)?candidate:'analysis';
 const unicode=message.match(/U\+[0-9A-F]{4,6}/i)?.[0]?.toUpperCase();
 return {code:typeof code==='string'&&/^[a-z_]{1,40}$/.test(code)?code:'invalid_result',field,reason:unicode?'unicode':/root/i.test(message)?'root_notation':/punctuation/i.test(message)?'alignment':/incomplete|readable/i.test(message)?'incomplete':'validation',...(unicode?{unicode}:{})};
}
export function analysisFailure(code:string){return malformed.has(code);}
