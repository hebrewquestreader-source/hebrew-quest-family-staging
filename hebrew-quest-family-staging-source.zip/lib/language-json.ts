// Read only complete top-level fields of a partially streamed JSON object.
// Nested values and quoted strings cannot impersonate top-level keys.
export function completeJsonFields(text:string):Record<string,unknown>{
 const result:Record<string,unknown>={};let i=0;
 const space=()=>{while(/\s/.test(text[i]||'')&&i<text.length)i++;};
 function endValue(start:number){
  let quoted=false,escaped=false,depth=0;const compound=['[','{'].includes(text[start]);
  for(let p=start;p<text.length;p++){
   const c=text[p];if(quoted){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"'){quoted=false;if(!compound&&text[start]==='"')return p+1;}continue;}
   if(c==='"'){quoted=true;continue;}if(c==='['||c==='{')depth++;
   else if(c===']'||c==='}'){if(depth>0){depth--;if(compound&&depth===0)return p+1;}else return p;}
   else if(c===','&&depth===0)return p;
  }
  return -1;
 }
 space();if(text[i++]!=='{')return result;
 while(i<text.length){space();if(text[i]==='}')break;if(text[i]!== '"')break;
  const keyEnd=endValue(i);if(keyEnd<0)break;let key:string;try{key=JSON.parse(text.slice(i,keyEnd));}catch{break;}i=keyEnd;space();if(text[i++]!==':')break;space();
  const valueEnd=endValue(i);if(valueEnd<0)break;
  try{const value=JSON.parse(text.slice(i,valueEnd));if(key!=='__proto__'&&key!=='constructor'&&key!=='prototype')result[key]=value;}catch{break;}
  i=valueEnd;space();if(text[i]!==',')break;i++;
 }
 return result;
}
