import {analysisFailure,diagnostic} from './language-recovery.ts';
import { AssistanceError } from './language.ts';
export const privateHeaders={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
export async function boundedJson(request:Request,max=10000){
  if(!request.headers.get('content-type')?.includes('application/json'))throw new AssistanceError('invalid_request','Send a JSON request.',415);
  if(Number(request.headers.get('content-length'))>max)throw new AssistanceError('request_too_large','The selection is too large.',413);
  const reader=request.body?.getReader();if(!reader)throw new AssistanceError('invalid_request','Empty request.');
  let size=0;const chunks:Uint8Array[]=[];
  try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>max)throw new AssistanceError('request_too_large','The selection is too large.',413);chunks.push(value);}}finally{await reader.cancel();}
  const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}
  try{return JSON.parse(new TextDecoder().decode(bytes));}catch{throw new AssistanceError('invalid_request','The request was not readable.');}
}
export function languageErrorBody(error:unknown){if(error instanceof AssistanceError){if(analysisFailure(error.code))console.warn(JSON.stringify({event:'language_analysis_failure',...(error.diagnostic||diagnostic(error,error.code)),attempts:error.retryCount===1?2:1}));return {error:analysisFailure(error.code)?"Couldn't analyse this word. Try again.":error.message,code:error.code,...(error.quota?{quota:error.quota}:{}),...(error.retryAt?{retryAt:error.retryAt}:{}),...(analysisFailure(error.code)?{diagnostic:error.diagnostic||diagnostic(error,error.code)}:{}),...(error.retryCount?{retryCount:1}:{})};}return {error:'Language assistance is temporarily unavailable. Please retry.',code:'unavailable'};}
export function languageFailure(error:unknown){
  if(error instanceof AssistanceError)return Response.json(languageErrorBody(error),{status:error.status,headers:{...privateHeaders,...(error.retryAt?{'Retry-After':String(Math.max(0,Math.ceil((error.retryAt-Date.now())/1000)))}:{})}});
  return Response.json({error:'Language assistance is temporarily unavailable. Please retry.',code:'unavailable'},{status:503,headers:privateHeaders});
}
