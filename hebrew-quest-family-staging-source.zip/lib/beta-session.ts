const name='__Host-hq-beta';
const tokenPattern=/^[0-9a-f]{64}$/;
const headers={'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff'};
export const betaJson=(value:unknown,status=200)=>Response.json(value,{status,headers});
function hex(bytes:Uint8Array){return Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');}
export async function hashToken(token:string){return hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token))));}
export async function betaSession(db:D1Database,request:Request){
 const value=request.headers.get('Cookie')?.split(/;\s*/).find(x=>x.startsWith(name+'='))?.slice(name.length+1);
 if(!value||!tokenPattern.test(value))return null;
 return db.prepare('SELECT id FROM beta_invites WHERE session_hash=? AND session_until>? AND revoked_at IS NULL').bind(await hashToken(value),Date.now()).first<{id:string}>();
}
function cookie(value:string,age:number){return name+'='+value+'; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age='+age;}
function verifyPost(request:Request){
 if(request.method!=='POST')return betaJson({error:'Use POST.'},405);
 if(request.headers.get('Origin')!==new URL(request.url).origin)return betaJson({error:'Open the invitation on this site.'},403);
}
export async function redeem(db:D1Database,request:Request){
 const denied=verifyPost(request);if(denied)return denied;
 if(request.headers.get('Content-Type')?.split(';')[0]!=='application/json')return betaJson({error:'Invalid invitation.'},400);
 const reader=request.body?.getReader();if(!reader)return betaJson({error:'Invalid invitation.'},400);
 let text='',bytes=0;
 try{
  const decoder=new TextDecoder();
  for(;;){const {value,done}=await reader.read();if(done)break;bytes+=value.byteLength;if(bytes>256)return betaJson({error:'Invalid invitation.'},400);text+=decoder.decode(value,{stream:true});}
  text+=decoder.decode();
 }catch{return betaJson({error:'Invalid invitation.'},400);}
 finally{await reader.cancel().catch(()=>{});}
 let token;try{token=JSON.parse(text)?.token;}catch{}
 if(typeof token!=='string'||!tokenPattern.test(token))return betaJson({error:'Invalid invitation.'},400);
 if(await betaSession(db,request))return betaJson({error:'Sign out before using a new invitation.'},409);
 const secret=hex(crypto.getRandomValues(new Uint8Array(32))),now=Date.now(),age=604800;
 const row=await db.prepare('UPDATE beta_invites SET session_hash=?,session_until=? WHERE token_hash=? AND redeem_until>? AND revoked_at IS NULL AND session_hash IS NULL RETURNING id')
 .bind(await hashToken(secret),now+age*1000,await hashToken(token),now).first();
 if(!row)return betaJson({error:'This invitation is expired, used, or revoked.'},403);
 return Response.json({ok:true},{headers:{...headers,'Set-Cookie':cookie(secret,age)}});
}
export async function signOut(db:D1Database,request:Request){
 const denied=verifyPost(request);if(denied)return denied;
 const guest=await betaSession(db,request);
 if(guest)await db.prepare('UPDATE beta_invites SET session_until=0 WHERE id=?').bind(guest.id).run();
 return new Response(null,{status:303,headers:{...headers,Location:'/', 'Set-Cookie':cookie('',0)}});
}
export function joinPage(){
 return new Response('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Hebrew Quest beta</title><main><h1>Hebrew Quest beta</h1><p>Invitation required. Language help uses simulated responses.</p><p>Vocabulary and progress are saved in this browser.</p><button id="join" disabled>Join beta</button><p id="message" role="status"></p></main><script src="/beta-join.js"></script></html>',{headers:{...headers,'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':"default-src 'none'; script-src 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'"}});
}
