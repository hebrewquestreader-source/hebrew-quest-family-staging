import {validDiscoverPreference} from './discover-catalog.ts';
import {AssistanceError} from './language.ts';
export type Account={id:string;email:string;dataOwner:string;keyId:string;legacyOwner:boolean;preferences:Record<string,boolean|number|string>;preferencesSet:boolean};
const preferenceKeys=['nikud','pron','audio','lemma','hint','translation','prepareAhead','wordBreakdown','highlightExpressions'];
export function verifiedIdentity(request:Request,mutation=true){
 const id=request.headers.get('oai-authenticated-user-id'),email=request.headers.get('oai-authenticated-user-email');
 if(!id||id.length>200||/[\p{Cc}\p{Cs}]/u.test(id)||!email||email.length>320||!email.includes('@'))throw new AssistanceError('sign_in','Sign in with your own authorised ChatGPT account.',401);
 if(mutation&&request.headers.get('origin')!==new URL(request.url).origin)throw new AssistanceError('bad_origin','Please use this reader’s own page.',403);
 if((request.headers.has('x-hq-account')||new URL(request.url).pathname.startsWith('/api/')&&!(request.method==='GET'&&new URL(request.url).pathname==='/api/account'))&&request.headers.get('x-hq-account')!==id)throw new AssistanceError('account_changed','The signed-in account changed. Reload the reader before continuing.',401);
 return {id,email:email.toLowerCase()};
}
export function validPreferences(value:unknown){if(!value||typeof value!=='object'||Array.isArray(value))throw new AssistanceError('invalid_preferences','Invalid reading preferences.');const out:Record<string,boolean|number|string>={};for(const [key,val]of Object.entries(value)){const allowed=validDiscoverPreference(key,val)||key==='interactiveReservePercent'&&[75,80,90,100].includes(Number(val))&&typeof val==='number'||preferenceKeys.includes(key)&&typeof val==='boolean'||key==='readingSize'&&Number.isInteger(val)&&Number(val)>=0&&Number(val)<=4||key==='lineSpacing'&&typeof val==='string'&&['compact','comfortable','spacious'].includes(String(val));if(!allowed)throw new AssistanceError('invalid_preferences','Unknown reading preference.');out[key]=val;}return out;}
export async function resolveAccount(db:D1Database,ownerEmail:string,request:Request,mutation=true):Promise<Account>{
 const identity=verifiedIdentity(request,mutation);let row=await db.prepare('SELECT * FROM reader_accounts WHERE id=?').bind(identity.id).first<any>();
 if(!row){const legacy=identity.email===ownerEmail.toLowerCase(),dataOwner=legacy?ownerEmail.toLowerCase():'user:'+identity.id;
  // Existing owner records and IDs are never rewritten. The unique alias prevents double claiming.
  try{await db.prepare('INSERT INTO reader_accounts (id,email,data_owner,legacy_owner,preferences_json,created_at,updated_at) VALUES (?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING').bind(identity.id,identity.email,dataOwner,legacy?1:0,'{}',new Date().toISOString(),new Date().toISOString()).run();}catch{throw new AssistanceError('account_mapping','This identity could not be linked safely. Existing data is unchanged; contact the site owner.',409);}
  row=await db.prepare('SELECT * FROM reader_accounts WHERE id=?').bind(identity.id).first<any>();
 }
 if(!row)throw new AssistanceError('account_unavailable','Your account could not be loaded.',503);
 let preferences={};try{preferences=validPreferences(JSON.parse(row.preferences_json));}catch{}
 return {id:row.id,email:identity.email,dataOwner:row.data_owner,keyId:Number(row.legacy_owner)?'owner':'user:'+row.id,legacyOwner:Number(row.legacy_owner)===1,preferences,preferencesSet:row.preferences_json!=='{}'};
}
export function accountView(account:Account){return {id:account.id,email:account.email,legacyOwner:account.legacyOwner,preferences:account.preferences,preferencesSet:account.preferencesSet};}
export async function savePreferences(db:D1Database,account:Account,value:unknown){const incoming=validPreferences(value),row=await db.prepare('SELECT preferences_json FROM reader_accounts WHERE id=?').bind(account.id).first<{preferences_json:string}>();let previous={};try{previous=validPreferences(JSON.parse(row?.preferences_json||'{}'));}catch{}const preferences={...previous,...incoming};await db.prepare('UPDATE reader_accounts SET preferences_json=?,updated_at=? WHERE id=?').bind(JSON.stringify(preferences),new Date().toISOString(),account.id).run();return preferences;}
export function accountBootstrap(account:Account){return '<script>globalThis.HQ_ACCOUNT='+JSON.stringify(accountView(account)).replace(/[<>&\u2028\u2029]/g,c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'))+';</script><script src="/account-client.js?v=3"></script><script src="/sync-client.js?v=38"></script>';}
