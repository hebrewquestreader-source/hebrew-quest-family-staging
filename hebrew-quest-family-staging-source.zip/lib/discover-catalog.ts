// Verified publisher RSS endpoints, checked 2026-11-01. No arbitrary URL proxy.
export const DISCOVER_TOPICS={israel:'Israeli News',world:'World Affairs',politics:'Politics',technology:'Technology',business:'Business and Economics',science:'Science',history:'History',culture:'Society and Culture'};
export const DISCOVER_PUBLISHERS={ynet:{name:'Ynet',domains:['ynet.co.il','www.ynet.co.il'],importable:true},globes:{name:'Globes',domains:['globes.co.il','www.globes.co.il'],importable:true},n12:{name:'N12 / mako',domains:['www.mako.co.il','mako.co.il','www.n12.co.il','n12.co.il'],importable:false},israelhayom:{name:'Israel Hayom',enabled:false,disabledReason:'The publisher returns HTTP 403 to access-rule requests from our hosting. Your preference is retained.',domains:['www.israelhayom.co.il','israelhayom.co.il'],importable:false}};
export type Publisher=keyof typeof DISCOVER_PUBLISHERS;
export type Topic=keyof typeof DISCOVER_TOPICS;
export const DISCOVER_FEEDS:{id:string;publisher:Publisher;topic:Topic;url:string}[]=[
 {id:'ynet-news',publisher:'ynet',topic:'israel',url:'https://www.ynet.co.il/Integration/StoryRss2.xml'},
 {id:'ynet-digital',publisher:'ynet',topic:'technology',url:'https://www.ynet.co.il/Integration/StoryRss544.xml'},
 {id:'ynet-culture',publisher:'ynet',topic:'culture',url:'https://www.ynet.co.il/Integration/StoryRss538.xml'},
 {id:'ynet-economy',publisher:'ynet',topic:'business',url:'https://www.ynet.co.il/Integration/StoryRss6.xml'},
 {id:'globes-home',publisher:'globes',topic:'business',url:'https://www.globes.co.il/webservice/rss/rssfeeder.asmx/FeederNode?iID=2'},
 {id:'n12-politics',publisher:'n12',topic:'politics',url:'https://rcs.mako.co.il/rss/news-military.xml'},
 {id:'n12-world',publisher:'n12',topic:'world',url:'https://rcs.mako.co.il/rss/news-world.xml'},
 {id:'israelhayom-home',publisher:'israelhayom',topic:'israel',url:'https://www.israelhayom.co.il/rss.xml'}
];
export const DISCOVER_DEFAULTS={discoverTopics:Object.keys(DISCOVER_TOPICS).join(','),discoverPublishers:Object.keys(DISCOVER_PUBLISHERS).join(','),discoverDifficulty:'normal'};
export function validDiscoverPreference(key:string,value:unknown){if(typeof value!=='string')return false;if(key==='discoverDifficulty')return ['easy','normal','challenge'].includes(value);const keys=key==='discoverTopics'?Object.keys(DISCOVER_TOPICS):key==='discoverPublishers'?Object.keys(DISCOVER_PUBLISHERS):null;if(!keys)return false;const parts=value?value.split(','):[];return parts.length<=keys.length&&new Set(parts).size===parts.length&&parts.every(x=>keys.includes(x));}
export function discoverPreferences(value:Record<string,unknown>={}){const out={...DISCOVER_DEFAULTS};for(const key of Object.keys(out) as (keyof typeof out)[])if(validDiscoverPreference(key,value[key]))out[key]=String(value[key]);return out;}

export function publisherEnabled(id:Publisher){return (DISCOVER_PUBLISHERS[id] as {enabled?:boolean}).enabled!==false;}
export const DISCOVER_IMAGE_HOSTS:Record<Publisher,string[]>={ynet:['ynet-pic1.yit.co.il','ynet-pic2.yit.co.il','images1.ynet.co.il','images.ynet.co.il'],globes:['res.cloudinary.com','images.globes.co.il'],n12:['img.mako.co.il'],israelhayom:['www.israelhayom.co.il','images.israelhayom.co.il']};
export function safeDiscoverImage(value:unknown,publisher:Publisher){try{if(typeof value!=='string'||value.length>2500)return null;const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||u.port||!DISCOVER_IMAGE_HOSTS[publisher]?.includes(u.hostname)||!/[.](jpe?g|png|webp|avif)(?:$|[?])/i.test(u.pathname+u.search)||u.hostname==='res.cloudinary.com'&&!u.pathname.startsWith('/globes/image/'))return null;return u.href;}catch{return null;}}
