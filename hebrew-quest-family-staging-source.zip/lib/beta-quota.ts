export function quotaBuckets(id:string,now:number){
 return [false,true].flatMap(shared=>[{window:'minute',unit:60000,guest:4,global:12},{window:'day',unit:86400000,guest:30,global:120}].map(({window,unit,guest,global})=>({
  window:shared?'global_'+window:window,limit:shared?global:guest,
  bucket:'beta:'+(shared?'global':'guest:'+id)+':'+window+':'+Math.floor(now/unit),resetAt:(Math.floor(now/unit)+1)*unit
 })));
}
export async function admit(db:D1Database,id:string,now:number){
 const b=quotaBuckets(id,now);
 const result=await db.prepare(`WITH limits(bucket,cap,reset_at) AS (VALUES (?,?,?),(?,?,?),(?,?,?),(?,?,?)),
 allowed AS MATERIALIZED (SELECT 1 WHERE EXISTS(SELECT 1 FROM beta_invites WHERE id=? AND revoked_at IS NULL AND session_until>?) AND NOT EXISTS(
 SELECT 1 FROM limits LEFT JOIN language_limits USING(bucket) WHERE COALESCE(hits,0)>=cap))
 INSERT INTO language_limits(bucket,hits,expires_at)
 SELECT bucket,1,reset_at FROM limits,allowed WHERE 1
 ON CONFLICT(bucket) DO UPDATE SET hits=language_limits.hits+1 RETURNING bucket`)
 .bind(...b.flatMap(x=>[x.bucket,x.limit,x.resetAt]),id,now).all();
 return result.results.length===b.length;
}
