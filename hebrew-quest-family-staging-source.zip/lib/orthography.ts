import {HebrewText} from './hebrew-text.js';
// Accept limited Hebrew full-to-pointed spelling differences, never arbitrary rewrites.
// The unpointed article token is kept separately and restored on deselection.
export const unpoint=(text:string)=>text.normalize('NFD').replace(/[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]/g,'').normalize('NFC');
export function standardPointedSpelling(original:string,pointed:string):boolean{
 if(!HebrewText.validNikud(original,pointed))return false;
 const source=[...unpoint(original)];
 const target:{letter:string;marks:string}[]=[];
 for(const c of pointed.normalize('NFD')){if(/[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]/.test(c)){if(!target.length)return false;target[target.length-1].marks+=c;}else target.push({letter:c,marks:''});}
 const memo=new Map<string,boolean>();
 function align(i:number,j:number):boolean{
  const key=i+':'+j;if(memo.has(key))return memo.get(key)!;
  if(i===source.length)return j===target.length;
  let ok=false;
  if(j<target.length&&source[i]===target[j].letter)ok=align(i+1,j+1);
  if(!ok&&j>0){const prev=target[j-1],c=source[i];
   const duplicate=(c==='י'||c==='ו')&&source[i-1]===c&&prev.letter===c;
   const materYod=c==='י'&&prev.letter!=='י'&&prev.marks.includes('\u05b4');
   const materVav=c==='ו'&&prev.letter!=='ו'&&/[\u05b9\u05ba\u05bb]/.test(prev.marks);
   if(duplicate||materYod||materVav)ok=align(i+1,j);
  }
  memo.set(key,ok);return ok;
 }
 return align(0,0);
}
