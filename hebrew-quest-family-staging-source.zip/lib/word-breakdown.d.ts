export const WordBreakdown:{checked(raw:any,input:{tokens:string[];context:string}):any;checkedPartial(raw:any,input:{tokens:string[];context:string}):any;values:Record<string,string[]>};
