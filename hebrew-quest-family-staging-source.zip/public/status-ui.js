// Presentation only: no requests, storage writes, queue mutations or retries.
globalThis.ReaderStatus=(()=>{
 const shown=new Map();
 function show(id,text,{state='notice',transient=false,details=''}={}){
  const node=document.getElementById(id);if(!node)return;
  const signature=JSON.stringify([text,state,transient,details]),previous=shown.get(id);
  if(previous?.signature===signature)return;
  clearTimeout(previous?.timer);
  const entry={signature,timer:null};shown.set(id,entry);
  node.textContent=text;node.hidden=false;node.dataset.saveState=state;
  const container=id==='accountSyncStatus'?document.getElementById('saveStatus'):node;
  if(container){if(id==='accountSyncStatus')container.hidden=!text;container.dataset.saveState=state;}
  if(id==='accountSyncStatus'){
   const disclosure=document.getElementById('syncStatusDetails'),body=document.getElementById('syncStatusDetailText');
   if(body)body.textContent=details;
   if(disclosure){disclosure.hidden=!details;if(!details)disclosure.open=false;}
  }
  if(text&&transient)entry.timer=setTimeout(()=>{
   if(shown.get(id)!==entry||node.textContent!==text)return;
   node.textContent='';if(id==='accountSyncStatus'&&container)container.hidden=true;
  },5000);
 }
 function init(){
  // Existing availability controller still owns hold, expiry and Retry behaviour.
  const availability=()=>{
   const hold=globalThis.AIAvailability?.snapshot().hold,details=document.getElementById('aiRetryInformation');
   if(!details)return;
   const text=hold?.retryAt?'New requests can be tried after '+new Date(hold.retryAt).toLocaleString()+'. Availability will depend on the service.':hold?'No retry time was supplied. Use Retry new help to try again.':'';
   if(details.textContent!==text)details.textContent=text;
   if(!hold){const notice=document.getElementById('aiUnavailableNotice');if(notice)notice.open=false;}
  };
  globalThis.AIAvailability?.subscribe(availability);availability();
 }
 return {show,init};
})();
