globalThis.QuickReadingTools=(()=>{
 const panel=document.getElementById('quickReadingPanel'),button=document.getElementById('quickReadingButton');
 function update(){document.getElementById('quickSizeValue').textContent=readingSizeNames[settings.readingSize];document.getElementById('quickSizeDown').disabled=settings.readingSize===0;document.getElementById('quickSizeUp').disabled=settings.readingSize===readingSizes.length-1;document.getElementById('quickLineSpacing').value=settings.lineSpacing;for(const [id,key]of [['quickBreakdown','wordBreakdown'],['quickPron','pron'],['quickAudio','audio']])document.getElementById(id).checked=!!settings[key];document.getElementById('quickPhraseAction').hidden=!active;}
 function close(focus=true){panel.hidden=true;button.setAttribute('aria-expanded','false');if(typeof HebrewInteractions!=='undefined')HebrewInteractions.closeToolsHistory();if(focus)button.focus({preventScroll:true});}
 function open(){update();panel.scrollTop=0;panel.hidden=false;button.setAttribute('aria-expanded','true');if(typeof HebrewInteractions!=='undefined')HebrewInteractions.openToolsHistory();document.getElementById('quickReadingHeading').focus({preventScroll:true});}
 button.addEventListener('click',()=>panel.hidden?open():close());document.getElementById('quickReadingClose').addEventListener('click',()=>close());document.getElementById('quickFullSettings').addEventListener('click',()=>{close(false);toggleSettings(true);});
 for(const [id,delta]of [['quickSizeDown',-1],['quickSizeUp',1]])document.getElementById(id).addEventListener('click',()=>changeReadingSize(delta));
 for(const [id,key]of [['quickLineSpacing','lineSpacing'],['quickBreakdown','wordBreakdown'],['quickPron','pron'],['quickAudio','audio']])document.getElementById(id).addEventListener('change',e=>{settings[key]=key==='lineSpacing'?e.target.value:e.target.checked;persistReadingSettings();});
 update();return {update,open,close,isOpen:()=>!panel.hidden};
})();
