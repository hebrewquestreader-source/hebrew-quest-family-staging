// Manually checked lexical facts and original glosses. See docs/word-catalogue.md.
globalThis.WordCatalogue=(()=>{
 const entries=[
  {
   lemma:'נדל״ן',category:'noun',senses:/^(?:real[ -]estate|immovables?|immovable (?:property|assets))$/,
   expansion:'נכסי דלא ניידי',
   note:'Aramaic for immovable property. נכסי means “assets”, דלא means “that do not”, and ניידי means “move”. In modern Hebrew it means real estate.',
   sources:[['Saul Rotstein · Construction Terms','https://hebrew-academy.org.il/wp-content/uploads/Dictionary-of-Construction-Terms-Hebrew.pdf'],['Academy of the Hebrew Language · immovable property','https://terms.hebrew-academy.org.il/munnah/28839_2/immovable%20property']]
  },
  {
   lemma:'מנכ״ל',category:'noun',senses:/^(?:ceo|chief executive(?: officer)?|general manager|director[ -]general)$/,
   expansion:'מנהל כללי',
   note:'מנהל is a manager or director, and כללי means “general”. The abbreviation is often used for a CEO or director-general.',
   sources:[['Academy of the Hebrew Language · CEO','https://terms.hebrew-academy.org.il/munnah/98961_2/CEO']]
  },
  {
   lemma:'דו״ח',category:'noun',senses:/^(?:report|account|written report)$/,
   expansion:'דין וחשבון',
   note:'The full expression means a report or an account. דין can mean “judgment”, and חשבון means “account” or “reckoning”.',
   sources:[['Academy of the Hebrew Language · דו״ח','https://terms.hebrew-academy.org.il/munnah/111657_1/%D7%93%D7%95%22%D7%97']]
  },
  {
   lemma:'לצאת לאור',category:'expression',senses:/^(?:be published|come out|appear in print)$/,
   figurative:'Used for a work being published. Literally, the expression describes coming out into the light.',
   sources:[['Academy of the Hebrew Language · publishing terms','https://terms.hebrew-academy.org.il/munnah/6626_2/to%20come%20out']]
  },
  {
   lemma:'להזכיר',category:'verb',senses:/^(?:mention|remind)(?:\s*(?:\/|;|,| or )\s*(?:to )?(?:mention|remind))?$/,
   family:[['לזכור','to remember','לִזְכּוֹר'],['זיכרון','memory','זִיכָּרוֹן'],['תזכורת','a reminder','תִּזְכּוֹרֶת'],['מזכרת','a keepsake','מַזְכֶּרֶת']],
   sources:[['Pealim · להזכיר','https://www.pealim.com/dict/35-lehazkir/'],['Pealim · מזכרת','https://www.pealim.com/he/dict/3403-mazkeret/']]
  },
  {
   lemma:'לכתוב',category:'verb',senses:/^write(?: down)?$/,
   family:[['כתיבה','the act of writing','כְּתִיבָה'],['מכתב','a written letter','מִכְתָּב'],['כתבה','a news story','כַּתָּבָה'],['התכתבות','written correspondence','הִתְכַּתְּבוּת']],
   sources:[['Pealim · מכתב','https://www.pealim.com/he/dict/3035-michtav/']]
  },
  {
   lemma:'טלפון',category:'noun',senses:/^(?:telephone|phone)(?: device)?$/,
   origin:'The international word for the telephone combines Greek elements for distance and voice. Modern Hebrew also formed a verb from this loanword: לטלפן, meaning to make a phone call.',
   sources:[['Academy of the Hebrew Language · טלפן','https://terms.hebrew-academy.org.il/munnah?kodErekhIvrit=8178'],['Académie française · téléphone','https://www.dictionnaire-academie.fr/article/A9T0581'],['Hebrew Wiktionary · טלפון','https://he.wiktionary.org/wiki/טלפון']]
  },
  {
   lemma:'טרור',category:'noun',senses:/^(?:terrorism|terror)(?:\s*[/;,]\s*(?:terrorism|terror))?$/,
   origin:'Hebrew borrowed this word from the international vocabulary of terror. Its distant ancestor is the Latin noun terror.',
   sources:[['Wiktionary contributors · טרור','https://en.wiktionary.org/w/index.php?title=טרור&oldid=91750653']]
  }
 ];
 function match(result){
  if(result?.confident!==true||result.lemmaConfident!==true||typeof result.lemma!=='string'||typeof result.lemmaMeaning!=='string')return;
  const lemma=normalize(result.lemma);
  const sense=result.lemmaMeaning.trim().toLowerCase().replace(/^(?:to|a|an|the)\s+/,'').replace(/\.$/,'');
  return entries.find(entry=>(entry.lemma===lemma||entry.expansion&&entry.lemma.replace('״','')===lemma)&&entry.category===result.category&&entry.senses.test(sense));
 }
 function normalize(text){return HebrewText.unpoint(text).replace(/["“”]/gu,'״');}
 function abbreviation(tokens){
  if(tokens.length!==1)return;
  const word=normalize(HebrewText.tokenEdges(tokens[0]).word);
  return entries.find(entry=>entry.expansion&&entry.lemma===word);
 }
 return {version:2,match,abbreviation};
})();
