// Shared, deterministic Unicode boundary checks. This does not guess vocalisation.
const HebrewText=(()=>{
 const mark=/[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]/u,letter=/[א-ת]/u,vowel=/[\u05b0-\u05bb\u05c7]/u;
 const unpoint=s=>String(s).normalize('NFD').replace(/[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]/gu,'').normalize('NFC');
 function validate(value,{source='',mixed=false,required=false,pointed=false}={}){
  if(typeof value!=='string')throw new Error('Invalid Hebrew text.');const text=value.normalize('NFC');
  if(required&&!letter.test(text))throw new Error('Expected Hebrew text.');
  for(const run of text.matchAll(/[\p{L}\p{M}]+/gu))if(/[א-ת]/u.test(run[0])&&/[\u0600-\u06ff\u0750-\u077f\u08a0-\u08ff]/u.test(run[0]))throw new Error('Invalid Hebrew character or mark U+'+[...run[0]].find(c=>/[\u0600-\u06ff\u0750-\u077f\u08a0-\u08ff]/u.test(c)).codePointAt(0).toString(16).toUpperCase().padStart(4,'0')+'. Original text retained.');
  const sourceNfd=source.normalize('NFD');let base='',marks=[],foreignCluster='';const fail=c=>{const error=new Error('Invalid Hebrew character or mark U+'+c.codePointAt(0).toString(16).toUpperCase().padStart(4,'0')+'. Original text retained.');error.character=c;throw error;};
  for(const c of text.normalize('NFD')){
   if(mark.test(c)){
    if(!letter.test(base)||marks.includes(c)||(/[\u05c1\u05c2]/u.test(c)&&(base!=='ש'||marks.some(m=>/[\u05c1\u05c2]/u.test(m))))||(vowel.test(c)&&marks.some(m=>vowel.test(m))))fail(c);
    marks.push(c);continue;
   }
   if(/\p{M}/u.test(c)){if(letter.test(base)||!mixed||!sourceNfd.includes(foreignCluster+c))fail(c);foreignCluster+=c;continue;}
   if(/[\p{Cc}\p{Cf}\p{Cs}]/u.test(c)&&!/[\n\t\r]/u.test(c))fail(c);
   if(/\p{L}/u.test(c)&&!letter.test(c)&&(!mixed||!sourceNfd.includes(c)))fail(c);
   if(!/[\p{L}\p{N}\p{P}\p{Z}\s]/u.test(c)&&!/[+%=₪$€]/u.test(c)&&(!mixed||!sourceNfd.includes(c)))fail(c);
   base=c;marks=[];foreignCluster=c;
  }
  // A foreign-script word may only be copied as a whole from the source, never assembled.
  for(const run of text.matchAll(/[^\s\p{P}\p{N}]+/gu))if(/\p{L}/u.test(run[0])&&!letter.test(run[0])&&(!mixed||!source.normalize('NFC').includes(run[0])))fail([...run[0]][0]);
  if(pointed&&letter.test(text)&&!mark.test(text))throw new Error('Nikud was omitted. Original text retained.');
  return text;
 }
 function safe(value,options){try{return validate(value,options);}catch{return null;}}
 // Copy only missing boundary punctuation from the immutable source. The lexical
 // spelling/nikud validator still checks the entire reconstructed token.
 function tokenEdges(text){const m=String(text).match(/^([.,!?;:()\[\]{}"“”«»]*)(.*?)([.,!?;:()\[\]{}"“”«»]*)$/u);return {before:m[1],word:m[2],after:m[3]};}
 function alignPunctuation(original,pointed){if(typeof original!=='string'||typeof pointed!=='string')return null;if(validNikud(original,pointed))return pointed.normalize('NFC');const a=tokenEdges(original),b=tokenEdges(pointed);if(b.before&&b.before!==a.before||b.after&&b.after!==a.after)return null;const candidate=a.before+b.word+a.after;return validNikud(original,candidate)?candidate.normalize('NFC'):null;}
 function related(selected,lemma){
  if(!lemma)return true;if(matches(selected,lemma))return true;const clean=s=>unpoint(s).replace(/[ךםןףץ]/g,c=>({'ך':'כ','ם':'מ','ן':'נ','ף':'פ','ץ':'צ'}[c])).replace(/[^א-ת\s]/g,'').trim();
  const a=clean(selected),b=clean(lemma);if(a===b)return true;
  const irregular=[['הלך','ללכת'],['הלכ','ללכת'],['היה','להיות'],['נתנ','לתת'],['בא','לבוא']];
  function stems(s){const out=new Set([s]);for(let depth=0;depth<2;depth++)for(const w of [...out]){
   for(const p of ['ו','ה','ב','כ','ל','מ','ש','לה','להת','הת'])if(w.startsWith(p)&&w.length-p.length>=3)out.add(w.slice(p.length));
   for(const x of ['יהמ','יהנ','ינו','יכמ','יכנ','יה','יו','ימ','ות','המ','הנ','כמ','כנ','נו','תי','תמ','תנ','ה','ו','ת','י','כ','מ','נ'])if(w.endsWith(x)&&w.length-x.length>=3)out.add(w.slice(0,-x.length));
  }return out;}
  const aw=a.split(/\s+/),bw=b.split(/\s+/);if(aw.length===1&&bw.length===1&&!b.startsWith('ל')&&b.length>a.length+1)return false;
  // Regular infinitives can write a vowel ו absent in finite forms (כתבתי / לכתוב).
  // This is a relationship check on an AI proposal, never a lemma/root generator.
  // Compare finite full spelling with a vowelled infinitive stem. Only the
  // existing nikud alignment rules may omit a mater; no arbitrary letters vanish.
  function pointedVerbRelated(w,inf){
   if(!unpoint(inf).startsWith('ל'))return false;
   const stem=inf.replace(/^ל[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]*/u,'').replace(/[ךםןףץ]/g,c=>({'ך':'כ','ם':'מ','ן':'נ','ף':'פ','ץ':'צ'}[c]));
   const base=unpoint(stem);
   const paalBase=base.length===4&&base[2]==='ו'&&/ו[\u0591-\u05c7]*\u05b9/u.test(stem.normalize('NFD'))?base.slice(0,2)+base.slice(3):base;
   const piel=/^[א-ת][\u05b7\u05b8][א-ת][\u0591-\u05c7]*\u05b5/u.test(stem.normalize('NFD'));
   return [...stems(w)].some(candidate=>validNikud(candidate,stem)||
    // Active Paal participle C-vav-C-C versus the supplied pointed infinitive.
    candidate.length===4&&candidate[1]==='ו'&&candidate[0]+candidate.slice(2)===paalBase&&/[\u05b0\u05b1\u05b2\u05b3]/u.test(stem)||
    // Piel finite hiriq/full-spelling yod alternates with infinitive patah.
    piel&&candidate[1]==='י'&&candidate[0]+candidate.slice(2)===base||
    // Hollow Paal and assimilated-nun infinitives: accept only the supplied
    // consonant relation with the corresponding pointed infinitive pattern.
    /^ל\u05b8/u.test(inf.normalize('NFD'))&&/^[א-ת]ו\u05bc[א-ת]/u.test(stem.normalize('NFD'))&&candidate===base[0]+base.slice(2)||
    /^ל\u05b4[א-ת][\u0591-\u05c7]*\u05bc/u.test(inf.normalize('NFD'))&&base.length===3&&base[1]==='ו'&&candidate==='נ'+base[0]+base[2]);
  }
  // Nifal infinitives may retain a full-spelling yod after hiriq. Future
  // forms double initial yod in full spelling. Check a pointed Nifal template,
  // not a general permission to drop initial letters from arbitrary lemmas.
  function nifalRelated(w,inf){
   const nfd=inf.normalize('NFD'),match=nfd.match(/^ל[\u0591-\u05c7]*ה\u05b4י?([א-ת][\u0591-\u05c7]*\u05bc[\s\S]*)$/u);
   if(!match)return false;
   const stem=match[1],candidates=new Set(stems(w));
   for(const candidate of [...candidates])if(/^[איתנ]/u.test(candidate)){
    candidates.add(candidate.slice(1));if(/^[יתנ]י/u.test(candidate))candidates.add(candidate.slice(2));
   }
   return [...candidates].some(candidate=>validNikud(candidate,stem));
  }
  function verbRelated(w,inf){if(!inf.startsWith('ל')||inf.length<4)return false;const finite=stems(w),infinitives=stems(inf);if(/^[אתינ]/.test(w)&&w.length>=4)for(const t of stems(w.slice(1)))finite.add(t);if([...infinitives].some(t=>finite.has(t)))return true;for(const x of infinitives){if(x.length<4)continue;for(let i=1;i<x.length-1;i++)if(x[i]==='ו'&&finite.has(x.slice(0,i)+x.slice(i+1)))return true;}return false;}
  // Closed-class prepositions have legitimate two-letter bases that the general
  // three-letter stem guard deliberately cannot accept.
  function prepRelated(w,base){if(!['על','אל','של','עמ'].includes(base))return false;return ['י','כ','ו','ה','נו','כמ','כנ','המ','הנ','יו','יה','יכמ','יכנ','יהמ','יהנ'].some(s=>w===base+s||w==='ו'+base+s);}
if(aw.length!==bw.length)return false;
  return aw.every((w,i)=>{const x=stems(w),y=stems(bw[i]);return [...x].some(t=>y.has(t))||irregular.some(([s,l])=>x.has(s)&&bw[i]===l)||nifalRelated(w,lemma.split(/\s+/)[i])||verbRelated(w,bw[i])||pointedVerbRelated(w,lemma.split(/\s+/)[i])||prepRelated(w,bw[i]);});
 }
 function matches(original,pointed){
  const source=[...unpoint(original)],target=[];for(const c of pointed.normalize('NFD')){if(mark.test(c)){if(!target.length)return false;target[target.length-1].marks+=c;}else target.push({letter:c,marks:''});}
  const memo=new Map();function align(i,j){const k=i+':'+j;if(memo.has(k))return memo.get(k);if(i===source.length)return j===target.length;let ok=j<target.length&&source[i]===target[j].letter&&align(i+1,j+1);
   if(!ok&&j>0){const prev=target[j-1],c=source[i];if(((c==='י'||c==='ו')&&source[i-1]===c&&prev.letter===c)||(c==='י'&&prev.letter!=='י'&&prev.marks.includes('\u05b4'))||(c==='ו'&&prev.letter!=='ו'&&/[\u05b9\u05ba\u05bb]/.test(prev.marks)))ok=align(i+1,j);}
   memo.set(k,ok);return ok;}return align(0,0);
 }
 function validNikud(original,nikud){try{validate(nikud,{source:original,mixed:true,pointed:/[א-ת]/.test(original)});return matches(original,nikud);}catch{return false;}}
 // Validate decoded values by field. English/transliteration never enter validate().
 function languageText(value,field){if(typeof value!=='string'||value.length>700||/[\p{Cc}\p{Cs}]/u.test(value.replace(/[\n\r\t]/g,'')))throw new Error('Invalid '+field+' text.');return value;}
 function hebrewField(value,field,source,withheld){
  try{return validate(value,{source,mixed:true});}catch(error){
   // A wrong-language optional field must not invalidate independently checked nikud.
   // Withhold the ENTIRE field, explicitly; never strip characters or guess a replacement.
   if(['hint','lemma'].includes(field)){withheld.add(field);return '';}
   throw new Error(field+': '+error.message);
  }
 }
 function result(value,input){
  if(!value||value.confident!==true||!Array.isArray(value.tokens)||value.tokens.length!==input.tokens.length)throw new Error('Incomplete language result.');
  const tokens=value.tokens.map((t,i)=>{if(t.original!==input.tokens[i]||!(value.withheldFields?.includes('nikud')&&t.nikud===t.original)&&!validNikud(input.tokens[i],t.nikud))throw new Error('nikud: The language result does not match the exact selection.');return {...t,nikud:t.nikud.normalize('NFC')};});
  const withheld=new Set((Array.isArray(value.withheldFields)?value.withheldFields:[]).filter(k=>['hint','lemma','pronunciation','nikud','translation'].includes(k)));
  let hint='';try{hint=hebrewField(languageText(value.hint??'','hint'),'hint',input.context,withheld);}catch{withheld.add('hint');}if(hint&&!/[א-ת]/u.test(hint)){hint='';withheld.add('hint');}if(!hint&&!value.partial)withheld.add('hint');let lemma=hebrewField(languageText(value.lemma||'','lemma'),'lemma',input.tokens.join(' '),withheld);
  const translation=languageText(value.translation,'translation');let pronunciation='';try{pronunciation=languageText(value.pronunciation??'','pronunciation');if(pronunciation&&!/^[\p{Script=Latin}\p{M}\p{N}\p{P}\p{Z}\s]+$/u.test(pronunciation))throw Error();}catch{pronunciation='';withheld.add('pronunciation');}let lemmaTranslation=languageText(value.lemmaTranslation,'lemmaTranslation');
  const lemmaWithheld=!!value.lemmaWithheld||value.lemmaConfident===false||!!lemma&&!safe(lemma,{source:input.tokens.join(' '),mixed:true,pointed:true})||!related(input.tokens.join(' '),lemma)||value.lemmaKind==='infinitive'&&!!lemma&&!unpoint(lemma).startsWith('ל');if(lemmaWithheld)lemma='';if(!lemma)lemmaTranslation='';
  const lemmaKind=lemma&&['infinitive','dictionary','expression','conjugated'].includes(value.lemmaKind)?value.lemmaKind:'';
  return {...value,lemmaKind,tokens,hint,lemma,translation,lemmaTranslation,pronunciation,...(lemmaWithheld?{lemmaWithheld:true}:{}),...(withheld.size?{withheldFields:[...withheld]}:{})};
 }
 function vocabulary(entry){
  const out={...entry},rejected={...(entry.quarantined||{})};
  for(const field of ['nikud','lemma']){const text=entry[field]||'';let ok=true;
   if(text)try{if(field==='nikud'){if(!validNikud(entry.expression,text))throw new Error();}else{validate(text,{source:entry.expression,mixed:true});if(!related(entry.expression,text))throw new Error();}}catch{ok=false;}
   if(!ok){rejected[field]=text;out[field]='';if(field==='lemma')out.lemmaTranslation='';}
  }
  if(Object.keys(rejected).length){out.quarantined=rejected;out.incomplete=true;out.validationNote='Malformed stored language help withheld; original selection and examples retained.';}
  out.examples=(entry.examples||[]).map(e=>{if(e.nikud&&!validNikud(e.expression,e.nikud))return {...e,nikud:'',incomplete:true,quarantined:{nikud:e.nikud}};return e;});
  if(out.examples.some(e=>e.incomplete))out.incomplete=true;
  return out;
 }
 return {validate,safe,unpoint,related,validNikud,tokenEdges,alignPunctuation,result,vocabulary};
})();
