function checkedAssistance(value,input){const result=HebrewText.result(value,input);delete result.analysis;if(value.analysis)try{const analysis=WordBreakdown.checked(value.analysis,input);if(analysis.confident)result.analysis=analysis;}catch{}return result;}
// Contextual language help. All response text is rendered with textContent, never HTML.
const assistCacheKey='hebrew-quest-language-v8-gemini-3.5-flash-lite';
let assistCache=new Map();
try{const saved=JSON.parse(readerStorage.getItem(assistCacheKey)||'[]');if(Array.isArray(saved))assistCache=new Map(saved.slice(-100));}catch{}
const wordHelpTimings=[];
function recordWordHelpTiming(phase,startedAt){
 wordHelpTimings.push({phase,elapsedMs:Math.max(0,Date.now()-startedAt)});
 if(wordHelpTimings.length>60)wordHelpTimings.shift();
}
let assistDetailsNeeded=false;
const assistancePending=new Map();
let assistanceCacheGeneration=0;
function cancelAssistance(){assistDetailsNeeded=false;assistEpoch++;assistController=null;}
function setAssistStatus(message,error=false,retry=false){const el=document.getElementById('assistStatus');el.textContent=message;el.classList.toggle('error',error);el.hidden=!message||(!error&&!retry&&!/withheld|retry|retried/i.test(message));document.getElementById('assistRetry').hidden=!retry;document.getElementById('assistSettings').hidden=!/settings|connect/i.test(message);}
function selectionRequest(){
 const ids=active==='selection'?[...selectionIds]:[active];
 if(!ids.length||!ids[0]||ids[0].startsWith('p'))return null;
 const tokens=ids.map(id=>getData(id)[0]);const external=externalSelection(ids);const context=external?.context||sentenceForSelection(ids);
 return {ids,input:{tokens,context,...(external?.protected?{helpScope:'exercise_language',isQuestion:!!external.wholeQuestion,sourceType:external.sourceType}:{})}};
}
function readCached(cacheKey,input){
 const r=assistCache.get(cacheKey);
 if(!r||r.confident!==true||!Array.isArray(r.tokens)||r.tokens.length!==input.tokens.length||r.tokens.some((t,i)=>t.original!==input.tokens[i]||typeof t.nikud!=='string'||t.nikud.length>300)||['translation','lemma','lemmaTranslation'].some(k=>typeof r[k]!=='string'))return null;
 try{if(!r.partial&&!r.hint&&!r.withheldFields?.includes('hint'))return null;return checkedAssistance(r,input);}catch{assistCache.delete(cacheKey);return null;}
}
function saveAssistCache(key,value){assistCache.delete(key);assistCache.set(key,value);while(assistCache.size>100)assistCache.delete(assistCache.keys().next().value);try{readerStorage.setItem(assistCacheKey,JSON.stringify([...assistCache]));}catch{}}
function applyAssistance(result,ids){
 result=checkedAssistance(result,{tokens:ids.map(id=>getData(id)[0]),context:sentenceForSelection(ids)});
 currentAssist=result;
 ids.forEach((id,n)=>{const [i,j]=id.split('-').map(Number);const token=result.tokens[n];if(token.nikud!==token.original||!result.withheldFields?.includes('nikud')||!HebrewText.validNikud(token.original,interactionRow(i)[j][1]))interactionRow(i)[j][1]=token.nikud;if(ids.length===1){interactionRow(i)[j][2]=result.pronunciation;interactionRow(i)[j][3]=result.hint;interactionRow(i)[j][4]=result.translation;}});
 if(active==='selection')Object.assign(selectionData,{nikud:ids.map(id=>getData(id)[1]).join(' '),hint:result.hint,translation:result.translation});
 render();
 document.getElementById('selectedWord').textContent=ids.map(id=>getData(id)[1]).join(' ');
 document.getElementById('pron').textContent=result.pronunciation;
 if(typeof MeaningHints==='undefined')document.getElementById('hint').textContent=result.withheldFields?.includes('hint')?'A Hebrew hint is not available. Try Hint again, or use Translate.':result.hint;
 document.getElementById('translation').textContent=result.translation;
 document.getElementById('contextTranslation').textContent=result.translation;
 if(!document.getElementById('translation').hidden){document.getElementById('contextTranslation').hidden=false;document.getElementById('translation').hidden=true;}
 document.getElementById('lexicalForm').textContent=result.lemma;
 document.getElementById('lexicalPron').textContent='';
 document.getElementById('lemmaTranslation').textContent=result.lemmaTranslation;
 document.querySelector('#lexical .label').textContent=result.lemmaKind==='infinitive'?'Infinitive':result.lemmaKind==='conjugated'?'Reusable conjugated form':'Reusable form';
 applySettings();const adjusted=result.tokens.some(t=>stripLocalNikud(t.nikud)!==stripLocalNikud(t.original));if(result.partial)assistDetailsNeeded=true;const unavailable=result.withheldFields?.includes('translation')?'Translation unavailable. Retry language help.':result.withheldFields?.includes('nikud')?'Some vowel marks could not be verified. Retry language help if needed.':'';const reusableMissing=result.lemmaWithheld||result.withheldFields?.includes('lemma');setAssistStatus(unavailable||(reusableMissing?'A reusable form is not available for this selection. You can retry language help.':adjusted?'Standard pointed spelling shown; the original spelling returns when nikud is cleared.':''),false,!!unavailable||!!reusableMissing);for(const field of result.withheldFields||[])globalThis.LanguageDiagnostics?.record({diagnostic:{field,code:'optional_field_withheld'}},'assist');if(result.retryCount===1)setAssistStatus('Language analysis succeeded after one automatic retry.');
}
function stripLocalNikud(s){return s.normalize('NFD').replace(/[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]/g,'').normalize('NFC');}
function applyNikud(tokens,ids){
 if(tokens.length!==ids.length||tokens.some((t,n)=>t.original!==getData(ids[n])[0]||!HebrewText.validNikud(t.original,t.nikud)))throw new Error('Incomplete nikud response.');
 ids.forEach((id,n)=>{const [i,j]=id.split('-').map(Number);interactionRow(i)[j][1]=tokens[n].nikud;});
 if(active==='selection')selectionData.nikud=tokens.map(t=>t.nikud).join(' ');
 render();document.getElementById('selectedWord').textContent=tokens.map(t=>t.nikud).join(' ');if(tokens.some(t=>stripLocalNikud(t.nikud)!==stripLocalNikud(t.original)))document.querySelector('.contextlabel').textContent='WITH NIKUD · STANDARD POINTED SPELLING';
}
async function readAssistanceResponse(response,onNikud,onRetry=()=>{}){
 if(!response.headers.get('content-type')?.includes('application/x-ndjson'))return response.json();
 const reader=response.body?.getReader();if(!reader)throw new Error('Empty language response.');
 const decoder=new TextDecoder();let pending='',result=null,total=0;
 function line(value){if(!value.trim())return;const event=JSON.parse(value);
  if(event.type==='error')throw Object.assign(new Error(event.error||"Couldn't analyse this word. Try again."),{requestId:event.requestId,code:event.code,diagnostic:event.diagnostic,retryCount:event.retryCount,retryAt:event.retryAt,quota:event.quota});if(event.type==='retry')onRetry();
  if(event.type==='nikud')onNikud(event.tokens);
  if(event.type==='result')result=event.result;
 }
 try{while(true){const {done,value}=await reader.read();if(done)break;total+=value.length;if(total>100000)throw new Error('Language response was too large.');pending+=decoder.decode(value,{stream:true});let end;while((end=pending.indexOf('\n'))>=0){line(pending.slice(0,end));pending=pending.slice(end+1);}}
  pending+=decoder.decode();if(pending.trim())line(pending);
 }finally{await reader.cancel();}
 if(!result)throw new Error('The language connection ended early. Please retry.');
 return result;
}
// Shared by the popup and Vocabulary Bank; saving never needs to reveal meanings.
async function getAssistanceResult(input,onNikud=()=>{},onRetry=()=>{},{priority='interactive',manual=false}={}){
 const known=typeof knownExpressionResult==='function'?knownExpressionResult(input.tokens,input.context):null;if(known)return known;
 const cacheKey=JSON.stringify(input),cached=readCached(cacheKey,input);if(cached&&!cached.partial&&!manual)return cached;
 let pending=assistancePending.get(cacheKey);if(pending&&priority==='interactive')AIAvailability.promote('assist',input);
 if(!pending){
  if(priority==='interactive'&&typeof notePreparationLookup==='function')notePreparationLookup();
  const cacheGeneration=assistanceCacheGeneration;
  pending=AIAvailability.run('assist',input,async effectivePriority=>{
   const response=await fetch('/api/assist',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/x-ndjson',...(effectivePriority==='background'?{'x-hq-ai-priority':'background'}:{})},body:JSON.stringify(input)});
   const rawResult=await readAssistanceResponse(response,onNikud,onRetry);
   const result=response.ok?checkedAssistance(rawResult,input):rawResult;
   if(!response.ok){if(result.code==='setup_required'){languageReady=false;refreshLanguageStatus();}throw Object.assign(new Error(result.error||"Couldn't analyse this word. Try again."),{code:result.code,diagnostic:result.diagnostic,retryCount:result.retryCount,retryAt:result.retryAt,quota:result.quota});}
   if(cacheGeneration===assistanceCacheGeneration){saveAssistCache(cacheKey,result);seedWordAnalyses(result,input);}return result;
  },{priority});assistancePending.set(cacheKey,pending);
  pending.finally(()=>{if(assistancePending.get(cacheKey)===pending)assistancePending.delete(cacheKey);}).catch(()=>{});
 }
 return pending;
}
function seedWordAnalyses(result,input){
 for(const w of result.words||[]){if(w.confident!==true||!input.tokens.includes(w.original))continue;const one={tokens:[w.original],context:input.context,...(input.helpScope?{helpScope:input.helpScope,isQuestion:false,sourceType:input.sourceType}:{})};
  try{const item=HebrewText.result({confident:true,tokens:[{original:w.original,nikud:w.nikud}],hint:'',translation:w.translation,lemma:w.lemma||'',lemmaTranslation:w.lemmaTranslation||'',pronunciation:'',partial:true},one);saveAssistCache(JSON.stringify(one),item);}catch{}
 }
}
function applyPreparedTranslation(ids){
 const meaning=typeof preparedTranslation==='function'?preparedTranslation(ids):null;
 if(!meaning)return false;
 document.getElementById('translation').textContent=meaning;
 document.getElementById('contextTranslation').textContent=meaning;
 return true;
}
async function requestAssistance(force=false,detail='all',manual=false){
 const startedAt=Date.now();
 const request=selectionRequest();if(!request)return;
 recordWordHelpTiming('selection_prepared',startedAt);
 const {ids,input}=request;cancelAssistance();const epoch=assistEpoch;
 const known=typeof knownExpressionResult==='function'?knownExpressionResult(input.tokens,input.context):null;if(known){applyAssistance(known,ids);return;}
 if(input.tokens.length>20){setAssistStatus('Select up to 20 words for language help.',true);return;}
 const cacheKey=JSON.stringify(input),cached=readCached(cacheKey,input);
 if(cached&&!manual){applyAssistance(cached,ids);recordWordHelpTiming('cache_applied',startedAt);assistDetailsNeeded=!!cached.partial;return;}
 if(detail==='translation'&&applyPreparedTranslation(ids)){assistDetailsNeeded=true;return;}
 if(languageReady===false){setAssistStatus('Connect your free Gemini key in Settings → Language assistance.',true);setMissingMeanings('Language assistance is not connected. Open Settings to connect it.');return;}
 if(!force&&settings.prepareAhead&&typeof preparedSelection==='function'){
  assistDetailsNeeded=true;setAssistStatus('Preparing nearby nikud for instant taps…');setMissingMeanings('Choose a hint or translation to request meaning.');
  const prepared=await preparedSelection(ids);if(epoch!==assistEpoch||!active)return;
  if(prepared){applyNikud(prepared,ids);const reusable=typeof preparedReusable==='function'?preparedReusable(ids):null;if(reusable){applyAssistance({...reusable,partial:true},ids);saveAssistCache(cacheKey,{...reusable,partial:true});}const meaning=applyPreparedTranslation(ids);setAssistStatus('Nikud ready · choose a hint or translation when needed.');assistDetailsNeeded=true;return;}
  return requestAssistance(true);
 }
 if(detail==='translation'&&settings.prepareAhead&&typeof preparationById!=='undefined'){
  const job=preparationById.get(ids[0]);
  if(ids.length===1&&job?.running&&!job.finished){
   assistDetailsNeeded=false;setAssistStatus('Finishing the nearby translation…');
   await job.promise;if(epoch!==assistEpoch||!active)return;
   if(applyPreparedTranslation(ids)){assistDetailsNeeded=true;setAssistStatus('Contextual translation ready.');return;}
  }
 }
 assistDetailsNeeded=false;
 const previous=ids.map(id=>getData(id)[1]);let early=false;
 const controller=new AbortController();assistController=controller;
 setAssistStatus(ids.every(id=>/[\u05b0-\u05bc\u05c1\u05c2\u05c7]/.test(getData(id)[1]))?'Nikud ready · preparing meanings…':'Adding contextual nikud and preparing language help…');setMissingMeanings('Preparing language help…');
 try{
  const result=await getAssistanceResult(input,tokens=>{if(epoch!==assistEpoch||!active)return;early=true;applyNikud(tokens,ids);recordWordHelpTiming('first_nikud',startedAt);setAssistStatus('Nikud ready · finishing meanings…');},()=>{if(epoch===assistEpoch&&active)setAssistStatus('Retrying language analysis once…');},{manual});
  if(epoch!==assistEpoch||!active)return;
  applyAssistance(result,ids);recordWordHelpTiming('lookup_applied',startedAt);
 }catch(error){if(error.name==='AbortError'||epoch!==assistEpoch)return;{ids.forEach((id,n)=>{const [i,j]=id.split('-').map(Number);interactionRow(i)[j][1]=early&&HebrewText.validNikud(getData(id)[0],getData(id)[1])||['quota','local_quota'].includes(error.code)&&HebrewText.validNikud(getData(id)[0],getData(id)[1])?getData(id)[1]:previous[n];});const retained=ids.map(id=>getData(id)[1]).join(' ');if(active==='selection')selectionData.nikud=retained;render();document.getElementById('selectedWord').textContent=retained;}globalThis.LanguageDiagnostics?.record(error,'assist');setAssistStatus(error.code==='simulator_missing'?error.message:['quota','local_quota'].includes(error.code)?'':error.code&&['setup_required','provider_access'].includes(error.code)?error.message:error.code==='uncertain'?'This reading is uncertain. Try selecting a longer phrase.':['unavailable','provider_unavailable','provider_network','provider_timeout'].includes(error.code)?'Language help is temporarily unavailable. Try again later.':'Word Help returned no usable result. Tap Retry language help.',true,!['quota','local_quota','simulator_missing'].includes(error.code));if(['quota','local_quota'].includes(error.code)){assistDetailsNeeded=true;setMissingMeanings('');updateWordHelpAvailability();}else if(error.code==='simulator_missing')setMissingMeanings('');else setMissingMeanings('Language help is unavailable. Use “Retry language help” or check Settings.');}
 finally{if(epoch===assistEpoch)assistController=null;}
}
function setMissingMeanings(text){if(active&&getData(active)[4])return;for(const id of (typeof MeaningHints==='undefined'?['hint','translation','contextTranslation']:['translation','contextTranslation']))document.getElementById(id).textContent=text;}
document.getElementById('assistSettings').addEventListener('click',()=>{closeAssistant();render();toggleSettings(true);refreshLanguageStatus();});
document.getElementById('assistRetry').addEventListener('click',()=>{if(!AIAvailability.retry())return;const request=selectionRequest();if(request){pronunciationWork.delete(JSON.stringify(request.input));}requestAssistance(true,'all',true);});
for(const id of ['hintBtn','translationBtn'])document.getElementById(id).addEventListener('click',()=>{if(id==='hintBtn'&&typeof MeaningHints!=='undefined')return;if((importedMode||externalSelection(selectionRequest()?.ids||[]))&&assistDetailsNeeded&&!assistController)requestAssistance(true,id==='translationBtn'?'translation':'all');});
async function refreshLanguageStatus(){
 const status=document.getElementById('languageConnection');
 try{const response=await fetch('/api/language/setup',{cache:'no-store'});const result=await response.json();if(!response.ok)throw new Error(result.error||'Could not check the language connection.');
  if(document.getElementById('connectLanguage').disabled)return;languageReady=result.configured;AIAvailability.fromUsage(result.usage);const usage=document.getElementById('languageUsage');if(usage&&typeof HQ_ACCOUNT!=='undefined'&&HQ_ACCOUNT.legacyOwner&&Array.isArray(result.usage)){usage.hidden=false;usage.textContent='Application allowance: '+result.usage.map(x=>`${x.used}/${x.limit} per ${x.window}`).join(' · ')+'. Provider limits are separate.';const exhausted=result.usage.find(x=>x.window==='day'&&x.used>=x.limit)||result.usage.find(x=>x.used>=x.limit);if(exhausted)usage.textContent+=' Next application allowance after '+new Date(exhausted.resetAt).toLocaleString()+'.';}status.textContent=result.configured?'Connected · free-tier project confirmed':'Not connected. Add a free-tier Gemini key below.';
  document.getElementById('languageForm').hidden=result.configured;document.getElementById('disconnectLanguage').hidden=!result.configured;if(result.configured&&typeof resumePreparation==='function')resumePreparation();
 }catch(error){status.textContent=error.message;}
}
document.getElementById('settingsButton').addEventListener('click',()=>refreshLanguageStatus());
document.getElementById('languageForm').addEventListener('submit',async event=>{
 event.preventDefault();const keyField=document.getElementById('geminiKey'),button=document.getElementById('connectLanguage'),status=document.getElementById('languageConnection');
 const body={apiKey:keyField.value.trim(),freeTierConfirmed:document.getElementById('confirmFree').checked,dataUseConsent:document.getElementById('confirmGoogle').checked};
 const done=document.getElementById('settingsClose'),feedback=document.getElementById('languageFeedback');
 button.disabled=true;done.disabled=true;button.textContent='Connecting…';feedback.textContent='Testing your connection. Please wait…';status.textContent='Testing the key with a short Hebrew example…';
 try{const response=await fetch('/api/language/setup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const result=await response.json();if(!response.ok)throw new Error(result.error||'Connection failed.');languageReady=true;keyField.value='';document.getElementById('languageForm').hidden=true;document.getElementById('disconnectLanguage').hidden=false;status.textContent='Connected successfully. Your key has been saved.';status.scrollIntoView({block:'nearest'});if(typeof resumePreparation==='function')resumePreparation();}
 catch(error){languageReady=false;status.textContent='Connection failed — key not saved.';feedback.textContent='Connection failed — '+error.message+' Your key has not been saved.';feedback.focus();feedback.scrollIntoView({block:'nearest'});}
 finally{body.apiKey='';button.disabled=false;done.disabled=false;button.textContent='Connect and test';}
});
document.getElementById('disconnectLanguage').addEventListener('click',async()=>{
 const status=document.getElementById('languageConnection');
 try{const response=await fetch('/api/language/setup',{method:'DELETE'});const result=await response.json();if(!response.ok)throw new Error(result.error||'Could not disconnect.');
  cancelAssistance();languageReady=false;assistanceCacheGeneration++;assistancePending.clear();assistCache.clear();try{readerStorage.removeItem(assistCacheKey);}catch{};await refreshLanguageStatus();
  if(importedMode){revealed.clear();closeAssistant();render();}
 }catch(error){status.textContent=error.message;}
});
refreshLanguageStatus();

// A prepared word may have nikud/meaning but no Latin guide. Enrich only when that
// optional preference is enabled; share the contextual assistance request/cache.
const pronunciationWork=new Map();
async function ensurePronunciationGuide(){
 if(!settings.pron||!active)return;const guide=document.getElementById('pron'),request=selectionRequest();
 if(!request){if(!guide.textContent)guide.textContent='Pronunciation guide unavailable for this selection.';return;}
 if(currentAssist&&!currentAssist.partial){guide.textContent=currentAssist.pronunciation||'Pronunciation guide unavailable for this selection.';return;}
 if(getData(active)[2]){guide.textContent=getData(active)[2];return;}const key=JSON.stringify(request.input);if(pronunciationWork.has(key))return;const epoch=assistEpoch;pronunciationWork.set(key,'pending');guide.textContent='Preparing pronunciation guide…';
 try{const result=await getAssistanceResult(request.input);pronunciationWork.set(key,'done');if(!settings.pron||!active||epoch!==assistEpoch||JSON.stringify(selectionRequest()?.input)!==key)return;applyAssistance(result,request.ids);guide.textContent=result.pronunciation||'Pronunciation guide unavailable for this selection.';}
 catch(error){pronunciationWork.set(key,'retry');globalThis.LanguageDiagnostics?.record(error,'assist');if(settings.pron&&active&&JSON.stringify(selectionRequest()?.input)===key)guide.textContent='Pronunciation guide unavailable. Retry language help if useful.';}
}

function updateWordHelpAvailability(){const paused=AIAvailability.paused();document.getElementById('assistRetry').hidden=paused||document.getElementById('assistRetry').hidden;const request=selectionRequest(),cached=request?readCached(JSON.stringify(request.input),request.input):null;const hasMeaning=!!(cached?.translation||currentAssist?.translation||active&&getData(active)?.[4]);document.getElementById('translationBtn').disabled=paused&&!hasMeaning;if(paused)setAssistStatus('');}
AIAvailability.subscribe(updateWordHelpAvailability);
