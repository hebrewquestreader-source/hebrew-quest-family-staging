// Vocabulary UI uses text nodes only; backups never execute imported HTML.
const vocabularyCardState=new Map();let vocabularyOpened=false;
let vocabularyEntries=[],reviewQueue=[],reviewIndex=0,reviewAnswer=false;
const vocabularyDialog=document.getElementById('vocabularyDialog');
function bankElement(tag,text,className){const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(className)el.className=className;return el;}
function bankButton(text,action){const el=bankElement('button',text,'btn');el.type='button';el.addEventListener('click',action);return el;}
function vocabularyNotice(text,error=false){const el=document.getElementById('vocabularyStatus');if(globalThis.ReaderStatus)ReaderStatus.show('vocabularyStatus',text,{state:error?'retry':'notice',transient:!error&&/^(Language details saved to account[.]|Expression deleted[.]|Backup exported[.]|Imported \d+ expressions[.])/.test(text)});else el.textContent=text;el.style.color=error?'#a13d2f':'';}
async function vocabularyApi(method,body){const options={method,headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined,cache:'no-store'};const {response,result}=typeof ReaderSync!=='undefined'?await ReaderSync.json('/api/vocabulary',options):await fetch('/api/vocabulary',options).then(async response=>({response,result:await response.json()}));if(!response.ok)throw new Error(result.error||'Vocabulary is unavailable.');return result;}
function completeVocabularySentence(ids){return sentenceForSelection(ids);}
function vocabularySnapshot(){
 if(!active)throw new Error('Choose a word or phrase first.');
 let request=selectionRequest(),ids=request?.ids;
 if(active.startsWith('p')){const phrase=phrases[Number(active.slice(1))];ids=[];for(let j=phrase.start;j<=phrase.end;j++)ids.push(`${phrase.i}-${j}`);}
 if(!ids?.length)throw new Error('Choose a word or phrase first.');
 const external=externalSelection(ids);const data=getData(active),now=new Date().toISOString();
 const expression=active.startsWith('p')?data[0]:ids.map(id=>getData(id)[0]).join(' ');
 const nikud=HebrewText.validNikud(expression,data[1])?data[1]:'',sentence=completeVocabularySentence(ids);
 const title=external?.articleTitle||(importedMode?(articleTitle||'Imported article'):'Hebrew Quest practice passage');
 const source=document.getElementById('sourceLink');const url=external?.url??(importedMode&&!source.hidden?source.href:'');const sourceType=external?.sourceType||'article';
 let result=null;if(currentAssist&&request?.input){try{result=HebrewText.result(structuredClone(currentAssist),request.input);}catch{}}
 if(!external&&!importedMode&&data[4]&&(active!=='selection'||selectedPhrases[data[0]])){const phrase=active.startsWith('p')?phrases[Number(active.slice(1))]:null;result={translation:data[4],tokens:[{nikud}],lemma:phrase?.lemma||'',lemmaTranslation:phrase?.lemmaTranslation||''};}
 const preparedMeaning=typeof preparedTranslation==='function'?preparedTranslation(ids):'';
 return {expression,nikud,sentence,title,url,sourceType,now,result,input:request?.input,ids,preparedMeaning};
}
function vocabularyEntryFrom(s,result=null){
 if(result&&s.input)result=HebrewText.result(result,s.input);
 if(result){HebrewText.validate(result.lemma||'',{source:s.expression,mixed:true});if(!HebrewText.related(s.expression,result.lemma||''))result={...result,lemma:'',lemmaTranslation:''};}
 const proposed=result?.tokens?.map(t=>t.nikud).join(' ')||s.nikud,nikud=HebrewText.validNikud(s.expression,proposed)?proposed:'',translation=result?.translation||s.preparedMeaning||'';
 const example={expression:s.expression,nikud,translation,sentence:s.sentence,title:s.title,url:s.url,sourceType:s.sourceType,savedAt:s.now};
 return {expression:s.expression,nikud,translation,lemma:result?.lemma||'',lemmaTranslation:result?.lemmaTranslation||'',incomplete:!nikud||!translation,status:'needs_review',createdAt:s.now,updatedAt:s.now,examples:[example]};
}
const vocabularyJobId=entry=>JSON.stringify([stripLocalNikud(entry.expression),entry.examples[0].url,entry.examples[0].title,entry.examples[0].sentence,entry.examples[0].sourceType||'article']);
let popupVocabularySave=null;
function showVocabularySave(){
 if(!popupVocabularySave||!active)return;let selected;try{selected=vocabularySnapshot();}catch{return;}
 const s=popupVocabularySave;if(selected.expression!==s.expression||selected.sentence!==s.sentence||selected.url!==s.url)return;
 const raw=ReaderSync.state('vocabulary:'+s.id),extra=ReaderSync.state('enrichment:'+s.id),safe=ReaderSync.canLeave();
 const state=raw?(!safe?'action':raw.state==='retry'?'retry':'saving'):extra?'notice':'saved';
 const text=raw?(!safe?'Action required · keep this page open; device storage is unavailable.':raw.state==='retry'?'Sync paused · exact selection kept on this device.':raw.state==='syncing'?'Saving vocabulary…':'Waiting to save vocabulary…'):(globalThis.HQ_BETA?'Saved on this device: ':'Saved to account: ')+s.expression+'.'+(extra?(extra.state==='retry'?' Language details are incomplete; retry in My Vocabulary.':' Language details pending.'):'');
 if(globalThis.ReaderStatus)ReaderStatus.show('vocabSaveStatus',text,{state,transient:!raw&&!extra});else document.getElementById('vocabSaveStatus').textContent=text;
 document.getElementById('vocabSaveRetry').hidden=!(raw?.state==='retry'||extra?.state==='retry'&&!AIAvailability.paused());
}
async function enrichSavedVocabulary(entry,input,priority='background'){const result=await getAssistanceResult(input,undefined,undefined,{priority}),e=entry.examples[0];const enriched=vocabularyEntryFrom({expression:e.expression,nikud:e.nikud,sentence:e.sentence,title:e.title,url:e.url,sourceType:e.sourceType,now:e.savedAt,input},result);return {...enriched,status:entry.status,createdAt:entry.createdAt,...(globalThis.HQ_BETA&&entry.id?{id:entry.id}:{})};}
function retryVocabularyEnrichment(entry){
 if(!AIAvailability.retry())return Promise.reject(Error('New language help is temporarily unavailable. Your saved selection is safe.'));
 const example=entry.examples.find(e=>e.expression===entry.expression)||entry.examples[0];if(!example)return Promise.resolve();const original={...entry,expression:example.expression,nikud:example.nikud||'',translation:example.translation||'',examples:[example]};
 const input={tokens:example.expression.split(/\s+/),context:example.sentence,...(['comprehension','hint','application','feedback','instruction'].includes(example.sourceType)?{helpScope:'exercise_language',sourceType:example.sourceType}:{})},id=vocabularyJobId(original);
 if(typeof ReaderSync!=='undefined'){const key='enrichment:'+id;if(!ReaderSync.state(key))ReaderSync.put('enrichment',id,{entry:original,input,ready:false},{defer:true});return ReaderSync.run(key,{interactive:true});}
 return enrichSavedVocabulary(original,input,'interactive').then(enriched=>vocabularyApi('POST',{enrichOnly:true,entry:enriched}));
}
if(typeof ReaderSync!=='undefined'){
 ReaderSync.register('vocabulary',entry=>vocabularyApi('POST',entry));
 ReaderSync.register('enrichment',async(payload,job)=>{const raw='vocabulary:'+vocabularyJobId(payload.entry);if(ReaderSync.state(raw)){await ReaderSync.run(raw);if(ReaderSync.state(raw))throw Error('Original vocabulary still needs sync. It remains on this device.');}let entry=payload.entry;if(!payload.ready){entry=await enrichSavedVocabulary(entry,payload.input,job.interactive?'interactive':'background');if(!job.checkpoint({...payload,entry,ready:true}))return;}await vocabularyApi('POST',{enrichOnly:true,entry});});
 ReaderSync.subscribe(showVocabularySave);AIAvailability.subscribe(showVocabularySave);
 document.getElementById('vocabSaveRetry')?.addEventListener('click',async()=>{if(!popupVocabularySave)return;AIAvailability.retry();const id=popupVocabularySave.id;await ReaderSync.run('vocabulary:'+id);if(!ReaderSync.state('vocabulary:'+id))await ReaderSync.run('enrichment:'+id,{interactive:true});showVocabularySave();});
}
document.getElementById('saveVocabulary').addEventListener('click',async()=>{
 const button=document.getElementById('saveVocabulary'),status=document.getElementById('vocabSaveStatus');button.disabled=true;
 try{const s=vocabularySnapshot();let entry;try{entry=vocabularyEntryFrom(s,s.result);}catch{entry=vocabularyEntryFrom({...s,nikud:'',preparedMeaning:''});}
  if(typeof ReaderSync!=='undefined'){const id=vocabularyJobId(entry);popupVocabularySave={id,expression:s.expression,sentence:s.sentence,url:s.url};const raw=ReaderSync.put('vocabulary',id,entry,{defer:true});if(!globalThis.HQ_BETA&&entry.incomplete&&s.input&&!ReaderSync.state('enrichment:'+id))ReaderSync.put('enrichment',id,{entry,input:s.input,ready:false},{defer:true});showVocabularySave();const saved=await ReaderSync.run(raw);if(saved.ok&&ReaderSync.state('enrichment:'+id))void ReaderSync.run('enrichment:'+id);showVocabularySave();}
  else{await vocabularyApi('POST',entry);status.textContent='Saved to vocabulary: '+s.expression+'.';if(entry.incomplete&&s.input)try{const enriched=await enrichSavedVocabulary(entry,s.input);await vocabularyApi('POST',{enrichOnly:true,entry:enriched});}catch{status.textContent+=' Original selection saved as incomplete; retry language details in My Vocabulary.';}}
 }catch(error){status.textContent='Could not save: '+error.message;}finally{button.disabled=false;}
});
function pendingVocabulary(entries){if(typeof ReaderSync==='undefined')return entries;const out=[...entries],key=s=>stripLocalNikud(s).replace(/^[\s.,!?;:״׳"'()\[\]{}–—־-]+|[\s.,!?;:״׳"'()\[\]{}–—־-]+$/g,'').toLowerCase();for(const job of ReaderSync.all('vocabulary')){const entry=job.payload;if(!out.some(e=>key(e.expression)===key(entry.expression)))out.push({...entry,id:'device:'+job.key,localOnly:true});}return out;}
async function loadVocabulary(){let entries=[];try{const result=await vocabularyApi('GET');entries=result.entries.map(entry=>HebrewText.vocabulary(entry));}catch(error){entries=pendingVocabulary([]);if(!entries.length)throw error;vocabularyNotice('Needs retry · showing vocabulary kept on this device. Account vocabulary is unavailable.',true);}vocabularyEntries=pendingVocabulary(entries);renderVocabulary();return vocabularyEntries;}
function resetVocabularyReview(){document.getElementById('vocabularyReview').hidden=true;document.getElementById('vocabularyBrowse').hidden=false;}
document.getElementById('myVocabulary').addEventListener('click',async()=>{
 closeAssistant();render();if(!vocabularyOpened)resetVocabularyReview();vocabularyOpened=true;vocabularyDialog.showModal();vocabularyNotice('Loading vocabulary…');
 try{await loadVocabulary();const pending=vocabularyEntries.filter(e=>e.localOnly).length;vocabularyNotice(vocabularyEntries.length+' expression'+(vocabularyEntries.length===1?'':'s')+'.'+(pending?' '+pending+' kept on this device only; needs retry.':''));}catch(e){vocabularyNotice(e.message,true);}
});
document.getElementById('vocabularyClose').addEventListener('click',()=>vocabularyDialog.close());
function appendExample(container,example,showMeaning=false){
 const sentence=bankElement('p',example.sentence,'vocabSentence');if(typeof HebrewInteractions!=='undefined')HebrewInteractions.setContext(sentence,{sourceType:example.sourceType||'vocabulary',articleTitle:example.title,url:example.url,relatedText:'',knownExpression:example.expression,knownNikud:example.nikud});container.append(sentence);
 if(showMeaning&&example.translation)container.append(bankElement('p',example.translation,'vocabEnglish'));
 const meta=bankElement('p',(example.sourceType||'article')+' · '+example.title+' · saved '+new Date(example.savedAt).toLocaleDateString(),'vocabMeta');
 if(example.url){const link=bankElement('a','Read original article ↗');link.href=example.url;link.target='_blank';link.rel='noopener noreferrer';meta.append(document.createTextNode(' · '),link);}
 container.append(meta);
}
async function markVocabulary(entry,status,review=false){await vocabularyApi('PATCH',{id:entry.id,status,review});entry.status=status;}
function renderVocabulary(){
 const list=document.getElementById('vocabularyList');list.replaceChildren();const query=document.getElementById('vocabularySearch').value.trim().toLocaleLowerCase();
 const filtered=vocabularyEntries.filter(e=>[e.expression,e.nikud,e.translation,e.lemma,e.lemmaTranslation,...e.examples.flatMap(x=>[x.sentence,x.title,x.translation])].join(' ').toLocaleLowerCase().includes(query));
 if(!filtered.length){list.append(bankElement('p',query?'No matching expressions.':'No saved vocabulary yet. Choose a word or phrase in the reader and select “Save to Vocabulary”.','intro'));return;}
 for(const entry of filtered){
  const card=bankElement('details',undefined,'vocabCard'),savedView=vocabularyCardState.get(entry.id)||{open:false,pointed:false,translated:false};card.open=savedView.open;card.addEventListener('toggle',()=>{savedView.open=card.open;vocabularyCardState.set(entry.id,savedView);});const summary=bankElement('summary',undefined,'vocabCardSummary');card.append(summary);if(typeof HebrewInteractions!=='undefined')HebrewInteractions.setContext(card,{sourceType:'vocabulary',articleTitle:entry.examples[0]?.title||'Vocabulary Bank',url:entry.examples[0]?.url||'',relatedText:entry.examples[0]?.sentence||'',knownExpression:entry.expression,knownNikud:entry.nikud});let pointed=!!savedView.pointed,translated=!!savedView.translated;
  const word=bankElement('div',stripLocalNikud(entry.expression),'vocabExpression');word.lang='he';word.dir='rtl';word.textContent=pointed?(entry.nikud||entry.expression):stripLocalNikud(entry.expression);summary.append(word);const compactStatus=bankElement('span',entry.status==='needs_review'?'Needs review':'Recognised independently','vocabStatus');summary.append(compactStatus,bankElement('span','Details','vocabDetailsLabel'));
  const meaning=bankElement('div',entry.translation||'Translation not saved yet. Save the expression again from the reader to add it.','vocabEnglish');meaning.dir='ltr';meaning.lang='en';meaning.hidden=!translated;card.append(meaning);
  const form=bankElement('div',undefined,'vocabMeta');form.hidden=!entry.lemma;const formLabel=bankElement('span','Dictionary form: '),formText=bankElement('bdi',entry.lemma);formText.dir='rtl';formText.lang='he';form.append(formLabel,formText);const formMeaning=bankElement('span',' · '+entry.lemmaTranslation);formMeaning.hidden=!translated||!entry.lemmaTranslation;form.append(formMeaning);card.append(form);
  const controls=bankElement('div',undefined,'bankActions');const nikudButton=bankButton(pointed?'Hide nikud':'Reveal nikud',()=>{pointed=!pointed;savedView.pointed=pointed;vocabularyCardState.set(entry.id,savedView);word.textContent=pointed?(entry.nikud||entry.expression):stripLocalNikud(entry.expression);nikudButton.textContent=pointed?'Hide nikud':'Reveal nikud';formText.textContent=pointed?entry.lemma:stripLocalNikud(entry.lemma);});formText.textContent=pointed?entry.lemma:stripLocalNikud(entry.lemma);
  function showMeaning(show){translated=show;savedView.translated=show;vocabularyCardState.set(entry.id,savedView);meaning.hidden=!show;formMeaning.hidden=!show||!entry.lemmaTranslation;meaningButton.textContent=show?'Hide translation':'Reveal translation';examples.replaceChildren();entry.examples.forEach(e=>appendExample(examples,e,show));}
  const meaningButton=bankButton(translated?'Hide translation':'Reveal translation',()=>showMeaning(!translated));controls.append(nikudButton,meaningButton);card.append(controls);
  const reveal=bankButton('Reveal meaning',event=>{event?.preventDefault?.();event?.stopPropagation?.();card.open=true;savedView.open=true;showMeaning(true);});reveal.className='btn vocabQuickReveal';summary.append(reveal);
  if(typeof settings!=='undefined'&&settings.audio)card.append(bankButton('Hear expression',()=>{const Synth=window.SpeechSynthesisUtterance||globalThis.SpeechSynthesisUtterance;if(!window.speechSynthesis||!Synth){vocabularyNotice('Audio is not supported by this browser.');return;}const utterance=new Synth(entry.nikud||entry.expression);utterance.lang='he-IL';utterance.rate=.8;utterance.onerror=()=>vocabularyNotice('Audio could not play. Check the device’s Hebrew voice.');window.speechSynthesis.cancel();window.speechSynthesis.speak(utterance);}));
  if(entry.localOnly)card.append(bankElement('p','Needs retry · saved on this device only.','vocabStatus'));
  if(entry.incomplete){card.append(bankElement('p','Incomplete language help. Original selection retained; invalid fields are withheld.','vocabStatus'));card.append(bankButton('Retry language details',async()=>{vocabularyNotice('Syncing language details…');try{const result=await retryVocabularyEnrichment(entry);if(result?.ok===false)throw Error(result.error?.message||'Language details still need retry.');await loadVocabulary();vocabularyNotice('Language details saved to account.');}catch(e){vocabularyNotice('Original selection retained. '+e.message,true);}}));}
  const status=bankElement('p',entry.status==='needs_review'?'Needs review':'Recognised independently','vocabStatus');card.append(status);
  const actions=bankElement('div',undefined,'bankActions');for(const [value,label] of [['needs_review','Needs review'],['recognised','Recognised independently']]){const b=bankButton(label,async()=>{try{await markVocabulary(entry,value);renderVocabulary();}catch(e){vocabularyNotice(e.message,true);}});b.setAttribute('aria-pressed',String(entry.status===value));actions.append(b);}
  const del=bankButton('Delete',async()=>{if(!confirm('Delete “'+entry.expression+'” and its saved examples? Export JSON first if you want a backup.'))return;try{const related=typeof ReaderSync!=='undefined'?ReaderSync.all().filter(job=>['vocabulary','enrichment'].includes(job.type)&&stripLocalNikud((job.payload.entry||job.payload).expression)===stripLocalNikud(entry.expression)):[];if(related.some(job=>job.type==='vocabulary'&&ReaderSync.isRunning(job.key)))throw Error('This expression is still syncing. Wait for the save to finish, then delete it.');if(!entry.localOnly)await vocabularyApi('DELETE',{id:entry.id});for(const job of related)ReaderSync.remove(job.key);vocabularyEntries=vocabularyEntries.filter(e=>e.id!==entry.id);renderVocabulary();vocabularyNotice('Expression deleted.');}catch(e){vocabularyNotice(e.message,true);}});actions.append(del);card.append(actions);
  const examples=bankElement('div');entry.examples.forEach(e=>appendExample(examples,e,translated));card.append(examples);list.append(card);
 }
}
document.getElementById('vocabularySearch').addEventListener('input',renderVocabulary);
document.getElementById('exportVocabulary').addEventListener('click',async()=>{
 try{await loadVocabulary();const blob=new Blob([JSON.stringify({format:'hebrew-quest-vocabulary',version:1,exportedAt:new Date().toISOString(),entries:vocabularyEntries},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='hebrew-quest-vocabulary-'+new Date().toISOString().slice(0,10)+'.json';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);vocabularyNotice('Backup exported.');}catch(e){vocabularyNotice(e.message,true);}
});
document.getElementById('importVocabulary').addEventListener('click',()=>document.getElementById('vocabularyFile').click());
document.getElementById('vocabularyFile').addEventListener('change',async event=>{
 const file=event.target.files[0];if(!file)return;const button=document.getElementById('importVocabulary');button.disabled=true;let completed=0;
 try{if(file.size>5_000_000)throw new Error('Choose a JSON backup smaller than 5 MB.');const data=JSON.parse(await file.text());if(data.format!=='hebrew-quest-vocabulary'||data.version!==1||!Array.isArray(data.entries)||data.entries.length>2000)throw new Error('Choose a Hebrew Quest vocabulary JSON backup (version 1, up to 2,000 entries).');
  for(const entry of data.entries){if(!Array.isArray(entry.examples)||!entry.examples.length)throw new Error('A backup entry is missing sentence examples.');for(let i=0;i<entry.examples.length;i+=20)await vocabularyApi('POST',{...entry,examples:entry.examples.slice(i,i+20)});completed++;vocabularyNotice('Importing '+completed+' / '+data.entries.length+'…');}
  await loadVocabulary();vocabularyNotice('Imported '+completed+' expressions. Duplicates and their examples were merged.');
 }catch(e){vocabularyNotice('Import stopped after '+completed+' entries: '+e.message,true);try{await loadVocabulary();}catch{}}
 finally{button.disabled=false;event.target.value='';}
});
function startVocabularyReview(){
 reviewQueue=[...vocabularyEntries].sort((a,b)=>(a.status==='needs_review'?0:1)-(b.status==='needs_review'?0:1)||a.updatedAt.localeCompare(b.updatedAt));reviewIndex=0;reviewAnswer=false;document.getElementById('vocabularyBrowse').hidden=true;document.getElementById('vocabularyReview').hidden=false;renderVocabularyReview();
}
document.getElementById('startReview').addEventListener('click',startVocabularyReview);
function renderVocabularyReview(){
 const area=document.getElementById('vocabularyReview');area.replaceChildren();area.append(bankElement('h3','Vocabulary Review'));area.append(bankButton('Back to My Vocabulary',()=>{resetVocabularyReview();renderVocabulary();}));
 if(reviewIndex>=reviewQueue.length){area.append(bankElement('p',reviewQueue.length?'You’ve reviewed this set. Return whenever you want.':'Save an expression to start reviewing.','intro'));return;}
 const entry=reviewQueue[reviewIndex];if(typeof HebrewInteractions!=='undefined')HebrewInteractions.setContext(area,{sourceType:'review',articleTitle:entry.examples[0]?.title||'Vocabulary Review',url:entry.examples[0]?.url||'',relatedText:entry.examples[0]?.sentence||'',knownExpression:entry.expression,knownNikud:entry.nikud});area.append(bankElement('p',(reviewIndex+1)+' of '+reviewQueue.length+' · Recall the meaning before revealing the answer.','intro'));const word=bankElement('div',stripLocalNikud(entry.expression),'vocabExpression');word.lang='he';word.dir='rtl';area.append(word);
 const controls=bankElement('div',undefined,'bankActions');let pointed=false;const nikud=bankButton('Reveal nikud',()=>{pointed=!pointed;word.textContent=pointed?(entry.nikud||entry.expression):stripLocalNikud(entry.expression);nikud.textContent=pointed?'Hide nikud':'Reveal nikud';});controls.append(nikud);
 const answer=bankElement('div',entry.translation||'Translation not saved yet. Use the original sentence to review.','vocabEnglish');answer.hidden=!reviewAnswer;answer.dir='ltr';answer.lang='en';
 const reveal=bankButton('Reveal answer',()=>{reviewAnswer=true;answer.hidden=false;reveal.hidden=true;ratings.hidden=false;});reveal.hidden=reviewAnswer;controls.append(reveal);area.append(controls,answer);
 if(entry.examples[0]){appendExample(area,entry.examples[0]);if(typeof MeaningHints!=='undefined'){const example=entry.examples[0];area.append(MeaningHints.create({request:()=>({expression:entry.expression,context:example.sentence,mode:'lexical'}),source:{articleTitle:example.title,url:example.url}}).root);}}const ratings=bankElement('div',undefined,'bankActions');ratings.hidden=!reviewAnswer;
 for(const [status,label] of [['recognised','Remembered'],['needs_review','Needs review']])ratings.append(bankButton(label,async()=>{for(const b of ratings.children)b.disabled=true;try{await markVocabulary(entry,status,true);reviewIndex++;reviewAnswer=false;renderVocabularyReview();}catch(e){vocabularyNotice(e.message,true);for(const b of ratings.children)b.disabled=false;}}));area.append(ratings);
}

let reportSnapshot=null;
document.getElementById('reportResult').addEventListener('click',()=>{try{const s=vocabularySnapshot();reportSnapshot={selected:s.expression,sentence:s.sentence,title:s.title,url:s.url,result:{analysis:currentAssist?structuredClone(currentAssist):null,error:document.getElementById('assistStatus').textContent,diagnostics:globalThis.LanguageDiagnostics?.snapshot()||[]}};document.getElementById('reportSelected').textContent=s.expression;document.getElementById('reportStatus').textContent='';document.getElementById('reportNote').value='';document.getElementById('reportDialog').showModal();}catch(e){document.getElementById('vocabSaveStatus').textContent=e.message;}});
document.getElementById('cancelReport').addEventListener('click',()=>document.getElementById('reportDialog').close());
document.getElementById('sendReport').addEventListener('click',async()=>{const button=document.getElementById('sendReport');button.disabled=true;try{const response=await fetch('/api/reports',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...reportSnapshot,kind:document.getElementById('reportKind').value,note:document.getElementById('reportNote').value})});const result=await response.json();if(!response.ok)throw new Error(result.error||'Report could not be saved.');document.getElementById('reportStatus').textContent='Report saved. Thank you.';}catch(e){document.getElementById('reportStatus').textContent=e.message;}finally{button.disabled=false;}});
