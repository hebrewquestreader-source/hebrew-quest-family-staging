// Optional morphology: no requests or English disclosure until the learner asks.
globalThis.WordBreakdownUI=(()=>{
 const button=document.getElementById('wordBreakdownButton'),panel=document.getElementById('wordBreakdownPanel'),status=document.getElementById('wordBreakdownStatus'),content=document.getElementById('wordBreakdownContent'),retry=document.getElementById('wordBreakdownRetry'),cache=new Map(),pending=new Map();let epoch=0,visible=false;
 const key='hebrew-quest-word-breakdown-v4';try{for(const [k,v]of JSON.parse(readerStorage.getItem(key)||'[]').slice(-40))cache.set(k,v);}catch{}
 function availability(){let cached=false;try{cached=!!globalThis.WordCatalogue?.abbreviation(input().tokens)||cache.has(JSON.stringify(input()))||!!readCached(JSON.stringify(input()),input())?.analysis?.confident;}catch{}button.disabled=AIAvailability.paused()&&!cached;if(AIAvailability.paused()){retry.hidden=true;if(!content.textContent)status.textContent='';}}
 AIAvailability.subscribe(availability);
 function reset(){epoch++;visible=false;panel.hidden=true;button.setAttribute('aria-expanded','false');content.replaceChildren();status.textContent='';retry.hidden=true;button.disabled=false;availability();}
 function updateSetting(){button.hidden=!settings.wordBreakdown;if(button.hidden)reset();else availability();}
 function input(){const request=selectionRequest();if(request)return request.input;if(!active)throw Error('Select a word or phrase first.');const data=getData(active),phrase=phrases[Number(active.slice(1))],ids=Array.from({length:phrase.end-phrase.start+1},(_,i)=>`${phrase.i}-${phrase.start+i}`);return {tokens:data[0].split(/\s+/),context:sentenceForSelection(ids)};}
 function sharedAnalysis(key,value){
  const analysis=readCached(key,value)?.analysis;
  if(analysis?.confident)try{return WordBreakdown.checked(analysis,value);}catch{}
 }
 async function get(value,force=false){const k=JSON.stringify(value);if(!force&&cache.has(k)){try{return WordBreakdown.checked(cache.get(k),value);}catch{cache.delete(k);}}if(!force){const shared=sharedAnalysis(k,value);if(shared)return shared;}if(pending.has(k))return pending.get(k);const work=(async()=>{
  const core=typeof assistancePending!=='undefined'?assistancePending.get(k):null;
  if(!force&&core){
   AIAvailability.promote('assist',value);
   await core.catch(()=>{});
   const shared=sharedAnalysis(k,value);if(shared)return shared;
   if(JSON.stringify(input())!==k)throw Error('The selection changed.');
  }
  return AIAvailability.run('breakdown',value,async()=>{const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),25000);try{const response=await fetch('/api/breakdown',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(value),signal:controller.signal}),raw=await response.json();if(!response.ok)throw Object.assign(Error(raw.error||"Couldn't analyse this word. Try again."),{requestId:response.headers.get('X-HQ-Request-ID'),code:raw.code,diagnostic:raw.diagnostic,retryCount:raw.retryCount,retryAt:raw.retryAt,quota:raw.quota});const result=WordBreakdown.checked(raw,value);if(result.confident)cache.set(k,result);while(cache.size>40)cache.delete(cache.keys().next().value);try{readerStorage.setItem(key,JSON.stringify([...cache]));}catch{}return result;}finally{clearTimeout(timer);}},{manual:force});
 })();pending.set(k,work);work.finally(()=>pending.delete(k)).catch(()=>{});return work;}
 function el(tag,text,lang){const n=document.createElement(tag);n.textContent=text;if(lang){n.lang=lang;n.dir=lang==='he'?'rtl':'ltr';}return n;}
 function renderCatalogue(entry){
  if(!entry)return;
  function section(title,body){
   const details=el('details','','en');details.className='wordCatalogue';
   details.setAttribute('data-hq-no-interaction','');
   const sources=el('p','Sources: ','en');
   entry.sources.forEach(([label,url],index)=>{
    if(index)sources.append(document.createTextNode(' · '));
    const link=el('a',label,'en');link.href=url;link.dir='auto';sources.append(link);
   });
   details.append(el('summary',title,'en'),body,sources);
   content.append(details);
   return details;
  }
  if(entry.family?.length){
   const words=el('ul','','en');
   for(const [plain,meaning] of entry.family){
    const row=el('li','','en');
    row.append(el('bdi',plain,'he'),document.createTextNode(' — '+meaning));
    words.append(row);
   }
   const details=section('Word Family',words);
   const button=el('button','Show nikud','en');button.type='button';button.className='btn';
   button.setAttribute('aria-pressed','false');
   button.addEventListener('click',()=>{
    const show=button.getAttribute('aria-pressed')!=='true';
    button.setAttribute('aria-pressed',String(show));
    Array.from(words.querySelectorAll('bdi')).forEach((node,index)=>{
     const [plain,,pointed]=entry.family[index];node.textContent=show&&pointed?pointed:plain;
    });
   });
   details.append(button);
  }
  function note(text){
   const paragraph=el('p','','en');
   for(const part of text.split(/([א-ת]+(?: [א-ת]+)*)/u)){
    paragraph.append(/[א-ת]/u.test(part)?el('bdi',part,'he'):document.createTextNode(part));
   }
   return paragraph;
  }
  if(entry.expansion){
   const body=el('div','','en'),line=el('p','Abbreviation expansion: ','en');
   line.append(el('bdi',entry.expansion,'he'));
   body.append(line,note(entry.note));
   section('Word Origins',body);
  }
  if(entry.origin){
   section('Word Origins',note('Loanword origin and history. '+entry.origin));
  }
  if(entry.figurative)section('Figurative meaning',note(entry.figurative));
 }

 function render(result,value){content.replaceChildren();if(!result.confident){status.textContent='This grammatical analysis could not be determined confidently. Your original selection is unchanged.';retry.hidden=false;return;}
  status.textContent='AI grammatical analysis · not independently verified.';const list=document.createElement('ul');
  if(result.lemma){const line=document.createElement('li');line.append(el('span',result.lemma,'he'),el('span',' — '+result.lemmaMeaning+(result.category==='verb'?' (infinitive)':' (dictionary form)'),'en'));list.append(line);}
  if(result.lemmaWithheld||result.rootWithheld)content.append(el('p',result.lemmaWithheld?'Infinitive unavailable; selected-form details are shown below.':'Root withheld: it could not be checked confidently.','en'));retry.hidden=!(result.lemmaWithheld||result.rootWithheld);if(result.root){const line=document.createElement('li');line.append(el('span','Root: ','en'),el('span',result.root,'he'));list.append(line);}
  const labels={gender:'Gender',number:'Number',state:'State',possession:'Possessive suffix',tense:'Verb form',person:'Person',binyan:'Binyan (verb pattern)'};
  if(['noun','adjective','adverb','preposition','verb','expression'].includes(result.category))list.append(el('li','Part of speech: '+result.category,'en'));
  for(const f of result.features){if(f.name==='state'&&f.value==='absolute')continue;list.append(el('li',labels[f.name]+': '+(f.name==='gender'&&f.value==='common'?'not distinguished in this form':f.value),'en'));}
  for(const part of result.parts){if(result.category!=='verb'&&result.parts.length===1&&HebrewText.unpoint(part.text).replace(/[^א-ת]/g,'')===HebrewText.unpoint(result.selected).replace(/[^א-ת]/g,''))continue;const line=document.createElement('li');line.append(el('span',part.text,'he'),el('span',' — '+part.meaning+' ('+part.kind+')','en'));list.append(line);}content.append(list);
  if(typeof HebrewInteractions!=='undefined'){HebrewInteractions.setContext(content,{sourceType:'instruction',relatedText:value.context,protected:value.helpScope==='exercise_language',articleTitle:articleTitle||'Word Breakdown'});HebrewInteractions.scan(content);}
  renderCatalogue(globalThis.WordCatalogue?.match(result));
 }
 async function open(force=false){if(!settings.wordBreakdown)return;if(visible&&!force){reset();return;}const ticket=++epoch;visible=true;panel.hidden=false;button.setAttribute('aria-expanded','true');status.textContent='Preparing optional Word Breakdown…';content.replaceChildren();retry.hidden=true;let value;try{value=input();const entry=globalThis.WordCatalogue?.abbreviation(value.tokens);if(entry){status.textContent='Verified abbreviation · catalogue';renderCatalogue(entry);return;}const result=await get(value,force);if(ticket!==epoch||!active||!settings.wordBreakdown||JSON.stringify(input())!==JSON.stringify(value))return;render(result,value);}catch(error){if(ticket===epoch){globalThis.LanguageDiagnostics?.record(error,'breakdown');status.textContent=error.code==='simulator_missing'?error.message:['quota','local_quota'].includes(error.code)?'':['setup_required','breakdown_timeout'].includes(error.code)?error.message:['uncertain'].includes(error.code)?'This reading is uncertain. Try selecting a longer phrase.':['breakdown_unavailable','unavailable'].includes(error.code)?'Word Breakdown is temporarily unavailable. Try again later.':'Word Breakdown could not verify this form. Any available word help is still shown.';retry.hidden=error.code==='simulator_missing'||AIAvailability.paused();availability();}}}
 button.addEventListener('click',()=>open());retry.addEventListener('click',()=>open(true));updateSetting();return {reset,updateSetting,get};
})();
