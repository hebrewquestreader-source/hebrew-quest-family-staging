// Conservative phrase proposals, never a replacement for source text or a full lexicon.
globalThis.ExpressionText=(()=>{
 const dictionary=[
  ['למרות זאת','לַמְרוֹת זֹאת','nevertheless / despite that'],['ולמרות זאת','וְלַמְרוֹת זֹאת','and nevertheless / and despite that'],['עם זאת','עִם זֹאת','however / nevertheless'],['לעומת זאת','לְעֻמַּת זֹאת','in contrast'],['בכל זאת','בְּכָל זֹאת','nevertheless / all the same'],
  ['נוגע ללב','נוֹגֵעַ לַלֵּב','touching / moving'],['בא לידי ביטוי','בָּא לִידֵי בִּטּוּי','was expressed / was reflected'],['על אף','עַל אַף','despite'],['לקח בחשבון','לָקַח בְּחֶשְׁבּוֹן','took into account'],['יצא לפועל','יָצָא לַפֹּעַל','was carried out / came to fruition'],['בין היתר','בֵּין הַיֶּתֶר','among other things'],['שם דגש על','שָׂם דָּגֵשׁ עַל','emphasised / placed emphasis on']
 ].map(([plain,nikud,translation])=>({plain:plain.split(' '),pointed:nikud.split(' '),translation,lemma:nikud,lemmaTranslation:translation,hint:'נסו לחשוב על המשמעות של המילים יחד במשפט.',pronunciation:''}));
 function token(value){if(/[@#]|https?:\/\/|www\./iu.test(String(value)))return null;const m=String(value).match(/^([^\p{L}\p{M}]*)([א-ת\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]+)([^\p{L}\p{M}]*)$/u);if(!m)return null;try{HebrewText.validate(m[2],{required:true});}catch{return null;}return {leading:m[1],word:HebrewText.unpoint(m[2]),trailing:m[3]};}
 function safeContext(plain,context=''){
  // Literal physical/technical uses are deliberately not grouped automatically.
  if(plain==='נוגע ללב'&&/(?:מנתח|ניתוח|צנתר|אלקטרודה|עורק|שריר הלב)/u.test(context))return false;
  if(plain==='על אף'&&/(?:מסכה|משקפיים|נחיר|כיסוי האף)/u.test(context))return false;
  if(plain==='בין היתר'&&/בין היתר (?:בנייה|בניה|עסקה)/u.test(context))return false;
  if(plain==='שם דגש על'&&/(?:ניקוד|דקדוק|האות|העיצור)/u.test(context))return false;
  return true;
 }
 function known(tokens,context=''){
  const parts=tokens.map(token);if(parts.some(p=>!p)||parts.slice(0,-1).some(p=>p.trailing)||parts.slice(1).some(p=>p.leading))return null;
  const entry=dictionary.find(e=>e.plain.length===tokens.length&&e.plain.every((w,i)=>w===parts[i].word));if(!entry||!safeContext(entry.plain.join(' '),context))return null;
  return {...entry,...(entry.plain[0]==='ולמרות'?{lemma:'לַמְרוֹת זֹאת'}:{}),confident:true,tokens:tokens.map((original,i)=>({original,nikud:parts[i].leading+entry.pointed[i]+parts[i].trailing}))};
 }
 function checked(tokens,candidate,context=''){
  if(!candidate||candidate.confident!==true||!Number.isInteger(candidate.start)||!Number.isInteger(candidate.end)||candidate.start<0||candidate.end>=tokens.length||candidate.end-candidate.start<1||candidate.end-candidate.start>4||typeof candidate.text!=='string')return null;
  const picked=tokens.slice(candidate.start,candidate.end+1),parts=picked.map(token);if(parts.some(p=>!p)||parts.slice(0,-1).some(p=>p.trailing)||parts.slice(1).some(p=>p.leading)||candidate.text!==picked.join(' '))return null;
  if(!safeContext(parts.map(p=>p.word).join(' '),context))return null;
  return {start:candidate.start,end:candidate.end,text:candidate.text,confident:true};
 }
 function nonoverlap(candidates,limit=3){const chosen=[];for(const c of [...candidates].sort((a,b)=>Number(b.source==='dictionary')-Number(a.source==='dictionary')||(b.end-b.start)-(a.end-a.start)||a.start-b.start))if(!chosen.some(x=>c.start<=x.end&&c.end>=x.start)){chosen.push(c);if(chosen.length>=limit)break;}return chosen.sort((a,b)=>a.start-b.start);}
 const byFirst=new Map();for(const entry of dictionary){const first=entry.plain[0];if(!byFirst.has(first))byFirst.set(first,[]);byFirst.get(first).push(entry);}
 function detect(tokens,context=tokens.join(' ')){const out=[];for(let start=0;start<tokens.length;start++){const first=HebrewText.unpoint(tokens[start]).replace(/^[^א-ת]+|[^א-ת]+$/gu,'');for(const entry of byFirst.get(first)||[]){const size=entry.plain.length;if(start+size<=tokens.length&&known(tokens.slice(start,start+size),context))out.push({start,end:start+size-1,text:tokens.slice(start,start+size).join(' '),confident:true,source:'dictionary'});}}return nonoverlap(out);}
 return {dictionary,known,checked,nonoverlap,detect};
})();
