// Prepare contextual word meanings alongside nikud in one bounded reading-window request.
const preparationCacheKey='hebrew-quest-prepared-language-v5';
let preparationCache=new Map();try{const saved=JSON.parse(readerStorage.getItem(preparationCacheKey)||'[]');if(Array.isArray(saved))preparationCache=new Map(saved.slice(-100));}catch{}
let preparationInvalid=false;
let preparationGeneration=0,preparationJobs=[],preparationById=new Map(),preparedMeanings=new Map(),preparedForms=new Map(),preparationQueue=[],preparationBusy=false,preparationPaused=false,preparationRecent=[],preparationTimer=null;
// At most 36 speculative tokens/article: one warm start and two earned windows.
const preparationPolicy={batchWords:12,maxBatches:3,lookupsPerWindow:4,idleMs:2000};
let preparationStarted=0,preparationLookups=0,preparationBackgroundUntil=0;
function savePreparationCache(key,value){preparationCache.delete(key);preparationCache.set(key,value);while(preparationCache.size>100)preparationCache.delete(preparationCache.keys().next().value);try{readerStorage.setItem(preparationCacheKey,JSON.stringify([...preparationCache]));}catch{}}
function preparationStatus(message){const el=document.getElementById('preparationStatus');if(el)el.textContent=message;}
function updatePreparationStatus(){if(!importedMode)return;const all=rows.flat().filter(w=>/[א-ת]/.test(w[0])),ready=all.filter(w=>/[\u05b0-\u05bc\u05c1\u05c2\u05c7]/.test(w[1])).length;preparationStatus(!settings.prepareAhead?'Nikud preparation paused.':preparationPaused?`Preparation paused to protect word-help requests. ${ready} words are ready for instant taps.`:`${ready} words ready for instant nikud · meanings prepare too${preparationBusy?' · preparing nearby text…':(preparationInvalid?' · malformed results rejected; original text retained':' · nearby words prepare selectively')}`);}
function preparationJob(ids,tokens,generation){
 const groups=new Map();for(const id of ids){const row=id.split('-')[0];if(!groups.has(row))groups.set(row,[]);groups.get(row).push(id);}const context=[...groups.values()].map(group=>sentenceForSelection(group)).join(' '),cacheKey=JSON.stringify({tokens,context});let resolve;const promise=new Promise(r=>resolve=r);return {generation,ids,tokens,context,cacheKey,promise,resolve,queued:false,finished:false};
}
function usePreparationCache(job){const cached=preparationCache.get(job.cacheKey);if(!cached)return false;try{finishPreparation(job,cached,false);return true;}catch{preparationCache.delete(job.cacheKey);return false;}}
function beginPreparation(){
 for(const job of preparationQueue)job.resolve(null);clearTimeout(preparationTimer);preparationStarted=0;preparationLookups=0;preparationGeneration++;if(typeof AIAvailability!=='undefined')AIAvailability.cancelQueued();const generation=preparationGeneration;preparationJobs=[];preparationById=new Map();preparedMeanings=new Map();preparedForms=new Map();preparationQueue=[];preparationPaused=typeof AIAvailability!=='undefined'&&AIAvailability.paused();
 if(!importedMode||!settings.prepareAhead){updatePreparationStatus();return;}
 const restored=new Set();
 // Reuse exact v30 paragraph-window caches before changing batching; never
 // discard previously generated language help to obtain a lower call count.
 rows.forEach((row,i)=>{for(let core=0;core<row.length;core+=36){const ids=[],tokens=[];for(let j=Math.max(0,core-3);j<Math.min(row.length,core+39);j++)if(row[j][0].length<=100){ids.push(`${i}-${j}`);tokens.push(row[j][0]);}while(tokens.join(' ').length>1500){tokens.pop();ids.pop();}if(!tokens.length)continue;const job=preparationJob(ids,tokens,generation);if(usePreparationCache(job))ids.forEach(id=>restored.add(id));}});
 let oldIds=[],oldTokens=[];const restoreOld=()=>{if(oldTokens.length){const j=preparationJob(oldIds,oldTokens,generation);if(usePreparationCache(j))oldIds.forEach(id=>restored.add(id));}oldIds=[];oldTokens=[];};rows.forEach((row,i)=>row.forEach((w,j)=>{if(w[0].length>100){restoreOld();return;}if(oldTokens.length>=40||[...oldTokens,w[0]].join(' ').length>1500)restoreOld();oldIds.push(`${i}-${j}`);oldTokens.push(w[0]);}));restoreOld();
 let ids=[],tokens=[];const flush=()=>{if(!tokens.length)return;const job=preparationJob(ids,tokens,generation);ids=[];tokens=[];preparationJobs.push(job);for(const id of job.ids)preparationById.set(id,job);if(usePreparationCache(job)){}else if(job.ids.every(id=>restored.has(id))||job.context.length>16000||!job.context.includes(job.tokens.join(' '))||!job.tokens.some(t=>/[א-ת]/.test(t))){job.finished=true;job.resolve(null);}};
 // Consecutive, non-overlapping batches may span adjacent paragraphs. Context
 // retains complete sentences; expression boundaries are checked per source row.
 rows.forEach((row,i)=>row.forEach((word,j)=>{const token=word[0];if(token.length>100){flush();return;}if(tokens.length>=preparationPolicy.batchWords||[...tokens,token].join(' ').length>1500)flush();ids.push(`${i}-${j}`);tokens.push(token);}));flush();
 if(restored.size||preparationJobs.some(job=>job.finished&&job.ids.some(id=>HebrewText.validNikud(getData(id)[0],getData(id)[1]))))preparationStarted=1;
 if(languageReady===true&&!preparationPaused)schedulePreparation();updatePreparationStatus();
}
function finishPreparation(job,result,save=true){
 if(!Array.isArray(result?.tokens))throw Object.assign(Error('Invalid preparation response.'),{code:'invalid_result'});
 const valid=result.tokens.filter(item=>Number.isInteger(item.index)&&job.ids[item.index]&&item.original===job.tokens[item.index]&&typeof item.nikud==='string'&&HebrewText.validNikud(item.original,item.nikud));
 result={...result,tokens:valid,expressions:typeof ExpressionText==='undefined'?[]:(Array.isArray(result.expressions)?result.expressions:[]).map(c=>ExpressionText.checked(job.tokens,c,job.context)).filter(Boolean)};
 if(!save&&!result.tokens.length&&!result.expressions.length)throw Error('Empty cached preparation.');
 if(result.rejected>0)preparationInvalid=true;
 if((result.tokens||[]).some(item=>!HebrewText.validNikud(item.original,item.nikud)))preparationInvalid=true;
 if(job.generation===preparationGeneration){
  if(typeof ExpressionUI!=='undefined')ExpressionUI.enhance(job,result);
  for(const item of result.tokens||[]){if(!Number.isInteger(item.index)||!job.ids[item.index]||item.original!==job.tokens[item.index]||typeof item.nikud!=='string'||!HebrewText.validNikud(item.original,item.nikud))continue;const [i,j]=job.ids[item.index].split('-').map(Number);const data=getData(job.ids[item.index]);if(data?.[0]===item.original){data[1]=item.nikud;if(typeof item.translation==='string'&&item.translation.length<=180&&/[A-Za-z]/.test(item.translation))preparedMeanings.set(job.ids[item.index],item.translation);if(item.lemmaChecked===true){try{const checked=HebrewText.result({confident:true,partial:true,tokens:[{original:item.original,nikud:item.nikud}],hint:'',translation:item.translation||'',pronunciation:'',lemma:item.lemma||'',lemmaTranslation:item.lemmaTranslation||'',lemmaKind:item.lemmaKind},{tokens:[item.original],context:job.context});preparedForms.set(job.ids[item.index],checked);}catch{preparationInvalid=true;}}}}
 }
 job.finished=true;job.resolve(result);if(save&&(result.tokens.length||result.expressions.length))savePreparationCache(job.cacheKey,result);updatePreparationStatus();
}
function queuePreparation(job,urgent=false){if(!job||job.finished||job.generation!==preparationGeneration||preparationPaused||typeof AIAvailability!=='undefined'&&AIAvailability.paused())return;if(job.retryable){job.promise=new Promise(resolve=>job.resolve=resolve);job.retryable=false;}if(urgent)job.urgent=true;if(!job.queued){job.queued=true;if(urgent)preparationQueue.unshift(job);else preparationQueue.push(job);}else if(urgent){preparationQueue=preparationQueue.filter(j=>j!==job);preparationQueue.unshift(job);}schedulePreparation();}
function schedulePreparation(){clearTimeout(preparationTimer);preparationTimer=setTimeout(()=>{scanReadingWindow();pumpPreparation();},preparationPolicy.idleMs);}
async function pumpPreparation(){
 if(preparationStarted>=preparationPolicy.maxBatches||preparationStarted>Math.floor(preparationLookups/preparationPolicy.lookupsPerWindow)||Date.now()<preparationBackgroundUntil||document.hidden||Number(settings.interactiveReservePercent)===100||preparationBusy||preparationPaused||typeof AIAvailability!=='undefined'&&AIAvailability.paused()||!settings.prepareAhead||languageReady!==true)return;
 if(typeof AIAvailability!=='undefined'&&!AIAvailability.interactiveIdle()){schedulePreparation();return;}
 preparationRecent=preparationRecent.filter(t=>Date.now()-t<60000);
 if(preparationRecent.length>=1){clearTimeout(preparationTimer);preparationTimer=setTimeout(pumpPreparation,Math.max(1000,60050-(Date.now()-preparationRecent[0])));updatePreparationStatus();return;}
 const job=preparationQueue.shift();if(!job)return;if(job.finished||job.generation!==preparationGeneration){pumpPreparation();return;}
 if(usePreparationCache(job)){pumpPreparation();return;}
 preparationBusy=true;job.running=true;preparationStarted++;preparationRecent.push(Date.now());updatePreparationStatus();
 try{const work=async()=>{const response=await fetch('/api/prepare',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tokens:job.tokens,context:job.context,...(job.helpScope?{helpScope:job.helpScope}:{})})});const result=await response.json();
  if(!response.ok){if(result.code==='invalid_result'||result.code==='invalid_hebrew')preparationInvalid=true;if(result.code==='quota'||result.code==='local_quota')preparationPaused=true;throw Object.assign(new Error(result.error||'Preparation unavailable.'),{code:result.code,retryAt:result.retryAt,quota:result.quota});}if(!Array.isArray(result?.tokens))throw Object.assign(Error('Invalid preparation response.'),{code:'invalid_result'});return result;};const result=typeof AIAvailability==='undefined'?await work():await AIAvailability.run('prepare',{tokens:job.tokens,context:job.context,...(job.helpScope?{helpScope:job.helpScope}:{})},work,{priority:'background',valid:()=>job.generation===preparationGeneration&&!document.hidden&&settings.prepareAhead&&Number(settings.interactiveReservePercent)!==100});
  finishPreparation(job,result);
 }catch(error){if(error.code==='background_paused'){preparationBackgroundUntil=Number(error.retryAt)||Date.now()+60000;}preparationPaused=preparationPaused||typeof AIAvailability!=='undefined'&&AIAvailability.paused();job.finished=!preparationPaused;job.retryable=!!preparationPaused;job.queued=false;job.resolve(null);if(preparationPaused){for(const waiting of preparationQueue){waiting.retryable=true;waiting.queued=false;waiting.resolve(null);}preparationQueue=[];}}
 finally{job.running=false;preparationBusy=false;updatePreparationStatus();pumpPreparation();}
}
async function preparedSelection(ids){
 const ready=()=>ids.every(id=>HebrewText.validNikud(getData(id)[0],getData(id)[1]));
 if(ready())return ids.map(id=>({original:getData(id)[0],nikud:getData(id)[1]}));
 const jobs=[...new Set(ids.map(id=>preparationById.get(id)).filter(Boolean))];
 // Only wait for work already in flight for this exact token. A tap never
 // starts a full batch or waits behind another preparation window.
 if(!jobs.length||jobs.some(j=>!j.running))return null;
 await Promise.all(jobs.map(job=>job.promise));
 return ready()?ids.map(id=>({original:getData(id)[0],nikud:getData(id)[1]})):null;
}
function scanReadingWindow(){
 if(!importedMode||!settings.prepareAhead||languageReady!==true||preparationQueue.length||preparationBusy||preparationStarted>=preparationPolicy.maxBatches||preparationStarted>Math.floor(preparationLookups/preparationPolicy.lookupsPerWindow))return;
 const candidates=[];for(const p of readingSurface.querySelectorAll('[data-reading-row]')){const box=p.getBoundingClientRect();if(box.bottom<0||box.top>window.innerHeight)continue;for(const word of p.querySelectorAll('.word')){const job=preparationById.get(word.dataset.id);if(job&&!job.finished&&!job.queued&&!candidates.includes(job))candidates.push(job);}}
 const job=candidates[0]||(!preparationStarted?preparationJobs.find(j=>!j.finished):null);if(job)queuePreparation(job);
}
function notePreparationLookup(){preparationLookups++;schedulePreparation();}

let scanTimer;window.addEventListener('scroll',()=>{clearTimeout(scanTimer);scanTimer=setTimeout(schedulePreparation,120);},{passive:true});

function resumePreparation(){if(typeof AIAvailability!=='undefined'&&AIAvailability.paused())return;preparationPaused=false;if(typeof HebrewInteractions!=='undefined')HebrewInteractions.refreshPreparation();if(!importedMode||!settings.prepareAhead)return;if(!preparationJobs.length){beginPreparation();return;}schedulePreparation();}
if(importedMode&&languageReady===true)beginPreparation();

function preparedTranslation(ids){return ids.length===1?preparedMeanings.get(ids[0])||null:null;}

// Hints, questions and breakdowns stay interactive on demand. Displaying AI
// content must not recursively spend more requests preparing that content.
function registerExternalPreparation(block){}

function preparedReusable(ids){return ids.length===1?preparedForms.get(ids[0])||null:null;}

if(typeof AIAvailability!=='undefined')AIAvailability.subscribe(hold=>{preparationPaused=!!hold&&AIAvailability.paused();if(!preparationPaused){updatePreparationStatus();return;}for(const job of preparationQueue){job.queued=false;job.retryable=true;job.resolve(null);}preparationQueue=[];updatePreparationStatus();});

document.addEventListener('visibilitychange',()=>{if(document.hidden){clearTimeout(preparationTimer);for(const job of preparationQueue){job.queued=false;job.resolve(null);}preparationQueue=[];AIAvailability.cancelQueued();}else schedulePreparation();});
