// Shared display gate. Meaning/naturalness/context are also audited by the tutor;
// these deterministic checks catch structure-only clues, repetition and visible leaks.
globalThis.SemanticHints=(()=>{
 const stop=new Set(['של','את','על','עם','אל','זה','זאת','הזה','הזאת','הוא','היא','הם','הן','לא','כן','כל','גם','יש','אין','מה','מי','איך','כדי','אשר','או','אם','כי','כמו','יותר','מאוד','אחד']);
 const plain=s=>HebrewText.unpoint(s).replace(/[ךםןףץ]/g,c=>({'ך':'כ','ם':'מ','ן':'נ','ף':'פ','ץ':'צ'}[c]));
 const words=s=>(plain(s).match(/[א-ת]+/g)||[]).filter(w=>w.length>=3&&!stop.has(w));
 function stems(w){let items=new Set([w]);for(let n=0;n<3;n++)for(const x of [...items]){if(/^[והבכלמש]/.test(x)&&x.length>3)items.add(x.slice(1));for(const suffix of ['יהמ','יהנ','ימ','ות','נו','כמ','כנ','המ','הנ','ה','ו','י'])if(x.endsWith(suffix)&&x.length-suffix.length>=3)items.add(x.slice(0,-suffix.length));}return new Set([...items].map(x=>x.replace(/[וי]/g,'')).filter(x=>x.length>=3));}
 function related(a,b){if(a===b||HebrewText.related(a,b))return true;const x=stems(a),y=stems(b);return [...x].some(t=>y.has(t));}
 function validate(text,input){
  if(typeof text!=='string'||text.length>240)throw new Error('Hint withheld: missing or oversized clue.');const hint=HebrewText.validate(text,{required:true});const unpointed=HebrewText.unpoint(hint),list=words(unpointed);
  if(unpointed.trim().split(/\s+/).length<3||unpointed.trim().split(/\s+/).length>24||!list.length)throw new Error('Hint withheld: the clue is too vague or too complex.');
  if(/מורכב[תים]* מ|המילה מורכבת|תחילית|סיומת|יידוע|הידיעה|[הב]שורש|שורש המילה|בניין|בנינ|זמן עבר|זמן הווה|זמן עתיד|גוף ראשון|גוף שני|גוף שלישי|שם עצם|שם פועל|אותיות|אות ראשונה|אות אחרונה|מבנה המילה|מבחינה דקדוקית|תרגום|באנגלית|נסו להבין|נחשו את|לפי ההקשר בלבד/.test(unpointed))throw new Error('Hint withheld: a meaning clue is needed, not word structure or translation.');
  if(input.mode!=='comprehension')for(const target of words(input.expression))for(const clue of list)if(related(target,clue))throw new Error('Hint withheld: it repeats the selected expression or a close derivative.');
  if(input.mode==='comprehension'&&plain(unpointed).trim()===plain(input.expression).trim())throw new Error('Hint withheld: it repeats the question.');
  if(input.answer&&/[א-ת]/.test(input.answer)){const answer=plain(input.answer).replace(/[^א-ת\s]/g,'').trim(),clue=plain(unpointed).replace(/[^א-ת\s]/g,'').trim();if(answer.length>=3&&clue.includes(answer))throw new Error('Hint withheld: it reveals the exercise answer.');}
  if(!list.some(w=>!['קשור','משהו','מישהו','מילה','משפט','הקשר','משמעות'].some(g=>related(g,w))))throw new Error('Hint withheld: no useful semantic information.');
  return hint.normalize('NFC');
 }
 function pair(value,input){if(!value||!Array.isArray(value.hints)||value.hints.length!==2)throw new Error('Two progressive meaning clues are required.');const hints=value.hints.map(h=>validate(h,input));if(plain(hints[0])===plain(hints[1]))throw new Error('The second hint must offer a more specific clue.');return {hints};}
 return {validate,pair};
})();
