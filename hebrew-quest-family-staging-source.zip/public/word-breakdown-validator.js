// Structural checks constrain AI proposals. They do not independently verify grammar.
globalThis.WordBreakdown=(()=>{
 const categories=['noun','adjective','verb','preposition','expression','adverb','other'];
 const values={gender:['masculine','feminine','common'],number:['singular','plural','dual'],state:['absolute','construct'],possession:['my','your (masculine singular)','your (feminine singular)','his','her','our','your (plural)','their'],tense:['past','present','future','imperative','infinitive'],person:['first','second','third'],binyan:['Paal','Nifal','Piel','Pual','Hifil','Hufal','Hitpael']};
 const applicable={adjective:['gender','number','state'],noun:['gender','number','state','possession'],verb:['gender','number','tense','person','binyan'],preposition:['possession'],expression:[],adverb:[],other:[]};
 function gloss(value){if(typeof value!=='string'||value.length>160||value.split(/\s+/).length>16||!/[A-Za-z]/.test(value)||!/^[\p{Script=Latin}\p{N}\p{P}\p{Z}\s]+$/u.test(value)||/[\p{Cc}\p{Cf}]/u.test(value))throw Error('Invalid English explanation.');return value;}
 const letters=s=>HebrewText.unpoint(s).replace(/[^\p{L}\p{N}]/gu,'').replace(/[ךםןףץ]/g,c=>({'ך':'כ','ם':'מ','ן':'נ','ף':'פ','ץ':'צ'}[c]));
 function field(name,work){try{return work();}catch(error){error.field=name;throw error;}}
 function rootText(value){return field('root',()=>{if(typeof value!=='string'||value.length>40)throw Error('Invalid root type.');const text=HebrewText.validate(value,{required:true}).trim();if(!/^[א-ת][\u05c1\u05c2]?(?:\s*(?:[-־.·–—]\s*)?[א-ת][\u05c1\u05c2]?){2,3}$/u.test(text))throw Error('Invalid Hebrew root notation.');return text.replace(/[\s.־·–—-]/gu,'');});}
 function checked(raw,input){
  const selected=input.tokens.join(' ');if(!raw||raw.selected!==selected||typeof raw.confident!=='boolean'){const e=Error('The analysis did not match the exact selection.');e.field='selected';throw e;}
  const uncertain={selected,confident:false,category:'other',lemma:'',lemmaMeaning:'',root:'',lemmaConfident:false,rootConfident:false,features:[],parts:[]};
  if(!raw.confident)return uncertain;
  if(!categories.includes(raw.category)||!Array.isArray(raw.features)||raw.features.length>7||!Array.isArray(raw.parts)||raw.parts.length>12)throw Error('Incomplete grammatical analysis.');
  const category=raw.category;let lemma='',lemmaMeaning='',root='',rootWithheld=false,lemmaWithheld=raw.lemmaWithheld===true;
  if(raw.lemmaConfident===true&&raw.lemma){lemma=field('lemma',()=>HebrewText.validate(raw.lemma,{source:selected,mixed:true,required:true,pointed:true}));if(!HebrewText.related(selected,lemma)){const e=Error('The proposed dictionary form could not be related to the selection.');e.field='lemma';throw e;}lemmaMeaning=field('lemmaMeaning',()=>gloss(raw.lemmaMeaning));
   // The contract requires an infinitive for verbs. A related finite stem is
   // not an infinitive. Withhold it; never add a guessed lamed or gloss.
   if(category==='verb'&&!/^ל[א-ת]{2,}$/u.test(HebrewText.unpoint(lemma))){lemma='';lemmaMeaning='';lemmaWithheld=true;}
  }
  if(raw.rootConfident===true&&raw.root){if(category!=='verb'){const e=Error('A root is only applicable here to a verb.');e.field='root';throw e;}root=rootText(raw.root);}
  const proposedTense=raw.features.find(f=>f?.name==='tense'&&f.confident===true)?.value;
  const seen=new Set(),features=[];for(let f of raw.features){if(!f||typeof f.confident!=='boolean'){const e=Error('Invalid feature type.');e.field='features';throw e;}if(f.confident!==true)continue;if(f.name==='binyan'&&typeof f.value==='string'){const alias={פעל:'Paal',קל:'Paal',נפעל:'Nifal',פיעל:'Piel',פועל:'Pual',הפעיל:'Hifil',הופעל:'Hufal',התפעל:'Hitpael'};f={...f,value:alias[HebrewText.unpoint(f.value)]||f.value};}if(!applicable[category].includes(f.name)||!values[f.name]?.includes(f.value)||seen.has(f.name)){const e=Error('The grammatical categories were inconsistent.');e.field='features';throw e;}if(category==='verb'&&(['present','infinitive'].includes(proposedTense)&&f.name==='person'||proposedTense==='infinitive'&&['gender','number'].includes(f.name)))continue;seen.add(f.name);features.push({name:f.name,value:f.value,confident:true});}
  // Check a proposed root against regular infinitive templates. Weak/assimilated
  // roots that cannot be checked here are withheld, never inferred or replaced.
  if(root){const pattern=features.find(f=>f.name==='binyan')?.value,inf=letters(lemma),r=letters(root);let stem='';
   if(pattern==='Paal'&&inf.startsWith('ל')){const b=inf.slice(1);if(b.length===3)stem=b;if(b.length===4&&b[2]==='ו')stem=b.slice(0,2)+b.slice(3);}
   if(pattern==='Piel'&&inf.startsWith('ל')&&[4,5].includes(inf.length))stem=inf.slice(1);
   if(pattern==='Hifil'&&inf.startsWith('לה')){const b=inf.slice(2);if(b.length===4&&b[2]==='י')stem=b.slice(0,2)+b.slice(3);}
   if(pattern==='Nifal'&&inf.startsWith('לה')&&inf.length===5)stem=inf.slice(2);
   if(pattern==='Nifal'&&inf.startsWith('להי')&&inf.length===6)stem=inf.slice(3);
   if(pattern==='Hitpael'&&inf.startsWith('להת')){const b=inf.slice(3);if(b.length===3)stem=b;else if(b.length===4&&b[1]==='ו'&&/ו\u05b9/u.test(lemma.normalize('NFD')))stem=b[0]+b.slice(2);}
   // Passive binyanim often lack a usable infinitive. A vowelled surface
   // stem can supply structural evidence instead; never manufacture an infinitive.
   if(!lemma&&['Pual','Hufal'].includes(pattern))for(const p of raw.parts){
    if(p?.confident!==true||!['stem','component'].includes(p.kind)||typeof p.text!=='string')continue;
    const pointed=field('parts.text',()=>HebrewText.validate(p.text,{required:true})).normalize('NFD').replace(/[־-]/g,'');
    if(pattern==='Pual'&&/^[א-ת][\u0591-\u05bd\u05bf\u05c1\u05c2]*\u05bb/u.test(pointed))stem=letters(pointed);
    if(pattern==='Hufal'&&/^[האיתן](?:[\u0591-\u05bd\u05bf\u05c1\u05c2]*\u05bb|ו\u05bc)/u.test(pointed))stem=letters(pointed).replace(/^[האיתן]ו?/u,'');
   }
   const weakYod=pattern==='Hifil'&&r.startsWith('י')&&stem==='ו'+r.slice(1),assimilatedNun=pattern==='Paal'&&r.startsWith('נ')&&/^ל\u05b4[א-ת][\u0591-\u05c7]*\u05bc/u.test(lemma.normalize('NFD'))&&stem===r[1]+'ו'+r[2];if(stem!==r&&!weakYod&&!assimilatedNun){root='';rootWithheld=true;}
  }
  let parts=[];for(const part of raw.parts){if(!part||typeof part.confident!=='boolean'){const e=Error('Invalid component type.');e.field='parts.text';throw e;}if(part.confident!==true){parts=[];break;}if(!['prefix','stem','suffix','component'].includes(part.kind))field('parts.text',()=>{throw Error('Invalid word component.');});parts.push({text:field('parts.text',()=>HebrewText.validate(part.text,{source:selected,mixed:true,required:true})),meaning:field('parts.meaning',()=>gloss(part.meaning)),kind:part.kind,confident:true});}
  // Full spelling and pointed spelling are not identical (e.g. a mater yod
  // represented by hiriq). Align the validated components with immutable source
  // text using the same bounded spelling rules as inline nikud. Do not strip
  // arbitrary letters, rewrite source text, or allow components across words.
  if(parts.length)field('parts.text',()=>{
   const text=s=>s.replace(/[^\p{L}\p{N}\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]/gu,'');
   const sourceWords=selected.split(/\s+/).map(text),segments=parts.flatMap(p=>p.text.split(/\s+/).map(text)).filter(Boolean);
   const memo=new Map();function align(i,j){const key=i+':'+j;if(memo.has(key))return memo.get(key);if(i===sourceWords.length)return j===segments.length;let candidate='',ok=false;for(let k=j;k<segments.length;k++){candidate+=segments[k];if((letters(candidate)===letters(sourceWords[i])||HebrewText.validNikud(sourceWords[i],candidate))&&align(i+1,k+1)){ok=true;break;}}memo.set(key,ok);return ok;}
   if(!align(0,0))throw Error('The component words do not reconstruct the exact selection.');
  });
  if(!lemma&&!root&&!features.length&&!parts.length&&category==='other')return uncertain;
  return {selected,confident:true,category,lemma,lemmaMeaning,...(lemmaWithheld?{lemmaWithheld:true}:{}),lemmaConfident:!!lemma,root,rootConfident:!!root,rootWithheld:rootWithheld||raw.rootWithheld===true,...(raw.retryCount===1?{retryCount:1}:{}),features,parts};
 }
 // Keep the identity check strict. Only discard a rejected optional field group.
 function checkedPartial(raw,input){
  if(!raw||raw.selected!==input.tokens.join(' ')||raw.confident!==true)return checked(raw,input);
  const candidate={...raw,features:[],parts:[]};
  const withheld=new Set();
  for(const field of ['features','parts']){
   const value=raw[field];
   if(value===undefined)continue;
   if(Array.isArray(value)&&value.length<=(field==='features'?7:12))candidate[field]=value;
   else withheld.add(field);
  }
  for(;;){
   try{return {...checked(candidate,input),...(withheld.size?{withheld:[...withheld]}:{})};}
   catch(error){
    const field=error.field?.split('.')[0];
    const group=field==='lemmaMeaning'?'lemma':field;
    if(!['root','lemma','parts','features'].includes(group)||withheld.has(group))throw error;
    withheld.add(group);
    if(group==='root')Object.assign(candidate,{root:'',rootConfident:false,rootWithheld:true});
    if(group==='lemma')Object.assign(candidate,{lemma:'',lemmaMeaning:'',lemmaConfident:false,lemmaWithheld:true});
    if(group==='features'||group==='parts')candidate[group]=[];
   }
  }
 }
 return {checked,checkedPartial,values};
})();
