(()=>{
 const token=location.hash.slice(1),button=document.getElementById('join'),message=document.getElementById('message');
 if(location.hash)history.replaceState(null,'',location.pathname);
 if(!/^[0-9a-f]{64}$/.test(token)){message.textContent='Open your invitation link to continue.';return;}
 button.disabled=false;
 button.onclick=async()=>{
  button.disabled=true;
  try{
   const r=await fetch('/beta/redeem',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token})});
   if(!r.ok)throw Error((await r.json()).error);
   location.replace('/');
  }catch(error){message.textContent=error.message;button.disabled=false;}
 };
})();
