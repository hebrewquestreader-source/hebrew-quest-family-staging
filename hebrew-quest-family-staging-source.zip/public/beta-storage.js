(()=>{
 const prefix='hq:beta:'+HQ_ACCOUNT.id+':',nativeFetch=globalThis.fetch.bind(globalThis),storage=globalThis.localStorage;
 globalThis.ReaderStorage={
  getItem:key=>storage.getItem(prefix+key),
  setItem:(key,value)=>storage.setItem(prefix+key,value),
  removeItem:key=>storage.removeItem(prefix+key)
 };
 const read=(key,fallback)=>JSON.parse(ReaderStorage.getItem(key)??JSON.stringify(fallback));
 const write=(key,value)=>ReaderStorage.setItem(key,JSON.stringify(value));
 const reply=(data,status=200)=>Response.json(data,{status});
 const wordKey=value=>value.normalize('NFD').replace(/[\u0591-\u05c7]/g,'').trim();
 function vocabulary(method,value){
  const entries=read('vocabulary',[]);
  if(method==='GET')return reply({entries,storage:'device'});
  if(method==='DELETE'||method==='PATCH'){
   const index=entries.findIndex(entry=>entry.id===value.id);
   if(index<0)return reply({error:'Word not found.'},404);
   if(method==='DELETE')entries.splice(index,1);else{
    if(!['needs_review','recognised'].includes(value.status))return reply({error:'Invalid review status.'},400);
    entries[index].status=value.status;
   }
  }else if(method==='POST'){
   const entry=value.enrichOnly?value.entry:value;
   if(typeof entry?.expression!=='string'||!Array.isArray(entry.examples)||!entry.examples.length)return reply({error:'Invalid vocabulary entry.'},400);
   const existing=entries.find(item=>wordKey(item.expression)===wordKey(entry.expression));
   if(!existing){
    if(value.enrichOnly)return reply({error:'Save the word first.'},404);
    entries.push({...entry,id:crypto.randomUUID()});
   }else{
    const key=e=>JSON.stringify([e.expression,e.url,e.title,e.sentence,e.sourceType]);
    const examples=new Map(existing.examples.map(e=>[key(e),e]));
    for(const example of entry.examples){
     const sameSavedWord=['vocabulary','review'].includes(example.sourceType)&&wordKey(example.sentence||'')===wordKey(existing.expression);
     if(!sameSavedWord)examples.set(key(example),{...examples.get(key(example)),...example});
    }
    for(const field of ['nikud','translation','lemma','lemmaTranslation'])if(entry[field])existing[field]=entry[field];
    existing.examples=[...examples.values()];
    existing.updatedAt=entry.updatedAt;
    existing.incomplete=!(existing.nikud&&existing.translation);
   }
  }else return reply({error:'Unsupported method.'},405);
  write('vocabulary',entries);return reply({ok:true});
 }
 function articles(method,url,value){
  const entries=read('articles',[]);
  if(method==='GET'){
   const id=url.searchParams.get('id');
   return id?reply({article:entries.find(item=>item.id===id)||null}):reply({articles:entries.map(({paragraphs,...item})=>item)});
  }
  if(method!=='POST')return reply({error:'Unsupported method.'},405);
  const index=entries.findIndex(item=>item.url===value.url&&item.title===value.title&&JSON.stringify(item.paragraphs)===JSON.stringify(value.paragraphs));
  const id=index<0?crypto.randomUUID():entries[index].id;
  if(index>=0)entries.splice(index,1);
  entries.unshift({...value,id});write('articles',entries.slice(0,10));return reply({id});
 }
 globalThis.fetch=async(input,options)=>{
  const url=new URL(typeof input==='string'?input:input.url||input.href,location.origin);
  if(url.origin!==location.origin)return nativeFetch(input,options);
  const method=options?.method||'GET';
  try{
   if(url.pathname==='/api/vocabulary')return vocabulary(method,JSON.parse(options?.body||'null'));
   if(url.pathname==='/api/articles')return articles(method,url,JSON.parse(options?.body||'null'));
   if(url.pathname==='/api/challenges'&&method==='GET')return reply({articles:[],recent:[],runs:[],articlesRead:0,vocabularySaved:read('vocabulary',[]).length});
  }catch{return reply({error:'Browser storage is unavailable.'},503);}
  const result=await nativeFetch(input,options);
  if(result.status===401&&url.pathname.startsWith('/api/'))location.replace('/');
  return result;
 };
})();
