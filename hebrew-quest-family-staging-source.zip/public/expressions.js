// Dictionary highlights are synchronous; contextual AI suggestions progressively enhance them.
const knownExpressions=ExpressionText.dictionary;
function knownExpressionResult(tokens,context=''){return ExpressionText.known(tokens,context);}
function findKnownExpression(id){return typeof ExpressionUI==='undefined'?null:ExpressionUI.find(id);}
const ExpressionUI=(()=>{
 const storageKey='hebrew-quest-expressions-v1',single=document.getElementById('expressionSingleWord'),cache=new Map();let currentRows=null,signature='',ranges=[],automatic=null,revision=0,lastRevision=-1,lastRows=null,lastEnabled=null;
 try{for(const [key,value]of JSON.parse(readerStorage.getItem(storageKey)||'[]').slice(-8))cache.set(key,value);}catch{}
 const keyFor=s=>{let hash=2166136261;for(let i=0;i<s.length;i++)hash=Math.imul(hash^s.charCodeAt(i),16777619);return String(hash>>>0);};
 function store(){try{readerStorage.setItem(storageKey,JSON.stringify([...cache]));}catch{}}
 function candidates(){return ranges.flatMap((list,row)=>list.map(r=>({...r,row})));}
 function ensure(){if(!importedMode){currentRows=null;ranges=[];return;}if(currentRows===rows)return;currentRows=rows;revision++;signature=JSON.stringify(rows.map(row=>row.map(w=>w[0])));ranges=rows.map(row=>ExpressionText.detect(row.map(w=>w[0])));const saved=cache.get(keyFor(signature));if(saved?.signature===signature)for(const c of (Array.isArray(saved.candidates)?saved.candidates:[]).slice(0,1000)){const row=rows[c.row];if(!row)continue;const checked=ExpressionText.checked(row.map(w=>w[0]),c,row.map(w=>w[0]).join(' '));if(checked)ranges[c.row]=ExpressionText.nonoverlap([...ranges[c.row],{...checked,source:'ai'}]);}}
 function persist(){cache.set(keyFor(signature),{signature,candidates:candidates().filter(c=>c.source==='ai')});while(cache.size>8)cache.delete(cache.keys().next().value);store();}
 function paint(ids){ensure();const full=lastRows!==rows||lastEnabled!==settings.highlightExpressions||lastRevision!==revision||!ids;const pairs=full?wordNodes:[...ids].map(id=>[id,wordNodes.get(id)]).filter(([,node])=>node);lastRows=rows;lastEnabled=settings.highlightExpressions;lastRevision=revision;for(const [id,node]of pairs){const match=find(id);node.classList.toggle('usefulExpression',!!match);if(match)node.setAttribute('aria-label',getData(id)[0]+', useful expression: '+match.text);}}
 function find(id){if(!importedMode||settings.highlightExpressions===false||!/^\d+-\d+$/.test(id))return null;ensure();const [i,j]=id.split('-').map(Number);const r=ranges[i]?.find(r=>r.start<=j&&r.end>=j);return r?{...r,start:`${i}-${r.start}`,end:`${i}-${r.end}`}:null;}
 function enhance(job,result){if(!importedMode||job.generation!==preparationGeneration||job.helpScope||!Array.isArray(result.expressions))return;ensure();let changed=false;for(const c of result.expressions.slice(0,6)){const checked=ExpressionText.checked(job.tokens,c,job.context);if(!checked)continue;const a=job.ids[checked.start]?.split('-').map(Number),b=job.ids[checked.end]?.split('-').map(Number);if(!a||!b||a[0]!==b[0]||b[1]-a[1]!==checked.end-checked.start)continue;const row=rows[a[0]],mapped=ExpressionText.checked(row.map(w=>w[0]),{...checked,start:a[1],end:b[1]},job.context);if(!mapped)continue;ranges[a[0]]=ExpressionText.nonoverlap([...ranges[a[0]],{...mapped,source:'ai'}]);changed=true;}if(changed){revision++;persist();paint();}}
 function clearSelection(){automatic=null;single.hidden=true;}
 function selected(range,anchor){automatic={range,anchor};single.textContent='Look up “'+getData(anchor)[0]+'” only';single.hidden=false;}
 single.addEventListener('click',()=>{if(!automatic)return;const id=automatic.anchor;clearSelection();select(id,true);});
 return {paint,find,enhance,clearSelection,selected};
})();
