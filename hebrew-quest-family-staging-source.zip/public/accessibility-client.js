// Native dialogs restore focus in modern browsers. Preserve the opener, with a safe fallback
// for dynamically replaced challenge controls and browsers with incomplete restoration.
(()=>{
 const openers=new WeakMap(),fallback={vocabularyDialog:'myVocabulary',readingChallengeDialog:'startReadingChallenge',readingProgressDialog:'readingProgressButton',recentArticlesDialog:'recentArticlesButton',accountDialog:'accountButton',reportDialog:'reportResult'};
 document.addEventListener('beforetoggle',e=>{if(e.target.tagName==='DIALOG'&&e.newState==='open')openers.set(e.target,document.activeElement);},true);
 document.addEventListener('close',e=>{if(e.target.tagName!=='DIALOG')return;const original=openers.get(e.target),target=original!==document.body&&original?.isConnected&&original.getClientRects().length?original:document.getElementById(fallback[e.target.id]);if(target?.isConnected&&target.getClientRects().length)target.focus({preventScroll:true});openers.delete(e.target);},true);
})();
