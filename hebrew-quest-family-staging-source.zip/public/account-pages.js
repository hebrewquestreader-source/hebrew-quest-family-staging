// Presentation links only. Authentication, sign-out safeguards and encrypted keys are unchanged.
(()=>{
 document.getElementById('accountLanguageSettings').addEventListener('click',()=>{toggleSettings(true);document.getElementById('settingsAi').open=true;});
 document.getElementById('accountVocabularyData').addEventListener('click',async()=>{await AppPages.go('vocabulary');document.querySelector('.manageVocabulary').open=true;});
})();
