// Account-scoped queue. Already running provider calls finish; queued background
// work yields to explicit reader actions. Failed responses are never results.
globalThis.AIAvailability=(()=>{
 const key='hebrew-quest-ai-availability-v1',pending=new Map(),failures=new Map(),counts={},listeners=new Set(),queue=[];let hold=null,timer=null,running=0,background=0,lastInteractive=0;
 try{const saved=JSON.parse(readerStorage.getItem(key)||'null');if(saved&&['quota','local_quota'].includes(saved.code)&&(!saved.retryAt||Number.isFinite(saved.retryAt)&&saved.retryAt>Date.now()))hold=saved;}catch{}
 const notice=document.getElementById('aiUnavailableNotice'),retry=document.getElementById('retryNewHelp');
 function persist(){try{if(hold)readerStorage.setItem(key,JSON.stringify(hold));else readerStorage.removeItem(key);}catch{}}
 function emit(){for(const fn of listeners)fn(hold);}
 function expire(){if(hold?.retryAt&&Date.now()>=hold.retryAt){hold=null;persist();render();emit();return true;}return false;}
 function paused(){expire();return !!hold;}
 function quotaError(){return Object.assign(Error('New language help is temporarily unavailable. Previously saved help still works.'),{code:hold?.code||'local_quota',quota:hold?.quota,retryAt:hold?.retryAt,availabilityPaused:true});}
 function render(){if(notice){notice.hidden=!hold;const text=document.getElementById('aiUnavailableText');if(text)text.textContent='New AI help paused. Saved help and Save still work.';}if(retry){retry.disabled=!!hold?.retryAt;retry.hidden=!hold||!!hold.retryAt;}clearTimeout(timer);if(hold?.retryAt&&hold.retryAt>Date.now())timer=setTimeout(()=>expire(),Math.min(2147483647,hold.retryAt-Date.now()+30));}
 function observe(error){if(!['quota','local_quota'].includes(error?.code))return false;const next={code:error.code,...(Number.isFinite(error.retryAt)&&error.retryAt>Date.now()?{retryAt:error.retryAt}:{}),...(error.quota?{quota:error.quota}:{})};if(hold?.retryAt&&hold.retryAt>(next.retryAt||0))next.retryAt=hold.retryAt;hold=next;persist();render();emit();return true;}
 function retryNow(){if(paused()&&hold.retryAt)return false;hold=null;failures.clear();persist();render();emit();return true;}
 function cancelled(){return Object.assign(Error('Queued preparation no longer needed.'),{code:'preparation_cancelled'});}
 function pump(){
  for(let i=queue.length-1;i>=0;i--)if(queue[i].valid&&!queue[i].valid()){const [job]=queue.splice(i,1);pending.delete(job.key);job.reject(cancelled());}
  if(paused()){for(const job of queue.splice(0)){pending.delete(job.key);job.reject(quotaError());}return;}
  while(running<2){const interactive=queue.findIndex(j=>j.priority==='interactive'),index=interactive>=0?interactive:queue.findIndex(j=>j.priority==='background');if(index<0)return;const job=queue[index];
   if(job.priority==='background'&&(background||running||queue.some(j=>j.priority==='interactive')))return;
   queue.splice(index,1);running++;job.started=true;if(job.priority==='background')background++;counts[job.service]=(counts[job.service]||0)+1;
   Promise.resolve().then(()=>job.work(job.priority)).then(job.resolve,error=>{if(!observe(error)&&!['background_paused','preparation_cancelled'].includes(error?.code)){failures.set(job.key,{error,until:Date.now()+30000});while(failures.size>100)failures.delete(failures.keys().next().value);}job.reject(error);}).finally(()=>{running--;if(job.priority==='background')background--;pending.delete(job.key);pump();}).catch(()=>{});
  }
 }
 function run(service,input,work,{manual=false,priority='interactive',valid}={}){const k=JSON.stringify([service,input]);if(priority==='interactive')lastInteractive=Date.now();const existing=pending.get(k);if(existing){if(priority==='interactive'&&!existing.started)existing.priority='interactive';pump();return existing.promise;}if(manual){failures.delete(k);if(hold&&!hold.retryAt)retryNow();}if(paused())return Promise.reject(quotaError());const failed=failures.get(k);if(failed&&Date.now()<failed.until&&!manual)return Promise.reject(failed.error);
  const job={key:k,service,work,priority,valid,started:false};job.promise=new Promise((resolve,reject)=>{job.resolve=resolve;job.reject=reject;});pending.set(k,job);queue.push(job);pump();return job.promise;
 }
 function fromUsage(usage){if(!Array.isArray(usage))return;const exhausted=usage.find(x=>x.window==='day'&&x.used>=x.limit)||usage.find(x=>x.used>=x.limit);if(exhausted)observe({code:'local_quota',retryAt:exhausted.resetAt,quota:{source:'application',...exhausted}});else expire();}
 retry?.addEventListener('click',()=>{if(retryNow()&&active&&typeof requestAssistance==='function')requestAssistance(true);});render();
 return {run,observe,paused,promote:(service,input)=>{const job=pending.get(JSON.stringify([service,input]));if(job&&!job.started)job.priority='interactive';pump();},retry:retryNow,fromUsage,cancelQueued:()=>pump(),subscribe:fn=>{listeners.add(fn);return ()=>listeners.delete(fn);},interactiveIdle:()=>!running&&!queue.some(j=>j.priority==='interactive')&&Date.now()-lastInteractive>=1000,snapshot:()=>({hold:hold?{...hold}:null,requests:{...counts},pending:pending.size,running,background,queued:queue.map(j=>({service:j.service,priority:j.priority}))})};
})();
