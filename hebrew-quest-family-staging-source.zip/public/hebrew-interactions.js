// One shared registry and the reader's existing selection/gesture/popup pipeline.
globalThis.HebrewInteractions=(()=>{
 const blocks=new Map(),byElement=new WeakMap(),metadata=new WeakMap();let serial=1000000,lastPainted=new Set(),homeParent=side.parentNode,homeNext=side.nextSibling,anchor=null,lastHost=null,observer=null,scheduled=false;
 const skip='input,textarea,select,option,button,a,script,style,pre,code,[contenteditable]:not([contenteditable="false"]),[data-hq-no-interaction]';
 const semantics='p,h1,h2,h3,h4,li,blockquote,dd,dt,summary,label,.challengeQuestion,.challengeContext,.challengeFeedback,.vocabExpression,.vocabSentence,.vocabEnglish,.vocabMeta,.hint,.translation,.wordtitle,.form,.lemmaTranslation,.assistantStatus,bdi';
 function setContext(element,info){metadata.set(element,{...info});return element;}
 function originals(node){if(node.nodeType===3)return node.nodeValue||'';if(node.dataset?.hqWord){const [i,j]=node.dataset.id.split('-').map(Number);return blocks.get(i)?.rawRanges[j]?.raw||node.textContent;}return [...node.childNodes].map(originals).join('');}
 function relatedArticle(question,paragraphs){const needles=new Set((question.match(/[א-ת]{3,}/g)||[]));const scored=paragraphs.map((text,i)=>({text,i,score:(text.match(/[א-ת]{3,}/g)||[]).reduce((n,w)=>n+Number(needles.has(w)),0)})).sort((a,b)=>b.score-a.score||a.i-b.i);const chosen=[];let size=0;for(const x of scored){if(size+x.text.length>11000)continue;chosen.push(x.text);size+=x.text.length;if(chosen.length===2)break;}return chosen.join('\n');}
 function infoFor(element,raw){
  let base={sourceType:'instruction',articleTitle:typeof articleTitle!=='undefined'&&articleTitle?articleTitle:'Hebrew Quest instruction',url:'',relatedText:'',protected:false};
  for(let node=element;node;node=node.parentElement)if(metadata.has(node)){base={...base,...metadata.get(node)};break;}
  if(element.closest('#challengeContent')&&typeof challengeSession!=='undefined'&&challengeSession){const s=challengeSession,view=challengeView,group=view==='comprehension'?s.comp:s.vocab,item=group?.items?.[group.cursor],question=view==='comprehension'?item?.question:view==='vocabulary'?item?.expression:s.application?.expression||'';
   let sourceType=view==='comprehension'?'comprehension':view==='vocabulary'?'vocabulary':view==='application'?'application':view==='review'?'review':'instruction';
   if(item?.hint&&raw.trim()===item.hint.trim())sourceType='hint';else if(element.classList.contains('challengeFeedback'))sourceType='feedback';
   if(s.kind==='run_review'&&sourceType==='vocabulary')sourceType='review';base={...base,sourceType,articleTitle:s.title,url:s.url,relatedQuestion:question,relatedText:relatedArticle(question||raw,s.scope.paragraphs),protected:['comprehension','vocabulary','application'].includes(view),question:sourceType==='comprehension',exerciseTarget:['comprehension','vocabulary'].includes(view)?{id:s.id,activity:view,index:group.cursor}:null};
  }
  if(element.closest('.meaningHints'))base={...base,sourceType:'hint'};
  if(element.closest('.side')&&active){const ids=active==='selection'?selectionIds:[active];const origin=context(ids);if(origin)base={...origin,sourceType:element.closest('#hint,.meaningHints')?'hint':'instruction',relatedQuestion:origin.sentence};else base={...base,sourceType:element.closest('#hint,.meaningHints')?'hint':'instruction',relatedText:sentenceForSelection(ids),url:document.getElementById('sourceLink').hidden?'':document.getElementById('sourceLink').href};}
  return base;
 }
 function sentenceSlice(block,start,end){const a=block.ranges[start]?.start||0,b=block.ranges[end]?.end||block.plain.length;const segments=typeof Intl.Segmenter==='function'?[...new Intl.Segmenter('he',{granularity:'sentence'}).segment(block.plain)]:[{index:0,segment:block.plain}];return segments.filter(s=>s.index<b&&s.index+s.segment.length>a).map(s=>s.segment).join('').trim();}
 function context(ids){if(!ids?.length)return null;const [i,start]=ids[0].split('-').map(Number),block=blocks.get(i);if(!block)return null;const end=Number(ids.at(-1).split('-')[1]),sentence=sentenceSlice(block,start,end);const additions=[];if(block.info.relatedQuestion&&block.info.relatedQuestion!==sentence)additions.push('Related question: '+block.info.relatedQuestion);if(block.info.relatedText&&block.info.relatedText!==sentence)additions.push('Article/context text: '+block.info.relatedText);
  const extra=additions.join('\n\n');const combined=sentence+(extra?'\n\n'+extra.slice(0,Math.max(0,15998-sentence.length)):'');return {...block.info,sentence,context:combined,wholeQuestion:!!block.info.question&&start===0&&end===block.row.length-1,block};
 }
 function row(i){return blocks.get(i)?.row||null;}
 function nodes(){return [...blocks.values()].flatMap(b=>b.nodes).filter(n=>n.isConnected);}
 function paint(){const current=new Set([...revealed,...selectionIds,...(active?[active]:[])]);for(const id of new Set([...lastPainted,...current])){const [i,j]=id.split('-').map(Number),block=blocks.get(i),node=block?.nodesByIndex.get(j);if(node?.isConnected){paintWord(node,id,block.row[j],false);node.classList.add('hq-word');}}lastPainted=new Set([...current].filter(id=>blocks.has(Number(id.split('-')[0]))));observer?.takeRecords();position();}
 function mount(container,raw,info=infoFor(container,raw)){
  if(!/[א-ת]/.test(raw)||container.closest(skip))return null;
  // Validate source-script integrity before creating clickable generated Hebrew.
  try{HebrewText.validate(raw,{source:raw,mixed:true});}catch{container.textContent='Invalid Hebrew text withheld. Please retry or report the result.';return null;}
  const old=byElement.get(container);if(old&&old.raw===raw&&old.nodes.every(n=>n.isConnected&&container.contains(n)))return old;
  if(old){if(old.nodes.some(n=>n.dataset.id===active||selectionIds.includes(n.dataset.id)))closeAssistant();blocks.delete(old.index);}
  const index=serial++,ranges=[...raw.matchAll(/\S+/gu)].map(m=>({start:m.index,end:m.index+m[0].length,raw:m[0]})),plain=HebrewText.unpoint(raw),row=ranges.map(m=>{const original=HebrewText.unpoint(m.raw);return [original,HebrewText.validNikud(original,m.raw)?m.raw:original,'','',''];}),block={index,element:container,raw,plain:row.map(w=>w[0]).join(' '),row,rawRanges:ranges,ranges:[],nodes:[],nodesByIndex:new Map(),info:{...info}};
  let plainOffset=0;for(const w of row){block.ranges.push({start:plainOffset,end:plainOffset+w[0].length});plainOffset+=w[0].length+1;}
  container.replaceChildren();let cursor=0;for(let j=0;j<ranges.length;j++){const m=ranges[j];if(m.start>cursor)container.append(document.createTextNode(raw.slice(cursor,m.start)));if(/[א-ת]/.test(m.raw)){const node=document.createElement('span'),id=`${index}-${j}`;node.dataset.id=id;node.dataset.hqWord='true';node.tabIndex=0;node.setAttribute('role','button');node.lang='he';node.dir='rtl';node.className='word hq-word';node.textContent=m.raw;node.setAttribute('aria-label',row[j][0]);node.setAttribute('aria-pressed','false');bindReadingWord(node,id);block.nodes.push(node);block.nodesByIndex.set(j,node);container.append(node);}else container.append(document.createTextNode(m.raw));cursor=m.end;}if(cursor<raw.length)container.append(document.createTextNode(raw.slice(cursor)));
  container.dataset.hqBlock=String(index);container.classList.add('hq-text');blocks.set(index,block);byElement.set(container,block);
  if(info.knownExpression&&HebrewText.unpoint(info.knownExpression)===row.map(w=>w[0]).join(' ')&&info.knownNikud){const pointed=info.knownNikud.split(/\s+/);if(pointed.length===row.length)pointed.forEach((w,j)=>{if(HebrewText.validNikud(row[j][0],w))row[j][1]=w;});}
  queueMicrotask(()=>{if(typeof registerExternalPreparation==='function')registerExternalPreparation(block);});
  return block;
 }
 function scan(root=document.body){
  if(!root?.isConnected)return;const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);const targets=new Set();let text;while((text=walker.nextNode())){const parent=text.parentElement;if(!parent||!/[א-ת]/.test(text.nodeValue||'')||parent.closest(skip)||parent.closest('.word')||parent.closest('#article,#importTitle'))continue;let container=parent.closest(semantics)||parent;if(container.closest(skip))continue;
   if(container.querySelector('button,input,textarea,select,a,[contenteditable]')){const wrapper=document.createElement('span');text.replaceWith(wrapper);wrapper.append(document.createTextNode(text.nodeValue||''));container=wrapper;}
   targets.add(container);
  }
  for(const element of targets){if(!element.isConnected)continue;const existing=byElement.get(element);const raw=existing&&element.querySelector('[data-hq-word]')?originals(element):element.textContent;if(existing&&element.querySelector('[data-hq-word]')&&!hasNewText(element))continue;mount(element,raw);}
  for(const [id,block] of blocks)if(!block.element.isConnected){if(block.nodes.some(n=>n.dataset.id===active||selectionIds.includes(n.dataset.id))){closeAssistant();render();}blocks.delete(id);}
  observer?.takeRecords();
 }
 function hasNewText(element){const walker=document.createTreeWalker(element,NodeFilter.SHOW_TEXT);let node;while((node=walker.nextNode()))if(/[א-ת]/.test(node.nodeValue||'')&&!node.parentElement.closest('[data-hq-word]'))return true;return false;}
 function pin(id){const block=blocks.get(Number(id.split('-')[0]));if(block&&side.contains(block.element)&&!block.element.closest('#assistantSourceContext')){const quote=document.getElementById('assistantSourceContext'),old=block.element,copy=document.createElement('div');copy.className=old.className;copy.dir=old.dir||'auto';copy.lang=old.lang||'he';copy.dataset.hqBlock=String(block.index);copy.append(...old.childNodes);byElement.delete(old);byElement.set(copy,block);block.element=copy;quote.replaceChildren(copy);quote.hidden=false;}}
 function selectedNode(id=active){if(id==='selection')id=selectionIds[0];const [i,j]=String(id).split('-').map(Number);return blocks.get(i)?.nodesByIndex.get(j)||wordNodes.get(id);}
 // A non-modal panel leaves article scrolling and other Hebrew selections available.
 let historyToken=null,waitingBack=false,keyboardFocus=false,returnAnchor=null,priorRestoration=null,scrollIntent=null;
 const body=side.querySelector('.wordHelpBody');
 function pushHistory(){if(!window.history?.pushState||historyToken||waitingBack)return;const token='hq-word-'+Date.now()+'-'+Math.random();try{if(priorRestoration===null&&typeof window.history.scrollRestoration==='string'){priorRestoration=window.history.scrollRestoration;window.history.scrollRestoration='manual';}window.history.pushState({...window.history.state,hqWordHelp:token},'');historyToken=token;}catch{/* Embedded browsers can disallow history changes. */}}
 function restoreHistory(){if(priorRestoration!==null&&!historyToken&&!waitingBack){window.history.scrollRestoration=priorRestoration;priorRestoration=null;}}
 function removeHistory(){if(historyToken&&window.history?.state?.hqWordHelp===historyToken){historyToken=null;waitingBack=true;window.history.back();}else{historyToken=null;restoreHistory();}}
 function readingAnchor(){if(!window.scrollY)return null;const candidates=[...readingSurface.querySelectorAll('[data-reading-row]')],node=candidates.find(n=>{const r=n.getBoundingClientRect();return r.bottom>54;});return node?{node,top:node.getBoundingClientRect().top}:null;}
 function preserveAnchor(before){if(!before?.node.isConnected)return;queueMicrotask(()=>{scrollIntent=null;const delta=before.node.getBoundingClientRect().top-before.top;if(Math.abs(delta)>1)window.scrollTo?.(window.scrollX||0,(window.scrollY||0)+delta);});}
 function panelLayout(desktop){const main=document.querySelector('main');side.classList.toggle('desktop-panel',desktop);main?.classList.toggle('word-help-open',desktop);side.setAttribute('role',desktop?'complementary':'dialog');if(desktop)side.removeAttribute?.('aria-modal');else side.setAttribute('aria-modal','false');}
 function open(id){scrollIntent=null;if(typeof QuickReadingTools!=='undefined'&&QuickReadingTools.isOpen())QuickReadingTools.close(false);if(typeof WordBreakdownUI!=='undefined')WordBreakdownUI.reset();const wasOpen=side.classList.contains('hq-floating');anchor=selectedNode(id);if(anchor&&!side.contains(anchor))returnAnchor=anchor;const host=anchor?.closest('dialog[open],.appPage[data-page-active="true"]')||null;if(host&&!host.contains(side)){host.append(side);lastHost=host;}else if(!host&&homeParent&&side.parentNode!==homeParent){homeParent.insertBefore(side,homeNext?.isConnected?homeNext:null);lastHost=null;}
  if(body)body.scrollTop=0;
  side.classList.add('hq-floating');position();if(!wasOpen)pushHistory();observer?.takeRecords();
 }
 function focus(){if(!active)return;keyboardFocus=true;document.getElementById('closePanel').focus({preventScroll:true});}
 function position(){if(!anchor?.isConnected||!side.classList.contains('hq-floating'))return;
  const desktop=(window.visualViewport?.width||window.innerWidth)>=1024&&!lastHost;panelLayout(desktop);if(desktop){side.dataset.dock='side-panel';return;}const viewport=window.visualViewport,top=viewport?.offsetTop||0,left=viewport?.offsetLeft||0,vw=viewport?.width||window.innerWidth,vh=viewport?.height||window.innerHeight,rect=anchor.getBoundingClientRect(),narrow=vw<=760,gap=8,width=Math.min(narrow?vw-16:360,vw-20),height=Math.min(vh*(narrow?.48:.7),540);
  let x,y;if(narrow){x=left+(vw-width)/2;const above=rect.top-top-gap,below=top+vh-rect.bottom-gap;const dockBelow=below>=above;y=dockBelow?top+vh-height-gap:top+gap;side.dataset.dock=dockBelow?'bottom':'top';}else{x=Math.max(left+gap,Math.min(rect.right+12+width<left+vw?rect.right+12:rect.left-width-12,left+vw-width-gap));y=Math.max(top+gap,Math.min(rect.top,top+vh-height-gap));side.dataset.dock='beside';}
  side.style.setProperty('--hq-width',width+'px');side.style.setProperty('--hq-height',Math.max(100,height)+'px');side.style.setProperty('--hq-left',x+'px');side.style.setProperty('--hq-top',y+'px');
 }
 function close(){scrollIntent=null;panelLayout(false);const returnTo=anchor&&!side.contains(anchor)?anchor:returnAnchor,hadFocus=keyboardFocus||side.contains(document.activeElement);keyboardFocus=false;side.classList.remove('hq-floating');if(homeParent&&side.parentNode!==homeParent)homeParent.insertBefore(side,homeNext?.isConnected?homeNext:null);const quote=document.getElementById('assistantSourceContext');quote.replaceChildren();quote.hidden=true;anchor=null;lastHost=null;
  // Removing our entry makes Android/browser Back dismiss help before leaving reading.
  removeHistory();
  if(hadFocus&&returnTo?.isConnected&&!side.contains(returnTo))returnTo.focus({preventScroll:true});observer?.takeRecords();
 }
 window.addEventListener('popstate',()=>{if(waitingBack){waitingBack=false;if(active||typeof QuickReadingTools!=='undefined'&&QuickReadingTools.isOpen())pushHistory();else restoreHistory();return;}if(historyToken&&window.history?.state?.hqWordHelp!==historyToken){historyToken=null;if(typeof QuickReadingTools!=='undefined'&&QuickReadingTools.isOpen()){QuickReadingTools.close(false);if(active)pushHistory();}else if(typeof tapPhrase!=='undefined'&&tapPhrase){cancelTapPhrase();pushHistory();}else if(active){closeAssistant();render();}restoreHistory();}});
 // Only actual document scrolling preceded by a deliberate gesture dismisses help.
 // Popup/Settings scrolls and programmatic scroll/focus changes never arm dismissal.
 const excluded=node=>!!node?.closest?.('.side,#settingsPanel,#quickReadingPanel,.readingToolsDock');let touch=null;
 document.addEventListener('touchstart',e=>{if(excluded(e.target)||e.touches?.length!==1){touch=null;return;}const t=e.touches[0];touch={x:t.clientX,y:t.clientY,scroll:window.scrollY||0};},{passive:true});
 document.addEventListener('touchmove',e=>{if(!active||!touch||excluded(e.target)||e.touches?.length!==1||typeof gesture!=='undefined'&&gesture?.armed)return;const t=e.touches[0];if(Math.abs(t.clientY-touch.y)>=24&&Math.abs(t.clientY-touch.y)>Math.abs(t.clientX-touch.x))scrollIntent={from:touch.scroll,until:Date.now()+1200};},{passive:true});
 document.addEventListener('touchcancel',()=>{touch=null;scrollIntent=null;},{passive:true});
 document.addEventListener('wheel',e=>{if(active&&!excluded(e.target)&&Math.abs(e.deltaY)>=1)scrollIntent={from:scrollIntent&&Date.now()<=scrollIntent.until?scrollIntent.from:window.scrollY||0,until:Date.now()+1000};},{passive:true});
 document.addEventListener('keydown',e=>{if(active&&!excluded(e.target)&&!e.target?.closest?.('input,textarea,select,button,[contenteditable]')&&['PageDown','PageUp','ArrowDown','ArrowUp','Home','End',' '].includes(e.key))scrollIntent={from:window.scrollY||0,until:Date.now()+1000};});
 document.addEventListener('scroll',e=>{if(!active||!scrollIntent||excluded(e.target)||e.target?.tagName==='TEXTAREA')return;const root=e.target===document||e.target===document.body||e.target===document.documentElement||e.target===window;if(!root)return;if(Date.now()>scrollIntent.until){scrollIntent=null;return;}if(Math.abs((window.scrollY||0)-scrollIntent.from)>=16){scrollIntent=null;closeAssistant();render();}},true);

 window.visualViewport?.addEventListener('resize',position);window.visualViewport?.addEventListener('scroll',position);
 if(typeof ResizeObserver!=='undefined')new ResizeObserver(position).observe(side);
 function refreshPreparation(){if(typeof registerExternalPreparation!=='function')return;for(const b of blocks.values())if(b.element.isConnected&&b.nodes.some(n=>n.getClientRects().length))registerExternalPreparation(b);}
 const pendingRoots=new Set();function schedule(root){pendingRoots.add(root);if(scheduled)return;scheduled=true;queueMicrotask(()=>{scheduled=false;const roots=[...pendingRoots];pendingRoots.clear();for(const root of roots)scan(root);});}
 if(typeof MutationObserver!=='undefined'){observer=new MutationObserver(records=>{for(const r of records){const target=r.target.nodeType===3?r.target.parentElement:r.target;if(!target||target.closest?.('.word,#article,#importTitle')||target.closest?.(skip))continue;const added=[...r.addedNodes||[]].filter(n=>n.nodeType===1);if(added.length)for(const n of added)schedule(n);else schedule(target);if(r.type==='attributes')queueMicrotask(refreshPreparation);}});observer.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['hidden','open']});}
 document.addEventListener('scroll',()=>{position();refreshPreparation();},true);document.addEventListener('close',e=>{if(e.target.contains?.(side)&&active){closeAssistant();render();}},true);window.addEventListener('resize',position);scan();
 return {setContext,scan,mount,row,context,nodes,paint,pin,open,close,focus,refreshPreparation,originals,openToolsHistory:pushHistory,closeToolsHistory:()=>{if(!active)removeHistory();}};
})();
