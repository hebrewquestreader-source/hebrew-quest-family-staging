import handler from 'vinext/server/fetch-handler';
import {betaJson,betaSession,joinPage,redeem,signOut} from '../lib/beta-session';

const routes=new Set(['/','/api/assist','/api/breakdown','/api/hints','/api/discover','/api/import','/api/language/setup']);
export default {
 async fetch(request:Request,env:Cloudflare.Env,ctx:ExecutionContext){
  const url=new URL(request.url);
  if(url.hostname!=='127.0.0.1'&&url.origin!==env.BETA_STAGING_ORIGIN)return betaJson({error:'Unknown beta host.'},403);
  if(!env.DB)return betaJson({error:'Beta storage unavailable.'},503);
  if(url.pathname==='/beta/redeem')return redeem(env.DB,request);
  if(url.pathname==='/beta/sign-out')return signOut(env.DB,request);
  if(url.pathname==='/beta/join'&&request.method==='GET')return joinPage();
  if(!routes.has(url.pathname))return betaJson({error:'Route unavailable in the beta.'},404);
  if(url.pathname==='/api/language/setup'&&request.method!=='GET')return betaJson({error:'Language settings are managed by the operator.'},405);
  if(url.pathname==='/'&&!await betaSession(env.DB,request))return joinPage();
  return handler.fetch(request,env,ctx);
 }
};
