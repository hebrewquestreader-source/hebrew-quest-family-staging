CREATE TABLE `vocabulary_entries` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`expression` text NOT NULL,
	`nikud` text NOT NULL,
	`translation` text NOT NULL,
	`lemma` text NOT NULL,
	`lemma_translation` text NOT NULL,
	`status` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `vocabulary_examples` (
	`id` text PRIMARY KEY NOT NULL,
	`entry_id` text NOT NULL,
	`owner` text NOT NULL,
	`expression` text NOT NULL,
	`nikud` text NOT NULL,
	`translation` text NOT NULL,
	`sentence` text NOT NULL,
	`title` text NOT NULL,
	`url` text NOT NULL,
	`saved_at` text NOT NULL
);
