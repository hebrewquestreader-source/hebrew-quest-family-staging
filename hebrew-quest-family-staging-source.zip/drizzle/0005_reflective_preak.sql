CREATE TABLE `imported_articles` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`title` text NOT NULL,
	`url` text NOT NULL,
	`article_json` text NOT NULL,
	`imported_at` text NOT NULL,
	`last_opened_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `reader_accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`data_owner` text NOT NULL,
	`legacy_owner` integer DEFAULT 0 NOT NULL,
	`preferences_json` text DEFAULT '{}' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `reader_accounts_data_owner_unique` ON `reader_accounts` (`data_owner`);--> statement-breakpoint
CREATE TABLE `vocabulary_reviews` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`entry_id` text NOT NULL,
	`status` text NOT NULL,
	`reviewed_at` text NOT NULL
);

--> statement-breakpoint
-- Preserve the entire pre-account database before any new application request can run.
CREATE TABLE IF NOT EXISTS `hq_backup_0005_vocabulary_entries` AS SELECT * FROM `vocabulary_entries`;
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `hq_backup_0005_vocabulary_examples` AS SELECT * FROM `vocabulary_examples`;
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `hq_backup_0005_reading_sessions` AS SELECT * FROM `reading_sessions`;
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `hq_backup_0005_reading_completions` AS SELECT * FROM `reading_completions`;
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `hq_backup_0005_language_reports` AS SELECT * FROM `language_reports`;
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `hq_backup_0005_language_settings` AS SELECT * FROM `language_settings`;
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `hq_backup_0005_language_limits` AS SELECT * FROM `language_limits`;
