CREATE TABLE `reading_completions` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`article_key` text NOT NULL,
	`title` text NOT NULL,
	`url` text NOT NULL,
	`completed_at` text NOT NULL,
	`difficulty` text NOT NULL,
	`coverage` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `reading_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`article_key` text NOT NULL,
	`title` text NOT NULL,
	`url` text NOT NULL,
	`article_json` text NOT NULL,
	`state_json` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`busy_until` integer DEFAULT 0 NOT NULL,
	`updated_at` text NOT NULL
);
