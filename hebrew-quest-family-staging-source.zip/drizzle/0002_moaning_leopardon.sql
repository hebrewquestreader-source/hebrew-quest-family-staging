CREATE TABLE `language_reports` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`selected` text NOT NULL,
	`sentence` text NOT NULL,
	`title` text NOT NULL,
	`url` text NOT NULL,
	`kind` text NOT NULL,
	`note` text NOT NULL,
	`result_json` text NOT NULL,
	`saved_at` text NOT NULL
);
--> statement-breakpoint
ALTER TABLE `vocabulary_entries` ADD `incomplete` integer DEFAULT 0 NOT NULL;