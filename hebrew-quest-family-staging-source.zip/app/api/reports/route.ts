import {env} from 'cloudflare:workers';
import {requireAccount} from '../../../lib/language-store';
import {boundedJson,privateHeaders} from '../../../lib/language-http';
import {AssistanceError} from '../../../lib/language';
export async function POST(request:Request){try{
 const account=await requireAccount(request);const v=await boundedJson(request,100000);if(!['nikud','translation','lemma'].includes(v.kind)||typeof v.selected!=='string'||v.selected.length>600||typeof v.sentence!=='string'||v.sentence.length>16000||typeof v.note!=='string'||v.note.length>1000||typeof v.title!=='string'||v.title.length>300||typeof v.url!=='string'||v.url.length>2048)throw new AssistanceError('invalid_report','The report is incomplete or too large.');
 const owner=account.dataOwner;await env.DB!.prepare('INSERT INTO language_reports (id,owner,selected,sentence,title,url,kind,note,result_json,saved_at) VALUES (?,?,?,?,?,?,?,?,?,?)').bind(crypto.randomUUID(),owner,v.selected,v.sentence,v.title,v.url,v.kind,v.note,JSON.stringify(v.result||null),new Date().toISOString()).run();
 return Response.json({ok:true},{headers:privateHeaders});
}catch(error){return Response.json({error:error instanceof AssistanceError?error.message:'Report could not be saved.'},{status:error instanceof AssistanceError?error.status:503,headers:privateHeaders});}}
