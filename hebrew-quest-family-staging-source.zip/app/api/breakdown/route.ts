import {generateBreakdown} from '../../../lib/breakdown';
import {validateSelection,AssistanceError} from '../../../lib/language';
import {requireAccount,getLanguageKey,meteredFetch} from '../../../lib/language-store';
import {boundedJson,languageFailure,privateHeaders} from '../../../lib/language-http';

export async function POST(request:Request){
 const requestId=crypto.randomUUID(),start=Date.now();
 const trace=(phase:string,details:Record<string,unknown>={})=>console.info(JSON.stringify({event:'word_breakdown_runtime',requestId,phase,totalMs:Date.now()-start,...details}));
 try{
  const account=await requireAccount(request),input=validateSelection(await boundedJson(request,100000)),key=await getLanguageKey(account);
  if(!key)throw new AssistanceError('setup_required','Connect your free Gemini key in Settings to request optional Word Breakdown.',503);
  trace('prepared');
  const result=await generateBreakdown(input,key,meteredFetch(account,'breakdown'),trace);
  trace('complete',{confident:result.confident,withheld:result.withheld||[]});
  return Response.json(result,{headers:{...privateHeaders,'X-HQ-Request-ID':requestId}});
 }catch(error){
  trace('failed',error instanceof AssistanceError?{code:error.code,diagnostic:error.diagnostic}:{code:'unavailable'});
  const response=languageFailure(error);
  response.headers.set('X-HQ-Request-ID',requestId);
  return response;
 }
}
