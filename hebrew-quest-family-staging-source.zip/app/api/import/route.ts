import {requireAccount} from '../../../lib/language-store';
import { importArticle } from '../../../lib/importer';
const requests=new Map<string,{start:number,count:number}>();
export async function GET(request:Request) {
  const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
  let account;try{account=await requireAccount(request,false);}catch(error){return Response.json({error:error instanceof Error?error.message:'Sign in first.'},{status:401,headers});}
  const now=Date.now(),key=account.id||request.headers.get('cf-connecting-ip')||'reader';
  for(const [ip,entry] of requests)if(now-entry.start>60000)requests.delete(ip);
  const entry=requests.get(key)||{start:now,count:0};entry.count++;requests.set(key,entry);
  if(entry.count>12)return Response.json({error:'Please wait a minute before importing again.'},{status:429,headers});
  try {
    const value=new URL(request.url).searchParams.get('url')||'';
    if(value.length>2048)throw new Error('Article URL is too long.');
    return Response.json(await importArticle(value),{headers});
  }catch(error){return Response.json({error:error instanceof Error?error.message:'Import failed.'},{status:422,headers});}
}
