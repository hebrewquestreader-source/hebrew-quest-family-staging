import {env} from 'cloudflare:workers';
import {requireAccount} from '../../../lib/language-store';
import {boundedJson,privateHeaders} from '../../../lib/language-http';
import {AssistanceError} from '../../../lib/language';
import {VocabularyError,validateVocabulary,saveVocabulary,enrichVocabulary,listVocabulary,changeVocabulary} from '../../../lib/vocabulary';
function failure(error:unknown){const known=error instanceof AssistanceError;return Response.json({error:known?error.message:error instanceof VocabularyError?error.message:'Vocabulary could not be saved. Please try again.'},{status:known?error.status:error instanceof VocabularyError?422:503,headers:privateHeaders});}
async function account(request:Request,mutation=true){return (await requireAccount(request,mutation)).dataOwner;}
export async function GET(request:Request){try{const owner=await account(request,false);return Response.json({entries:await listVocabulary(env.DB!,owner),storage:'account'},{headers:privateHeaders});}catch(e){return failure(e);}}
export async function POST(request:Request){try{const owner=await account(request),value=await boundedJson(request,2_000_000);const entry=validateVocabulary(value.enrichOnly?value.entry:value);return Response.json(await (value.enrichOnly?enrichVocabulary(env.DB!,owner,entry):saveVocabulary(env.DB!,owner,entry)),{headers:privateHeaders});}catch(e){return failure(e);}}
export async function PATCH(request:Request){try{const owner=await account(request);const v=await boundedJson(request);if(!['needs_review','recognised'].includes(v.status))throw new VocabularyError('Choose a review status.');await changeVocabulary(env.DB!,owner,v.id,v.status,v.review===true);return Response.json({ok:true},{headers:privateHeaders});}catch(e){return failure(e);}}
export async function DELETE(request:Request){try{const owner=await account(request);const v=await boundedJson(request);await changeVocabulary(env.DB!,owner,v.id);return Response.json({ok:true},{headers:privateHeaders});}catch(e){return failure(e);}}
