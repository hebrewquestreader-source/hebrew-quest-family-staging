import { generateAssistance,AssistanceError,LANGUAGE_MODEL,normalizeApiKey } from '../../../../lib/language';
import { requireAccount,isConfigured,saveLanguageKey,removeLanguageKey,meteredFetch,quotaUsage,preparationPolicy } from '../../../../lib/language-store';
import { boundedJson,languageFailure,privateHeaders } from '../../../../lib/language-http';
export async function GET(request:Request){
  try{const account=await requireAccount(request,false);return Response.json({configured:await isConfigured(account),model:LANGUAGE_MODEL,usage:await quotaUsage(account),preparationPolicy:preparationPolicy(account)},{headers:privateHeaders});}catch(error){return languageFailure(error);}
}
export async function POST(request:Request){
  try{
    const account=await requireAccount(request);const data=await boundedJson(request,2000);
    if(data.freeTierConfirmed!==true||data.dataUseConsent!==true)throw new AssistanceError('confirmation_required','Confirm that billing is disabled and that you agree to send selected text to Google.');
    const key=normalizeApiKey(data.apiKey);
    // Verify a real Hebrew result before marking the connection ready. Never echo or log the key.
    await generateAssistance({tokens:['שלום'],context:'הוא אמר שלום לשכנים.'},key,meteredFetch(account,'setup','setup'));
    await saveLanguageKey(account,key);
    return Response.json({configured:true,model:LANGUAGE_MODEL},{headers:privateHeaders});
  }catch(error){return languageFailure(error);}
}
export async function DELETE(request:Request){
  try{const account=await requireAccount(request);await removeLanguageKey(account);return Response.json({configured:false},{headers:privateHeaders});}catch(error){return languageFailure(error);}
}
