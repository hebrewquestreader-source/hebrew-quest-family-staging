import { validatePreparation,preparationContext,prepareNikud } from '../../../lib/preparation';
import { AssistanceError } from '../../../lib/language';
import { requireAccount,getLanguageKey,meteredFetch } from '../../../lib/language-store';
import { boundedJson,languageFailure,privateHeaders } from '../../../lib/language-http';
export async function POST(request:Request){
 try{const account=await requireAccount(request);const value=await boundedJson(request,100000);const tokens=validatePreparation(value);const context=preparationContext(value,tokens);const key=await getLanguageKey(account);if(!key)throw new AssistanceError('setup_required','Connect language assistance in Settings first.',503);return Response.json(await prepareNikud(tokens,key,meteredFetch(account,'prepare','assist',fetch,'background'),context),{headers:privateHeaders});}
 catch(error){return languageFailure(error);}
}
