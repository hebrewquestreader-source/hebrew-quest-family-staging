
import {requireAccount} from '../../../lib/language-store';
import {discoveryService,discoveryEdgeCache} from '../../../lib/discover';
import {discoverPreferences,validDiscoverPreference} from '../../../lib/discover-catalog';
import {privateHeaders} from '../../../lib/language-http';
export async function GET(request:Request){try{const account=await requireAccount(request,false),preferences=discoverPreferences(account.preferences),query=new URL(request.url).searchParams;for(const key of Object.keys(preferences) as (keyof typeof preferences)[]){if(query.has(key)){const value=query.get(key);if(!validDiscoverPreference(key,value))return Response.json({error:'Choose supported topics, publishers and a reading preference.'},{status:422,headers:privateHeaders});preferences[key]=value!;}}
 const {edge}=await discoveryEdgeCache();return Response.json(await discoveryService.list(preferences,[],fetch,Date.now(),edge,new URL(request.url).origin),{headers:privateHeaders});
 }catch(error){return Response.json({error:'Discover could not load. You can still paste a URL or article text in Reader.'},{status:typeof error==='object'&&error&&'status'in error?Number(error.status):503,headers:privateHeaders});}}
