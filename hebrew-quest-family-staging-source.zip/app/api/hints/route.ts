import {env} from 'cloudflare:workers';
import {requireAccount,getLanguageKey,meteredFetch} from '../../../lib/language-store';
import {boundedJson,languageFailure,privateHeaders} from '../../../lib/language-http';
import {AssistanceError} from '../../../lib/language';
import {hintInput,meaningHints,sessionHintInput} from '../../../lib/meaning-hints';
import {loadSession} from '../../../lib/challenges';
export async function POST(request:Request){try{const account=await requireAccount(request);const v=await boundedJson(request,100000);let input;if(v.sessionId){const row=await loadSession(env.DB!,account.dataOwner,v.sessionId);input=sessionHintInput(JSON.parse(row.state_json),v.activity,v.index);}else input=hintInput(v);const key=await getLanguageKey(account);if(!key)throw new AssistanceError('setup_required','Connect your free Gemini key in Settings to request optional meaning hints.',503);return Response.json(await meaningHints(input,key,meteredFetch(account,'hints')),{headers:privateHeaders});}catch(e){return languageFailure(e);}}
