import { generateAssistance,validateSelection,AssistanceError } from '../../../lib/language';
import { requireAccount,getLanguageKey,meteredFetch } from '../../../lib/language-store';
import { boundedJson,languageFailure,languageErrorBody,privateHeaders } from '../../../lib/language-http';
export async function POST(request:Request){
  const requestId=crypto.randomUUID(), start=Date.now();
  const trace=(phase:string,details:Record<string,unknown>={})=>console.info(JSON.stringify({event:"word_help_runtime",requestId,phase,totalMs:Date.now()-start,...details}));
  const runtime={trace};
  try{
    const account=await requireAccount(request);
    const priority=request.headers.get('x-hq-ai-priority')==='background'?'background':'interactive';
    const input=validateSelection(await boundedJson(request,100000));
    const key=await getLanguageKey(account);if(!key)throw new AssistanceError('setup_required','Connect your free Gemini key in Settings → Language assistance.',503);

    trace('prepared');
    if(request.headers.get('accept')?.includes('application/x-ndjson')){
      const encoder=new TextEncoder();let closed=false;
      const stream=new ReadableStream({
        async start(controller){
          const send=(event:unknown)=>{if(!closed)controller.enqueue(encoder.encode(JSON.stringify(event)+'\n'));};
          try{
            send({type:'status',requestId});
            const result=await generateAssistance(input,key,meteredFetch(account,'assist','assist',fetch,priority),tokens=>{trace('first_nikud');send({type:'nikud',tokens});},undefined,runtime);
            trace('complete');send({type:'result',result});
          }catch(error){const failure=languageErrorBody(error);trace('failed',{code:failure.code,diagnostic:'diagnostic' in failure?failure.diagnostic:undefined});send({type:'error',...failure,requestId});}
          finally{if(!closed){closed=true;controller.close();}}
        },cancel(){closed=true;},
      });
      return new Response(stream,{headers:{...privateHeaders,'Content-Type':'application/x-ndjson; charset=utf-8','Cache-Control':'no-store, no-transform','X-Accel-Buffering':'no'}});
    }
    return Response.json(await generateAssistance(input,key,meteredFetch(account,'assist','assist',fetch,priority),undefined,undefined,runtime),{headers:privateHeaders});
  }catch(error){return languageFailure(error);}
}
