import {env} from 'cloudflare:workers';
import {requireAccount,getLanguageKey,meteredFetch} from '../../../lib/language-store';
import {boundedJson,privateHeaders} from '../../../lib/language-http';
import {AssistanceError} from '../../../lib/language';
import {tutorRequest} from '../../../lib/challenge-tutor';
import {accountProgress,loadSession,openSession,openRunReview,mutateSession,publicState,validateArticle,mode} from '../../../lib/challenges';
function failure(error:unknown){return Response.json({error:error instanceof AssistanceError?error.message:'The reading session could not be saved. Please reopen it; existing work is retained.',code:error instanceof AssistanceError?error.code:'unavailable'},{status:error instanceof AssistanceError?error.status:503,headers:privateHeaders});}
export async function GET(request:Request){try{const account=await requireAccount(request,false),owner=account.dataOwner,id=new URL(request.url).searchParams.get('id');if(id){const row=await loadSession(env.DB!,owner,id);return Response.json({session:publicState(row),article:JSON.parse(row.article_json)},{headers:privateHeaders});}return Response.json(await accountProgress(env.DB!,owner),{headers:privateHeaders});}catch(e){return failure(e);}}
export async function POST(request:Request){try{
 const account=await requireAccount(request),owner=account.dataOwner,v=await boundedJson(request,400000);
 if(v.action==='open'){const row=await openSession(env.DB!,owner,validateArticle(v.article),mode(v.mode??'NORMAL'),v.short===true);return Response.json({session:publicState(row)},{headers:privateHeaders});}
 if(v.action==='run_review'){const row=await openRunReview(env.DB!,owner,v.run);return Response.json({session:publicState(row)},{headers:privateHeaders});}
 const result=await mutateSession(env.DB!,owner,v.id,v.action,v,async(task,payload)=>{const key=await getLanguageKey(account);if(!key)throw new AssistanceError('setup_required','Connect your free Gemini key in Settings to use the optional tutor. Progress and article completion do not need AI.',503);return tutorRequest(task,payload,key,meteredFetch(account,'tutor'));});return Response.json(result,{headers:privateHeaders});
}catch(e){return failure(e);}}
