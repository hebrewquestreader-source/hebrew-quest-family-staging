import html from '../lib/reader.html?raw';
import {requireAccount} from '../lib/language-store';
import {accountView} from '../lib/accounts';
const headers={'Content-Type':'text/html; charset=utf-8','Cache-Control':'private, no-store','Vary':'Cookie','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'};
export async function GET(request:Request){
 try{
  const account=await requireAccount(request,false);
  const state=JSON.stringify(accountView(account)).replace(/</g,'\\u003c');
  const bootstrap='<script>globalThis.HQ_BETA=true;globalThis.HQ_ACCOUNT='+state+';</script><script src="/beta-storage.js"></script><script src="/sync-client.js?v=beta"></script>';
  return new Response(html.replace('<script src="/hebrew-text-client.js',bootstrap+'\n<script src="/hebrew-text-client.js'),{headers});
 }catch{return new Response('Invitation session required.',{status:401,headers});}
}
