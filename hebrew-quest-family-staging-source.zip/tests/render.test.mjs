import {HebrewText} from '../lib/hebrew-text.js';
import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
test('a tap in a 5,000-word article updates selected nodes without rebuilding the article',()=>{
 const html=fs.readFileSync(new URL('../lib/reader.html',import.meta.url),'utf8');const source=html.slice(html.indexOf('let renderedRows='),html.indexOf('function select('));
 let created=0,cleared=0;const node=()=>({dataset:{},classList:{toggle(){}},children:[],textContent:'',setAttribute(){},addEventListener(){},append(child){this.children.push(child)},replaceChildren(){this.children=[]}});
 const article=node();Object.defineProperty(article,'innerHTML',{set(){cleared++;article.children=[]}});const count=node(),heading=node();
 const row=Array.from({length:5000},()=>['שלום','שָׁלוֹם','','','']);
 const c=vm.createContext({HebrewText,bindReadingWord(){},Set,Map,Date,rows:[[['כותרת','כּוֹתֶרֶת','','','']],row],article,settings:{nikud:true},importedMode:true,revealed:new Set(),selectionIds:[],active:null,punctuation:[''],groupAt(){return null},getData:id=>id.startsWith('0-')?['כותרת','כּוֹתֶרֶת']:row[Number(id.split('-')[1])],document:{createElement(){created++;return node()},createTextNode(text){return {textContent:text}},getElementById(id){return id==='importTitle'?heading:count}}});
 vm.runInContext(source,c);c.render();assert.equal(created,5004);assert.equal(cleared,1);
 const first=article.children[0].children[0].children[40],second=article.children[0].children[0].children[60];
 c.revealed.add('1-20');c.active='1-20';c.render();assert.equal(first.textContent,'שָׁלוֹם');
 c.revealed.clear();c.revealed.add('1-30');c.active='1-30';c.render();assert.equal(first.textContent,'שלום');assert.equal(second.textContent,'שָׁלוֹם');
 assert.equal(created,5004);assert.equal(cleared,1);assert.match(count.textContent,/^1 word/);
});
