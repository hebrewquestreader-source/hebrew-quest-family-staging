import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {WordBreakdown} from '../lib/word-breakdown.js';import {HebrewText} from '../lib/hebrew-text.js';
import {generateAssistance,validateAssistance} from '../lib/language.ts';import {generateBreakdown} from '../lib/breakdown.ts';
import {harness,settle} from './helpers/interactive-harness.mjs';
const cases=JSON.parse(fs.readFileSync(new URL('./fixtures/hebrew-linguistic-benchmark.json',import.meta.url),'utf8')).cases;
const envelope=v=>Response.json({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(v)}]}}]});
const grammar=r=>Object.fromEntries(r.features.map(f=>[f.name,f.value]));
const calm=async()=>{for(let i=0;i<6;i++)await settle();};
for(const c of cases)test(`human-authored benchmark ${c.id} ${c.expected.selected} in sentence context`,async()=>{
 let calls=0;const a=await generateAssistance(c.input,'synthetic',async(url,opts)=>{calls++;assert.deepEqual(JSON.parse(JSON.parse(opts.body).contents[0].parts[0].text),c.input);return envelope(c.provider.assist);});
 const b=await generateBreakdown(c.input,'synthetic',async()=>{calls++;return envelope(c.provider.breakdown);});
 assert.equal(calls,2);assert.equal(a.tokens.map(t=>t.original).join(' '),c.expected.selected);
 assert.equal(a.tokens.map(t=>t.nikud).join(' '),c.expected.nikud.normalize('NFC'));
 assert.equal(a.translation,c.expected.translation);assert.equal(a.lemma,c.expected.lemma.normalize('NFC'));
 assert.equal(b.selected,c.expected.selected);assert.equal(b.lemma,c.expected.lemma.normalize('NFC'));
 assert.equal(b.category,c.expected.category);assert.equal(b.root,c.expected.root);assert.deepEqual(grammar(b),c.expected.features);
 assert.deepEqual(WordBreakdown.checked(b,c.input),b);
});

test('finite headwords are never relabelled as infinitives, including cached model proposals',()=>{
 const c=cases[0],bad={...c.provider.breakdown,lemma:'הִזְכִּיר'};
 const result=WordBreakdown.checked(bad,c.input);
 assert.equal(result.lemma,'');assert.equal(result.lemmaWithheld,true);assert.equal(grammar(result).tense,'past');
 assert.equal(result.selected,'הזכירו');assert.equal(result.confident,true);
 assert.equal(WordBreakdown.checked(result,c.input).lemma,'');
 assert.equal(HebrewText.result({...c.provider.assist,lemmaKind:'infinitive',lemma:'הִזְכִּיר'},c.input).lemma,'');
});

test('optional malformed lemma and per-word analysis cannot erase trustworthy main nikud and meaning or cause a second call',async()=>{
 const c=cases[2],bad={...c.provider.assist,lemma:'אָהוּب',words:[{original:'האהובים',nikud:'האהוביم',translation:'beloved',lemma:'',confident:true}]};let count=0;
 const result=await generateAssistance(c.input,'synthetic',async()=>{count++;return envelope(bad);});
 assert.equal(count,1);assert.equal(result.tokens[0].nikud,c.expected.nikud.normalize('NFC'));assert.equal(result.translation,'beloved');
 assert.equal(result.lemma,'');assert.ok(result.withheldFields.includes('lemma'));assert.equal(result.words,undefined);
});

test('Nifal relationship rules handle future prefixes and full spelling without accepting unrelated lemmas or Arabic marks',()=>{
 for(const word of ['ייזכר','תיזכר','נזכר'])assert.equal(HebrewText.related(word,'לְהִזָּכֵר'),true,word);
 assert.equal(HebrewText.related('ייזכר','לְהִכָּתֵב'),false);
 assert.equal(HebrewText.validNikud('ייזכר','יִזָּכֵר'),true);
 // Both spellings can pass character/alignment checks; the benchmark must
 // distinguish the actual reading instead of treating validation as an oracle.
 assert.equal(HebrewText.validNikud('ייזכר','יִזְכֹּר'),true);
 assert.notEqual('יִזְכֹּר'.normalize('NFC'),cases[1].expected.nikud.normalize('NFC'));
 assert.throws(()=>HebrewText.validate('הָאֲהוּبִים'));
 assert.throws(()=>HebrewText.validate('הָאֲהוّבִים'));
});

test('present participles and infinitives cannot receive finite-person labels',()=>{
 for(const index of [13,15]){const c=cases[index],raw=structuredClone(c.provider.breakdown);raw.features.push({name:'person',value:'third',confident:true});const b=WordBreakdown.checked(raw,c.input);assert.equal(grammar(b).person,undefined);}
});

test('Word Help renders accurate infinitive labels and concise loanword analysis without revealing contextual English',async()=>{
 for(const index of [0,4]){const c=cases[index],h=harness({fetcher:async(url,opts,fallback)=>url==='/api/assist'?Response.json(c.provider.assist):url==='/api/breakdown'?Response.json(c.provider.breakdown):fallback(url,opts)});await calm();h.c.c=c;h.run('loadArticleText("בדיקה",[c.input.context],"");settings.wordBreakdown=true;applySettings()');
 const word=h.el('article').querySelectorAll('.word').find(w=>w.textContent===c.expected.selected);assert.ok(word);await word.click();await calm();await h.el('wordBreakdownButton').click();await calm();const text=h.el('wordBreakdownContent').textContent;
 assert.equal(h.el('contextTranslation').hidden,true);assert.equal(h.el('translation').hidden,true);
 if(index===0){assert.match(text,/infinitive/);assert.match(text,/לְהַזְכִּיר/u);assert.doesNotMatch(text,/הִזְכִּיר —.*infinitive/u);}else{assert.match(text,/Part of speech: noun/);assert.doesNotMatch(text,/\(stem\)|State: absolute|Binyan|Root:/);}
 assert.equal(h.c.vocabularySnapshot().expression,c.expected.selected);
 }
});

test('quota is not retried; intermittent provider errors remain bounded and unsuccessful analyses never become a result',async()=>{
 const c=cases[2];let calls=0;
 await assert.rejects(()=>generateAssistance(c.input,'synthetic',async()=>{calls++;return Response.json({error:{details:[]}},{status:429});}),e=>e.code==='quota');assert.equal(calls,1);
 calls=0;await assert.rejects(()=>generateBreakdown(c.input,'synthetic',async()=>{calls++;return new Response('temporary',{status:503});}),{code:'breakdown_unavailable'});assert.equal(calls,1);
 calls=0;await assert.rejects(()=>generateBreakdown(c.input,'synthetic',async()=>{calls++;return envelope({...c.provider.breakdown,selected:'מילה אחרת'});}),e=>e.diagnostic.field==='selected');assert.equal(calls,1);
});

test('cached finite verb lemmas are revalidated before rendering without discarding existing useful help',async()=>{
 const c=cases[0],key=JSON.stringify(c.input),storageMap=new Map([['hebrew-quest-word-breakdown-v4',JSON.stringify([[key,{...c.provider.breakdown,lemma:'הִזְכִּיר'}]])]]);let calls=0;
 const h=harness({storageMap,fetcher:async(url,opts,fallback)=>{if(url==='/api/breakdown'){calls++;throw Error('A cache hit should not call the provider');}return fallback(url,opts);}});await calm();const b=await h.c.WordBreakdownUI.get(c.input);assert.equal(calls,0);assert.equal(b.lemma,'');assert.equal(b.lemmaWithheld,true);assert.equal(grammar(b).tense,'past');
});

test('a validated early nikud result survives a later malformed response; error text stays concise and Save remains available',async()=>{
 const c=cases[2];const h=harness({fetcher:async(url,opts,fallback)=>url==='/api/assist'?new Response(JSON.stringify({type:'nikud',tokens:c.provider.assist.tokens})+'\n'+JSON.stringify({type:'error',code:'invalid_result',error:'technical value',retryCount:1,diagnostic:{code:'invalid_result',field:'tokens.nikud',reason:'alignment'}})+'\n',{headers:{'content-type':'application/x-ndjson'}}):fallback(url,opts)});await calm();h.c.c=c;h.run('loadArticleText("בדיקה",[c.input.context],"")');await h.el('article').querySelectorAll('.word').find(w=>w.textContent==='האהובים').click();await calm();
 assert.equal(h.el('selectedWord').textContent,c.expected.nikud.normalize('NFC'));
 assert.match(h.el('assistStatus').textContent,/Tap Retry language help/);assert.notEqual(h.el('saveVocabulary').disabled,true);assert.equal(h.c.vocabularySnapshot().expression,'האהובים');assert.equal(h.c.LanguageDiagnostics.snapshot().at(-1).field,'tokens.nikud');
});

test('diagnostic logs identify the failed field and attempts without raw content, selected text or credentials',async()=>{
 const {languageErrorBody}=await import('../lib/language-http.ts');const {AssistanceError}=await import('../lib/language.ts');
 const warnings=[],original=console.warn;console.warn=s=>warnings.push(s);
 try{const e=new AssistanceError('invalid_breakdown','provider body must not be logged');e.retryCount=1;e.diagnostic={code:'invalid_breakdown',field:'parts.text',reason:'alignment'};const body=languageErrorBody(e);assert.equal(body.error,"Couldn't analyse this word. Try again.");}finally{console.warn=original;}
 assert.equal(JSON.parse(warnings[0]).field,'parts.text');assert.equal(JSON.parse(warnings[0]).attempts,2);assert.doesNotMatch(warnings.join(''),/provider body|האהובים|api.key/i);
});
