import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../public/beta-storage.js',import.meta.url),'utf8');
function browser(id,storage=new Map()){
 const c=vm.createContext({HQ_ACCOUNT:{id},Response,URL,crypto,location:{origin:'https://beta.test'},localStorage:{getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},fetch:()=>{throw Error('Unexpected network write');}});
 vm.runInContext(source,c);return c;
}
const save=(c,value)=>c.fetch('/api/vocabulary',{method:'POST',body:JSON.stringify(value)});
const entries=async c=>(await (await c.fetch('/api/vocabulary')).json()).entries;
test('repeat save from vocabulary retains original context, status and valid enrichment without a self-example',async()=>{
 const storage=new Map(),c=browser('one',storage);
 const original={expression:'הודיעה',status:'recognised',examples:[{expression:'הודיעה',sentence:'העירייה הודיעה שהספרייה תיפתח ביום ראשון.',sourceType:'article'}]};
 assert.equal((await save(c,original)).status,200);
 assert.equal((await save(c,{...original,translation:'announced',lemma:'להודיע',examples:[{expression:'הודיעה',sentence:'הודיעה',sourceType:'vocabulary'}]})).status,200);
 const result=await entries(browser('one',storage));assert.equal(result.length,1);assert.equal(result[0].examples.length,1);assert.equal(result[0].examples[0].sentence,original.examples[0].sentence);assert.equal(result[0].status,'recognised');assert.equal(result[0].translation,'announced');assert.equal(result[0].lemma,'להודיע');
 assert.equal((await entries(browser('two',storage))).length,0);
});
test('distinct article context is retained and old examples are not silently deleted',async()=>{
 const c=browser('one');const old={expression:'הודיעה',sentence:'הודיעה',sourceType:'vocabulary'};
 await save(c,{expression:'הודיעה',examples:[old]});
 await save(c,{expression:'הודיעה',examples:[{expression:'הודיעה',sentence:'היא הודיעה אתמול.',sourceType:'article'}]});
 const result=await entries(c);assert.equal(result[0].examples.length,2);assert.equal(result[0].examples[0].sentence,'הודיעה');
});
