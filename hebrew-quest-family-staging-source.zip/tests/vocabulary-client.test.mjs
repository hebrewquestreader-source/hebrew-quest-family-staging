import {HebrewText} from '../lib/hebrew-text.js';
import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';import {DatabaseSync} from 'node:sqlite';
import {validateVocabulary,saveVocabulary,enrichVocabulary,listVocabulary,changeVocabulary} from '../lib/vocabulary.ts';
class Element {
 constructor(tag='div'){this.tag=tag;this.children=[];this.handlers={};this.hidden=false;this.value='';this.style={};this.attributes={};this._text='';}
 set textContent(v){this._text=String(v);this.children=[];} get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}
 append(...nodes){this.children.push(...nodes);} replaceChildren(...nodes){this._text='';this.children=[...nodes];}
 addEventListener(name,fn){this.handlers[name]=fn;}setAttribute(k,v){this.attributes[k]=v;}showModal(){this.open=true;}close(){this.open=false;}click(){return this.handlers.click?.();}remove(){}
}
function adapter(sqlite){return {prepare(sql){const statement=sqlite.prepare(sql);return {bind(...args){return {first:async()=>statement.get(...args)||null,all:async()=>({results:statement.all(...args)}),run:async()=>statement.run(...args),execute:()=>statement.run(...args)}}}},async batch(statements){sqlite.exec('BEGIN');try{const result=statements.map(s=>s.execute());sqlite.exec('COMMIT');return result;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};}
function find(element,predicate){if(predicate(element))return element;for(const c of element.children){const result=find(c,predicate);if(result)return result;}}
const strip=s=>s.normalize('NFD').replace(/[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]/g,'').normalize('NFC');
function harness(db,article){
 const elements=new Map(),el=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};let languageCalls=0;const exports=[];
 el('importTitle').textContent=article.title;el('sourceLink').href=article.url;el('sourceLink').hidden=false;el('translation').hidden=true;el('contextTranslation').hidden=true;
 const rows=article.paragraphs.map(p=>p.split(/\s+/).map(w=>[w,w,'','','']));const snapshot={tokens:[rows[0][0][0]],context:article.paragraphs[0]};
 const c=vm.createContext({HebrewText,externalSelection:()=>null,articleTitle:article.title,sentenceForSelection:ids=>article.paragraphs[0].split(/(?<=\.)\s/)[0],document:{getElementById:el,createElement:tag=>new Element(tag),createTextNode:text=>{const n=new Element();n.textContent=text;return n;},body:new Element()},rows,punctuation:rows.map(()=>''),active:'0-0',importedMode:true,currentAssist:null,Intl,Date,JSON,Blob,URL:{createObjectURL(blob){exports.push(blob);return "blob:test";},revokeObjectURL(){}},structuredClone,setTimeout:fn=>fn(),stripLocalNikud:strip,preparedTranslation:()=>null,getData:id=>{const [i,j]=id.split('-').map(Number);return rows[i][j];},selectionRequest:()=>({ids:['0-0'],input:snapshot}),closeAssistant(){c.active=null;},render(){},confirm:()=>true,getAssistanceResult:async()=>{languageCalls++;return {confident:true,hint:'גשם שיורד מהשמים',pronunciation:'ha-geshem',tokens:[{original:rows[0][0][0],nikud:'הַגֶּשֶׁם'}],translation:'the rain',lemma:'גֶּשֶׁם',lemmaTranslation:'rain'};},fetch:async(url,opts)=>{
  assert.equal(url,'/api/vocabulary');const v=opts.body?JSON.parse(opts.body):null;const owner='test-owner';let result;
  if(opts.method==='POST')result=v.enrichOnly?await enrichVocabulary(db,owner,validateVocabulary(v.entry)):await saveVocabulary(db,owner,validateVocabulary(v));else if(opts.method==='GET')result={entries:await listVocabulary(db,owner),storage:'account'};else{await changeVocabulary(db,owner,v.id,opts.method==='PATCH'?v.status:undefined);result={ok:true};}
  return {ok:true,json:async()=>result};
 }});
 c.readerStorage=c.localStorage;vm.runInContext(fs.readFileSync(new URL('../public/vocabulary-client.js',import.meta.url),'utf8'),c);return {c,el,languageCalls:()=>languageCalls,exports};
}
test('save from real Ynet import without showing translation; reopen bank after a fresh UI context; reveal and review',async()=>{
 // A recorded real public article returned by the live importer; language response is controlled.
 const fixture=process.env.HEBREW_QUEST_ARTICLE_FIXTURE;
 const article=fixture?JSON.parse(fs.readFileSync(fixture,'utf8')):{title:'Ynet weather article',url:'https://www.ynet.co.il/news/article/rkk005oepfl',paragraphs:['הגשם הכבד שירד ביום שלישי האחרון, יום הבחירות, באזור הדרום, שבר גם שיא חדש שלא נמדד עד כה באזורי המדבר. 35.6 מ"מ ירדו ב-10 דקות בלבד באזור מכתש רמון.']};
 const sqlite=new DatabaseSync(':memory:');for(const f of fs.readdirSync(new URL('../drizzle/',import.meta.url)).filter(f=>f.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync(new URL('../drizzle/'+f,import.meta.url),'utf8'));const db=adapter(sqlite);
 let h=harness(db,article);await h.el('saveVocabulary').click();assert.equal(h.languageCalls(),1);assert.equal(h.el('translation').hidden,true);assert.equal(h.el('contextTranslation').hidden,true);
 const saved=(await listVocabulary(db,'test-owner'))[0];assert.equal(saved.expression,'הגשם');assert.equal(saved.translation,'the rain');assert.equal(saved.examples[0].title,article.title);assert.equal(saved.examples[0].url,article.url);assert.match(saved.examples[0].sentence,/שיא חדש/);assert.doesNotMatch(saved.examples[0].sentence,/35\.6/);
 // A new UI/VM emulates refresh: no client array or previously selected expression is retained.
 h=harness(db,article);await h.el('myVocabulary').click();const list=h.el('vocabularyList');assert.equal(h.el('vocabularyDialog').open,true);
 let word=find(list,e=>e.className==='vocabExpression');assert.equal(word.textContent,'הגשם');let meaning=find(list,e=>e.className==='vocabEnglish');assert.equal(meaning.hidden,true);
 await find(list,e=>e.tag==='button'&&e.textContent==='Reveal nikud').click();assert.equal(word.textContent,'הַגֶּשֶׁם'.normalize('NFC'));assert.equal(meaning.hidden,true);
 await find(list,e=>e.tag==='button'&&e.textContent==='Reveal translation').click();assert.equal(meaning.hidden,false);assert.equal(meaning.textContent,'the rain');
 await h.el('startReview').click();const review=h.el('vocabularyReview');assert.equal(find(review,e=>e.className==='vocabEnglish').hidden,true);assert.equal(find(review,e=>e.className==='vocabExpression').textContent,'הגשם');
 await find(review,e=>e.tag==='button'&&e.textContent==='Reveal answer').click();assert.equal(find(review,e=>e.className==='vocabEnglish').hidden,false);
 await find(review,e=>e.tag==='button'&&e.textContent==='Remembered').click();assert.equal((await listVocabulary(db,'test-owner'))[0].status,'recognised');assert.match(review.textContent,/reviewed this set/);
 h.el('vocabularySearch').value='nonmatching';h.c.renderVocabulary();assert.match(h.el('vocabularyList').textContent,/No matching/);
 h.el('vocabularySearch').value='';await h.el('exportVocabulary').click();const json=await h.exports[0].text();const backup=JSON.parse(json);assert.equal(backup.format,'hebrew-quest-vocabulary');assert.equal(backup.entries[0].status,'recognised');
 await find(h.el('vocabularyList'),e=>e.tag==='button'&&e.textContent==='Delete').click();assert.equal((await listVocabulary(db,'test-owner')).length,0);
 for(let n=0;n<2;n++)await h.el('vocabularyFile').handlers.change({target:{files:[{size:json.length,text:async()=>json}],value:'backup.json'}});
 assert.equal((await listVocabulary(db,'test-owner')).length,1);assert.equal((await listVocabulary(db,'test-owner'))[0].examples.length,1);
 const next={...saved,expression:'הכבד',nikud:'הַכָּבֵד',translation:'the heavy',lemma:'כָּבֵד',lemmaTranslation:'heavy',status:'needs_review',examples:saved.examples.map(e=>({...e,expression:'הכבד',nikud:'הַכָּבֵד',translation:'the heavy'}))};await saveVocabulary(db,'test-owner',validateVocabulary(next));await h.c.loadVocabulary();h.c.startVocabularyReview();assert.equal(find(review,e=>e.className==='vocabExpression').textContent,'הכבד');
 sqlite.close();
});

test('mismatched or failed language help saves the immutable exact selection as incomplete, never an unrelated word',async()=>{
 const article={title:'Test article',url:'https://www.ynet.co.il/news/article/example',paragraphs:['הגשם ירד היום.']};
 const sqlite=new DatabaseSync(':memory:');for(const f of fs.readdirSync(new URL('../drizzle/',import.meta.url)).filter(f=>f.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync(new URL('../drizzle/'+f,import.meta.url),'utf8'));const db=adapter(sqlite),h=harness(db,article);
 h.c.getAssistanceResult=async()=>({confident:true,tokens:[{original:'תפקיד',nikud:'תַּפְקִיד'}],hint:'משרה',translation:'role',lemma:'תַּפְקִיד',lemmaTranslation:'role',pronunciation:''});
 await h.el('saveVocabulary').click();const saved=(await listVocabulary(db,'test-owner'))[0];assert.equal(saved.expression,'הגשם');assert.equal(saved.nikud,'');assert.equal(saved.translation,'');assert.equal(saved.lemma,'');assert.equal(saved.incomplete,true);assert.equal(saved.examples[0].expression,'הגשם');assert.match(h.el('vocabSaveStatus').textContent,/incomplete/);sqlite.close();
});
