import test from 'node:test';import assert from 'node:assert/strict';import {harness,settle} from './helpers/interactive-harness.mjs';
const first='https://www.ynet.co.il/news/article/first',second='https://www.ynet.co.il/news/article/second';
const value=title=>({title,paragraphs:['זהו משפט ראשון בכתבה.','כן.','כן.','סוף.'],url:second});
function setup(){
 const pending=[];const h=harness({fetcher:(url,options,fallback)=>String(url).startsWith('/api/import?')?new Promise((resolve,reject)=>pending.push({resolve,reject,url,signal:options.signal})):fallback(url,options)});
 h.setChallenge({title:'כתבה קיימת',paragraphs:['הגשם ירד ביום שלישי.'],url:first});h.el('challengeAnswer').value='My unfinished answer';h.run("readerStorage.setItem('audit-draft','Keep my draft');vocabularyEntries=[{expression:'מילה שמורה'}]");
 const snapshot=()=>JSON.stringify({state:h.run('JSON.stringify({rows,articleTitle,challengeArticle,challengeSession,vocabularyEntries,active,selectionIds})'),body:h.el('article').textContent,answer:h.el('challengeAnswer').value,storage:[...h.storage.entries()]});
 const start=url=>{h.el('articleUrl').value=url;return h.el('importUrl').click();};return {h,pending,snapshot,start};
}
test('slow import has a clear cancellable busy state; accidental duplicate submissions make one request and do not touch current work',async()=>{
 const {h,pending,snapshot,start}=setup();await settle();const before=snapshot(),a=start(first);assert.equal(pending.length,1);assert.equal(h.el('importUrl').disabled,true);assert.equal(h.el('importUrl').getAttribute('aria-busy'),'true');assert.equal(h.el('cancelImport').hidden,false);assert.match(h.el('importStatus').textContent,/keep reading or cancel/);await start(first);await settle();assert.equal(pending.length,1);assert.equal(snapshot(),before);pending[0].resolve(Response.json(value('כתבה חדשה')));await a;assert.equal(h.el('importUrl').disabled,false);assert.equal(h.el('cancelImport').hidden,true);
});
test('latest import wins even when an aborted older fetch ignores cancellation and resolves later',async()=>{
 const {h,pending,snapshot,start}=setup();await settle();const a=start(first);h.el('articleUrl').value=second;await h.el('articleUrl').fire('input');assert.equal(h.el('importUrl').disabled,false);const b=start(second);assert.equal(pending[0].signal.aborted,true);pending[1].resolve(Response.json(value('כתבה שנבחרה אחרונה')));await b;const winner=snapshot(),status=h.el('importStatus').textContent;pending[0].resolve(Response.json(value('תגובה ישנה')));await a;assert.equal(snapshot(),winner);assert.equal(h.el('importStatus').textContent,status);assert.equal(h.run('articleTitle'),'כתבה שנבחרה אחרונה');
});
test('a stale JSON body cannot commit after the response headers have already arrived',async()=>{
 const {h,pending,snapshot,start}=setup();await settle();let body;const a=start(first);pending[0].resolve({ok:true,json:()=>new Promise(resolve=>body=resolve)});await settle();const b=start(second);pending[1].resolve(Response.json(value('הכי חדשה')));await b;const winner=snapshot();body(value('גוף ישן ואיטי'));await a;assert.equal(snapshot(),winner);
});
test('cancel preserves article, vocabulary, progress and challenge drafts, including a late success',async()=>{
 const {h,pending,snapshot,start}=setup();await settle();const before=snapshot(),a=start(first);await h.el('cancelImport').click();assert.equal(pending[0].signal.aborted,true);assert.equal(snapshot(),before);assert.match(h.el('importStatus').textContent,/cancelled.*unchanged/);const status=h.el('importStatus').textContent;pending[0].resolve(Response.json(value('מאוחר מדי')));await a;assert.equal(snapshot(),before);assert.equal(h.el('importStatus').textContent,status);assert.equal(h.el('importUrl').disabled,false);
});
test('failed imports retain current work and restore controls, with a usable recovery message',async()=>{
 const {h,pending,snapshot,start}=setup();await settle();const before=snapshot(),a=start(first);pending[0].resolve(Response.json({error:'Publisher returned HTTP 403.'},{status:422}));await a;assert.equal(snapshot(),before);assert.match(h.el('importStatus').textContent,/403.*unchanged.*paste/);assert.equal(h.el('importUrl').disabled,false);assert.equal(h.el('cancelImport').hidden,true);
});
test('a slow network rejection after cancellation does not replace the cancellation state',async()=>{
 const {h,pending,snapshot,start}=setup();await settle();const before=snapshot(),a=start(first);await h.el('cancelImport').click();const status=h.el('importStatus').textContent;pending[0].reject(new TypeError('Network disconnected'));await a;assert.equal(snapshot(),before);assert.equal(h.el('importStatus').textContent,status);
});
test('an aborted request may finish late without unlocking the next request or hiding its Cancel button',async()=>{
 const {h,pending,start}=setup();await settle();const a=start(first);await h.el('cancelImport').click();const b=start(second);pending[0].reject(new DOMException('Aborted','AbortError'));await a;assert.equal(h.el('importUrl').disabled,true);assert.equal(h.el('cancelImport').hidden,false);assert.match(h.el('importStatus').textContent,/Importing/);pending[1].resolve(Response.json(value('חדש')));await b;assert.equal(h.run('articleTitle'),'חדש');
});
test('a newer failed import never revives an older successful response',async()=>{
 const {h,pending,snapshot,start}=setup();await settle();const before=snapshot(),a=start(first),b=start(second);pending[1].reject(new TypeError('Offline'));await b;const status=h.el('importStatus').textContent;pending[0].resolve(Response.json(value('ישן')));await a;assert.equal(snapshot(),before);assert.equal(h.el('importStatus').textContent,status);
});
test('pasted article and Return to practice invalidate pending URL imports',async()=>{
 for(const action of ['paste','practice']){const {h,pending,snapshot,start}=setup();await settle();const a=start(first);if(action==='paste'){h.el('pasteTitle').value='כתבה שהודבקה';h.el('pasteText').value='כן.\nכן.\nסוף.';await h.el('loadPaste').click();assert.equal(h.run('rows.length'),4);}else await h.el('sample').click();const winner=snapshot();assert.equal(pending[0].signal.aborted,true);pending[0].resolve(Response.json(value('ישן')));await a;assert.equal(snapshot(),winner);}
});
test('opening another saved article invalidates pending URL imports and preserves all 151 paragraphs',async()=>{
 const {h,pending,snapshot,start}=setup();await settle();const a=start(first);h.c.longParagraphs=Array.from({length:150},(_,i)=>'פסקה '+i);h.c.longParagraphs.push('סוף.');h.run('loadArticleText("כתבה שמורה",longParagraphs,"https://www.ynet.co.il/news/article/saved")');assert.equal(h.run('rows.length'),152);const winner=snapshot();pending[0].resolve(Response.json(value('ישן')));await a;assert.equal(snapshot(),winner);
});
test('oversized and malformed responses do not replace the displayed article or saved work',async()=>{
 for(const data of [{title:'גדול',paragraphs:['א'.repeat(120001)],url:first},{title:'לא תקין',url:first},{title:{malformed:true},paragraphs:['טקסט.'],url:first},{title:'א'.repeat(301),paragraphs:['טקסט.'],url:first},{title:'כותרת',paragraphs:[null],url:first}]){const {h,pending,snapshot,start}=setup();await settle();const before=snapshot(),a=start(first);pending[0].resolve(Response.json(data));await a;assert.equal(snapshot(),before);assert.match(h.el('importStatus').textContent,/unchanged/);if(data.title==='גדול')assert.match(h.el('importStatus').textContent,/120,000-character.*Nothing was imported or shortened/);}
});
test('stale URL results never write account article history, vocabulary or challenge progress',async()=>{
 const pending=[],writes=[];const profile={id:'import-account',email:'import@example.com',legacyOwner:false,preferencesSet:true,preferences:{}};
 const h=harness({account:profile,fetcher:(url,options,fallback)=>{
  if(String(url).startsWith('/api/import?'))return new Promise(resolve=>pending.push(resolve));
  if(options?.method&&options.method!=='GET')writes.push({url,input:options.body?JSON.parse(options.body):null});
  if(url==='/api/account')return Response.json(profile);if(url==='/api/articles')return Response.json({id:'history-entry'});return fallback(url,options);
 }});await settle();h.setChallenge({title:'קיימת',paragraphs:['משפט קיים.'],url:first});h.el('challengeAnswer').value='Unfinished';await settle();writes.length=0;
 h.el('articleUrl').value=first;const a=h.el('importUrl').click();h.el('articleUrl').value=second;const b=h.el('importUrl').click();pending[1](Response.json(value('נבחרה אחרונה')));await b;await settle();const committed=JSON.stringify(writes);assert.equal(writes.filter(w=>w.url==='/api/articles').length,1);assert.equal(writes[0].input.title,'נבחרה אחרונה');assert.equal(writes.some(w=>w.url==='/api/vocabulary'||w.url==='/api/challenges'),false);pending[0](Response.json(value('ישנה')));await a;await settle();assert.equal(JSON.stringify(writes),committed);assert.equal(h.el('challengeAnswer').value,'Unfinished');
});
test('version 20 latest-import protection also holds with continuity and the durable save queue enabled',async()=>{
 const pending=[],archives=[];const h=harness({withSync:true,fetcher:(url,options,fallback)=>{if(String(url).startsWith('/api/import?'))return new Promise(resolve=>pending.push(resolve));if(url==='/api/articles'){if(options?.method==='POST'){archives.push(JSON.parse(options.body));return Response.json({id:'saved-copy'});}return Response.json({articles:[]});}return fallback(url,options);}});await settle();h.setChallenge({title:'קיימת',paragraphs:['משפט קיים.'],url:first});await h.c.ReaderSync.retry();archives.length=0;h.el('articleUrl').value=first;const a=h.el('importUrl').click();h.el('articleUrl').value=second;const b=h.el('importUrl').click();pending[1](Response.json(value('הבחירה האחרונה')));await b;await h.c.ReaderSync.retry();const saved=JSON.stringify(archives),place=JSON.stringify(h.c.ReaderContinuity.local());pending[0](Response.json(value('תגובה ישנה')));await a;assert.equal(JSON.stringify(archives),saved);assert.equal(JSON.stringify(h.c.ReaderContinuity.local()),place);assert.equal(archives.length,1);assert.equal(h.run('articleTitle'),'הבחירה האחרונה');
});
