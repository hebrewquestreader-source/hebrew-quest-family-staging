import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import {load} from 'cheerio/slim';
import {extractArticle,robotsAllowed,importArticle} from '../lib/importer.ts';
import {validateArticle} from '../lib/challenges.ts';
import {MAX_ARTICLE_CHARACTERS} from '../lib/article-limits.ts';
import {database,apiHarness} from './helpers/api-harness.mjs';
const url='https://www.ynet.co.il/news/article/rkk005oepfl';
const intro='זהו משפט פתיחה ארוך לכתבה לצורך בדיקת שמירת הטקסט המקורי, כולל משפטים קצרים, ציטוטים ופסקאות חוזרות ללא שינוי בסדר הופעתם. '.repeat(2);
const html=body=>'<h1>כותרת לבדיקה</h1><article>'+body+'</article>';
const escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
const article=ps=>html(ps.map(p=>'<p>'+escape(p)+'</p>').join(''));
test('retains one-word sentences, short quotations, punctuation, numeric/foreign lines and the final paragraph in source order',()=>{
 const ps=[intro,'כן.','"לא."','2026','Jean-Luc','סוף.'];const r=extractArticle(article(ps),url);assert.deepEqual(r.paragraphs,ps.map(s=>s.trim()));
});
test('retains intentional repeats while choosing one article body, not duplicate matching roots',()=>{
 const ps=[intro,'הדיון נמשך מחר.','הדיון נמשך מחר.','סוף.'];const page='<article><div id="articleBody">'+ps.map(s=>'<p>'+s+'</p>').join('')+'</div></article>';
 assert.deepEqual(extractArticle(page,url).paragraphs,ps.map(s=>s.trim()));
});
test('preserves more than 100 paragraphs, the ending, and the downstream archive/challenge validation',async()=>{
 const ps=[intro,...Array.from({length:149},(_,i)=>'פסקה '+i+'.'),'סוף הכתבה.'];const r=extractArticle(article(ps),url);assert.equal(r.paragraphs.length,151);assert.equal(r.paragraphs.at(-1),'סוף הכתבה.');assert.deepEqual(validateArticle(r).paragraphs,r.paragraphs);
 const {sqlite}=database(),api=apiHarness(sqlite),user={id:'import-tester',email:'import@example.com'};
 const saved=await api.call('articles',user,'POST',r);assert.equal(saved.status,200);const id=(await saved.json()).id;
 const stored=JSON.parse(sqlite.prepare('SELECT article_json FROM imported_articles WHERE id=?').get(id).article_json);assert.deepEqual(stored.paragraphs,r.paragraphs);
 const session=await api.call('challenges',user,'POST',{action:'open',article:r,mode:'NORMAL',short:false});assert.equal(session.status,200);const state=(await session.json()).session;assert.equal(state.scope.paragraphs.length,151);assert.equal(state.scope.paragraphs.at(-1),'סוף הכתבה.');assert.equal(sqlite.prepare('SELECT count(*) n FROM reading_completions').get().n,0);sqlite.close();
});
test('retains nested quotations, subheadings, list text, line breaks and inline emphasis without duplicating DOM text',()=>{
 const page=html('<p>'+intro+'</p><h2>כותרת משנה</h2><blockquote>"לפני"<p>"ציטוט קצר"</p>"אחרי"</blockquote><ul><li>פריט ראשון<ul><li>פריט פנימי</li></ul>סיום הפריט</li></ul><p>שורה ראשונה<br>שורה שנייה <strong>חשובה</strong>.</p><p>סוף.</p>');
 assert.deepEqual(extractArticle(page,url).paragraphs,[intro.trim(),'כותרת משנה','"לפני"','"ציטוט קצר"','"אחרי"','פריט ראשון','פריט פנימי','סיום הפריט','שורה ראשונה','שורה שנייה חשובה.','סוף.']);
});
test('preserves short Draft.js paragraphs and repeated text, excluding navigation, advertising, related and hidden content',()=>{
 const ps=[intro,'כן.','כן.','סוף.'];const page='<nav><p>ניווט</p></nav><div class="article-body">'+ps.map((s,i)=>'<div class="text_editor_paragraph">'+s+'</div>'+(i===0?'<div class="advert"><p>פרסומת</p><div class="text_editor_paragraph">פרסומת</div></div><aside><p>קראו גם</p></aside><div class="related"><p>כתבות נוספות</p></div><div hidden><p>מוסתר</p></div>':'')).join('')+'</div>';
 assert.deepEqual(extractArticle(page,url).paragraphs,ps.map(s=>s.trim()));
});
test('does not collect short paragraphs from page-wide navigation or unrelated page content',()=>{
 assert.throws(()=>extractArticle('<h1>כותרת</h1><nav>'+Array(60).fill('<p>חדשות</p>').join('')+'</nav><div><p>'+intro+'</p></div>',url),/No accessible/);
});
test('Draft.js fallback preserves visible breaks and does not duplicate nested blocks',()=>{
 const page='<div class="text_editor_paragraph">'+intro+'<div class="text_editor_paragraph">כן.<br>סוף.</div></div>';
 assert.deepEqual(extractArticle(page,url).paragraphs,[intro.trim(),'כן.','סוף.']);
});
test('text at the documented safety boundary is retained through its final character',()=>{
 const ps=['א'.repeat(MAX_ARTICLE_CHARACTERS-5),'סוף.'];const r=extractArticle(article(ps),url);assert.equal(r.paragraphs.join('\n').length,MAX_ARTICLE_CHARACTERS);assert.deepEqual(validateArticle(r).paragraphs,ps);assert.equal(r.paragraphs.at(-1),'סוף.');
});
test('rejects oversized complete text explicitly rather than returning a truncated article',()=>{
 const ps=[intro,'א'.repeat(MAX_ARTICLE_CHARACTERS),'סוף.'];assert.throws(()=>extractArticle(article(ps),url),/120,000-character.*Nothing was imported or shortened.*paste a shorter section/);assert.throws(()=>validateArticle({title:'כותרת',url,paragraphs:ps}),/120,000-character/);
});
test('keeps subscription markers, hidden subscription text and robots restrictions enforced',()=>{
 assert.throws(()=>extractArticle('<script type="application/ld+json">{"isAccessibleForFree":false}</script>'+article([intro]),url),/subscription-only/);
 assert.throws(()=>extractArticle('<div data-paywall="true"></div>'+article([intro]),url),/subscription-only/);
 assert.equal(robotsAllowed('User-agent: *\nDisallow: /news/',new URL(url)),false);
});
test('download safety limit reports recovery and does not return a partial article',async()=>{
 const original=globalThis.fetch;globalThis.fetch=async target=>String(target).endsWith('/robots.txt')?new Response('User-agent: *\nAllow: /'):new Response('large',{headers:{'Content-Type':'text/html','Content-Length':'3000001'}});
 try{await assert.rejects(()=>importArticle(url),/3 MB.*Nothing was imported or shortened.*paste text/);}finally{globalThis.fetch=original;}
});
test('recorded real Ynet visible article paragraphs match exactly, including the ending', {skip:!process.env.HEBREW_QUEST_PUBLISHER_FIXTURE},()=>{
 const source=fs.readFileSync(process.env.HEBREW_QUEST_PUBLISHER_FIXTURE,'utf8'),$=load(source);const expected=$('#ArticleBodyComponent .text_editor_paragraph').toArray().map(el=>$(el).text().replace(/\s+/g,' ').trim()).filter(Boolean);assert.ok(expected.length>0);const r=extractArticle(source,url);assert.deepEqual(r.paragraphs,expected);assert.equal(r.paragraphs.at(-1),expected.at(-1));
});
