import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {load} from 'cheerio';
import {harness,settle} from './helpers/interactive-harness.mjs';
const css=fs.readFileSync(new URL('../public/app-shell.css',import.meta.url),'utf8');
const polish=css.split('/* v39:')[1];
const calm=async()=>{for(let i=0;i<6;i++)await settle();};
const article={title:'כותרת עברית עם English',url:'https://www.ynet.co.il/news/article/polish39',paragraphs:['משפחתו קראה כתבה מעניינת.','English quotation: “Read this in order.”','סוף הכתבה.']};

test('quick tools retain article nodes, original mixed text, reading preferences and navigation state at representative widths (simulated DOM)',async()=>{
 for(const width of [320,412,768,1440]){
  const h=harness();await calm();h.c.window.innerWidth=width;h.c.fixture=article;h.run('loadArticleText(fixture.title,fixture.paragraphs,fixture.url)');
  await h.el('readingSizeUp').click();
  const nodes=[...h.el('article').children],text=h.el('article').textContent,prefs=h.run('JSON.stringify(settings)'),font=h.body.style['--reading-font'];
  await h.el('quickReadingButton').click();assert.equal(h.el('quickReadingPanel').hidden,false);
  await h.el('quickReadingClose').click();assert.equal(h.el('quickReadingPanel').hidden,true);
  assert.deepEqual(h.el('article').children,nodes);assert.equal(h.el('article').textContent,text);assert.ok(text.includes('Read this in order.'));
  assert.equal(h.el('importTitle').textContent,article.title);assert.equal(h.body.style['--reading-font'],font);
  assert.equal(h.run('JSON.stringify(settings)'),prefs);assert.equal(h.c.AppPages.current(),'read');
 }
});

test('Vocabulary card polish retains exact expression and separate meaning and nikud reveal controls',async()=>{
 const h=harness();await calm();h.c.entry={id:'v39',expression:'משפחתו',nikud:'מִשְׁפַּחְתּוֹ',translation:'his family',lemma:'מִשְׁפָּחָה',lemmaTranslation:'family',status:'needs_review',examples:[{sentence:'משפחתו קראה כתבה.',title:article.title,url:article.url,savedAt:'2026-11-01T08:00:00Z'}]};
 h.run('vocabularyEntries=[entry];renderVocabulary()');
 let card=h.el('vocabularyList').children[0];
 assert.equal(card.querySelector('.vocabExpression').textContent,'משפחתו');
 assert.equal(card.querySelector('.vocabEnglish').hidden,true);
 assert.equal(!!card.open,false);
 const buttons=card.querySelectorAll('button');
 assert.ok(buttons.some(b=>b.textContent==='Needs review'));assert.ok(buttons.some(b=>b.textContent==='Delete'));
 await buttons.find(b=>b.textContent==='Reveal nikud').click();
 assert.equal(card.querySelector('.vocabExpression').textContent,h.c.entry.nikud);
 assert.equal(card.querySelector('.vocabEnglish').hidden,true);
 await card.querySelector('.vocabQuickReveal').click();
 assert.equal(card.open,true);assert.equal(card.querySelector('.vocabEnglish').hidden,false);
 assert.equal(card.querySelector('.vocabEnglish').textContent,'his family');
 assert.equal(h.c.entry.expression,'משפחתו');assert.equal(card.querySelector('.vocabSentence').textContent,'משפחתו קראה כתבה.');
});

test('presentation contracts preserve preferences, stable tools, native hidden fields and responsive editorial frames',()=>{
 const html=fs.readFileSync(new URL('../lib/reader.html',import.meta.url),'utf8'),$=load(html);
 assert.equal($('link[href="/app-shell.css?v=39"]').length,1);
 assert.match(html,/\.quickReadingPanel\{position:fixed/);
 assert.match(html,/#article\.hebrew\{[^}]*font-size:var\(--reading-font/);
 assert.match(polish,/#discoverDialog \.discoverCover\{aspect-ratio:16\/9/);
 assert.match(polish,/@media\(max-width:600px\)/);
 assert.match(polish,/\.discoverCard:not\(\.featured\) \.discoverCover\{aspect-ratio:1\/1/);
 assert.match(polish,/:focus-visible\{outline:3px/);
 assert.match(polish,/min-height:44px/);
 assert.match(polish,/@media\(prefers-reduced-motion:reduce\)/);
 assert.doesNotMatch(polish,/\[hidden\]|\.side\s*\{|\.primaryNavigation|grid-template-columns|transform:|@keyframes|--reading-font\s*:|--reading-leading\s*:/);
});

test('shared metadata, focus and primary button palette retains readable contrast',()=>{
 const luminance=hex=>{const c=hex.match(/../g).map(x=>parseInt(x,16)/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4);return c[0]*.2126+c[1]*.7152+c[2]*.0722;};
 const ratio=(a,b)=>{const x=luminance(a),y=luminance(b);return(Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
 for(const [ink,paper]of [['50656b','fffefa'],['50656b','f4f1e9'],['106b68','fffefa'],['ffffff','147d79']])assert.ok(ratio(ink,paper)>=4.5,`${ink} on ${paper}`);
});
