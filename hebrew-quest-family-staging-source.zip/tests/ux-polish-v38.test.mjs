import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {load} from 'cheerio';
import {harness,settle} from './helpers/interactive-harness.mjs';

const calm=async()=>{for(let i=0;i<6;i++)await settle();};
const article={title:'כתבה לקריאה',url:'https://www.ynet.co.il/news/article/polish',paragraphs:['תפקיד חשוב במשפחה.','הפסקה השנייה נשמרת.']};
const loadArticle=h=>{h.c.fixture=article;h.run('loadArticleText(fixture.title,fixture.paragraphs,fixture.url)');};
const successTimers=h=>[...h.timers.values()].filter(fn=>String(fn).includes('shown.get(id)'));
const expireSuccess=h=>{for(const fn of successTimers(h))fn();};

test('paused AI has one compact native disclosure with accurate retry details and no requests on expansion',async()=>{
 const h=harness();await calm();loadArticle(h);const before=h.requests.length,at=Date.now()+60000;
 h.c.AIAvailability.observe({code:'local_quota',retryAt:at});
 assert.equal(h.el('aiUnavailableNotice').tagName,'DETAILS');
 assert.equal(h.el('aiUnavailableNotice').hidden,false);
 assert.equal(!!h.el('aiUnavailableNotice').open,false);
 assert.equal(h.el('readerArticleActions').contains(h.el('aiUnavailableNotice')),true);
 assert.equal(h.el('readerSecondary').contains(h.el('aiUnavailableNotice')),false);
 assert.match(h.el('aiUnavailableNotice').querySelector('summary').textContent,/AI help paused/);
 assert.match(h.el('aiRetryInformation').textContent,/New requests can be tried after/);
 assert.equal(h.el('retryNewHelp').hidden,true);
 const held=JSON.stringify(h.c.AIAvailability.snapshot().hold);
 h.el('aiUnavailableNotice').open=true;h.el('aiUnavailableNotice').open=false;
 assert.equal(JSON.stringify(h.c.AIAvailability.snapshot().hold),held);
 assert.equal(h.requests.length,before);
 assert.equal(h.body.querySelectorAll('#aiUnavailableNotice').length,1);
});

test('unknown AI retry time is not invented and normal state returns without a model request',async()=>{
 const h=harness();await calm();const before=h.requests.length;
 h.c.AIAvailability.observe({code:'quota'});
 assert.match(h.el('aiRetryInformation').textContent,/No retry time was supplied/);
 assert.equal(h.el('retryNewHelp').hidden,false);
 h.el('aiUnavailableNotice').open=true;
 const start=Date.now();h.c.AIAvailability.observe({code:'local_quota',retryAt:start+5000});
 h.c.Date=class extends Date{static now(){return start+6000;}};
 assert.equal(h.c.AIAvailability.paused(),false);
 assert.equal(h.el('aiUnavailableNotice').hidden,true);
 assert.equal(h.el('aiUnavailableNotice').open,false);
 assert.equal(h.el('aiRetryInformation').textContent,'');
 assert.equal(h.requests.length,before);
});

test('save UI does not claim account success before a confirmed response and hides success without changing queue data',async()=>{
 const h=harness({withSync:true});await calm();let release;
 h.c.ReaderSync.register('polish-confirm',()=>new Promise(resolve=>release=resolve));await calm();
 const key=h.c.ReaderSync.put('polish-confirm','one',{value:'kept'});await calm();
 assert.equal(h.el('accountSyncStatus').textContent,'Saving…');
 assert.equal(h.el('saveStatus').dataset.saveState,'saving');
 assert.equal(h.el('accountSyncRetry').hidden,true);
 assert.doesNotMatch(h.el('accountSyncStatus').textContent,/Saved to account/);
 assert.equal(h.c.ReaderSync.state(key).payload.value,'kept');
 release();await calm();
 assert.equal(h.el('accountSyncStatus').textContent,'Saved to account.');
 assert.equal(h.c.ReaderSync.state(key),null);
 expireSuccess(h);
 assert.equal(h.el('accountSyncStatus').textContent,'');
 assert.equal(h.el('saveStatus').hidden,true);
 h.c.ReaderSync.notify();
 assert.equal(h.el('saveStatus').hidden,true,'repeated notifications do not resurrect a stale success');
 assert.equal(h.c.ReaderSync.all().length,0);
});

test('failed sync remains visible with retained error details and uses the original manual retry mechanism',async()=>{
 const h=harness({withSync:true});await calm();let fail=true,calls=0;
 h.c.ReaderSync.register('polish-retry',async()=>{calls++;if(fail)throw Error('Transport unavailable');});await calm();
 const key=h.c.ReaderSync.put('polish-retry','two',{text:'original'});await calm();
 assert.match(h.el('accountSyncStatus').textContent,/Sync paused.*device/);
 assert.match(h.el('syncStatusDetailText').textContent,/Transport unavailable/);
 assert.equal(h.el('syncStatusDetails').hidden,false);
 assert.equal(h.el('accountSyncRetry').hidden,false);
 const pending=JSON.stringify(h.c.ReaderSync.state(key));expireSuccess(h);
 assert.equal(JSON.stringify(h.c.ReaderSync.state(key)),pending);
 assert.equal(h.el('saveStatus').hidden,false);
 assert.equal(calls,1);
 fail=false;await h.el('accountSyncRetry').click();await calm();
 assert.equal(calls,2);assert.equal(h.c.ReaderSync.state(key),null);
 assert.equal(h.el('accountSyncStatus').textContent,'Saved to account.');
});

test('success timeout cannot erase a newer error and identical status updates do not reset timers',async()=>{
 const h=harness();await calm();
 h.c.ReaderStatus.show('challengeStatus','Saved answer to account.',{transient:true,state:'saved'});
 const timer=successTimers(h).at(-1),count=successTimers(h).length;
 h.c.ReaderStatus.show('challengeStatus','Saved answer to account.',{transient:true,state:'saved'});
 assert.equal(successTimers(h).length,count);
 h.c.ReaderStatus.show('challengeStatus','Sync paused · draft kept on this device.',{state:'retry'});
 timer();assert.match(h.el('challengeStatus').textContent,/Sync paused/);
 assert.equal(h.el('challengeStatus').hidden,false);
 h.c.ReaderStatus.show('vocabSaveStatus','Saved to account.',{transient:true,state:'saved'});
 const directTimer=successTimers(h).at(-1);h.el('vocabSaveStatus').textContent='A later error from an existing controller';
 directTimer();assert.equal(h.el('vocabSaveStatus').textContent,'A later error from an existing controller');
});

test('language-enrichment-only recovery does not present itself as loss of the original vocabulary save',async()=>{
 const h=harness({withSync:true});await calm();
 h.c.ReaderSync.register('enrichment',async()=>{throw Error('New help is temporarily unavailable.');});await calm();
 const before=h.requests.length,key=h.c.ReaderSync.put('enrichment','test',{entry:{expression:'תפקיד'}});await calm();
 assert.equal(h.el('accountSyncStatus').textContent,'Language details pending.');
 assert.match(h.el('syncStatusDetailText').textContent,/New help is temporarily unavailable/);
 assert.equal(h.c.ReaderSync.state(key).state,'retry');
 assert.equal(h.requests.length,before,'presentation does not call the AI service');
});

test('Reader keeps the article first and groups continuation, help, reset and diagnostics without losing controls or preferences',async()=>{
 const h=harness({withSync:true});await calm();loadArticle(h);
 const text=h.el('article').textContent,prefs=h.run('JSON.stringify(settings)'),nodes=[...h.el('article').children];
 assert.equal(h.el('readerOptions').tagName,'DETAILS');assert.equal(h.el('readerOptions').open,false);
 for(const id of ['continueReadingPanel','readerHelpToggle','readingTools','clear','sample','footerText'])assert.equal(h.el('readerOptions').contains(h.el(id)),true,id);
 assert.equal(h.el('readerOptions').contains(h.el('challengeEntry')),false);
 assert.equal(h.el('challengeEntry').hidden,false);
 h.el('readerOptions').open=true;await h.el('readerHelpToggle').click();
 assert.equal(h.el('readerHelpContent').hidden,false);
 h.el('readingTools').open=true;await h.el('readerHelpToggle').click();h.el('readerOptions').open=false;
 assert.equal(h.el('article').textContent,text);assert.deepEqual(h.el('article').children,nodes);
 assert.equal(h.run('JSON.stringify(settings)'),prefs);
 assert.equal(h.el('importControls').hidden,true);
});

test('quick tools and full Settings describe their separate purposes while retaining every setting',async()=>{
 const h=harness();await calm();loadArticle(h);const prefs=h.run('JSON.stringify(settings)');
 await h.el('quickReadingButton').click();
 assert.match(h.el('quickReadingPanel').querySelector('.quickToolsDescription').textContent,/Quick adjustments/);
 await h.el('quickFullSettings').click();await calm();
 assert.equal(h.c.AppPages.current(),'settings');assert.match(h.el('settingsPanel').querySelector('.settingsDescription').textContent,/Full preferences/);
 for(const id of ['setNikud','setHint','setTranslation','setWordBreakdown','setPron','setAudio','setPrepareAhead','interactiveReservePercent','setLemma','setHighlightExpressions'])assert.ok(h.el('settingsPanel').contains(h.el(id)),id);
 assert.equal(h.run('JSON.stringify(settings)'),prefs);
});

test('Discover polish preserves full metadata and exact Hebrew titles while limiting only visible summary lines',async()=>{
 const title='משפחה בישראל עם שם באנגלית Example ומילים נוספות בכותרת ארוכה',description='תיאור עברי ארוך '.repeat(40);
 const h=harness({withDiscover:true,fetcher:async(url,opts,fallback)=>String(url).startsWith('/api/discover')?Response.json({articles:[{title,description,url:article.url,publisher:'ynet',topics:['culture'],publishedAt:'2026-11-01T08:00:00Z',importable:true}]}):String(url).startsWith('/api/challenges')?Response.json({articlesRead:0,sessions:[],articles:[]}):fallback(url,opts)});
 await calm();await h.el('discoverNav').click();await calm();const card=h.el('discoverArticles').children[0];
 assert.equal(card.querySelector('h3').textContent,title);assert.equal(card.querySelector('.discoverExcerpt').textContent,description);
 assert.equal(card.querySelector('time').dateTime,'2026-11-01T08:00:00Z');assert.equal(card.dataset.articleUrl,article.url);
 assert.equal(h.requests.some(x=>['/api/assist','/api/prepare','/api/hints','/api/breakdown'].includes(x.url)),false);
 const css=fs.readFileSync(new URL('../public/app-shell.css',import.meta.url),'utf8');
 assert.match(css,/\.appPage \.discoverExcerpt\{[^}]*-webkit-line-clamp:3/);
 assert.match(css,/\.appPage \.discoverByline time\{white-space:nowrap/);
 assert.match(css,/\.appPage \.discoverCard h3 \.word\{overflow-wrap:break-word;word-break:normal/);
});

test('presentation assets load before sync and all status disclosures have unique identifiers',()=>{
 const html=fs.readFileSync(new URL('../lib/reader.html',import.meta.url),'utf8'),$=load(html);
 const ids=$('[id]').map((i,n)=>$(n).attr('id')).get();assert.equal(new Set(ids).size,ids.length);
 assert.ok(html.indexOf('/status-ui.js')<html.indexOf('/hebrew-text-client.js'));
 assert.equal($('#aiUnavailableNotice>summary').length,1);assert.equal($('#accountSyncStatus').attr('role'),'status');
 assert.equal($('#readerOptions').is('[open]'),false);assert.equal($('#readerHelpContent').is('[hidden]'),true);
});
