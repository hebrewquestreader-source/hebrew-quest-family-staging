import {HebrewText} from '../lib/hebrew-text.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../public/language-client.js',import.meta.url),'utf8');
function harness(){
 const calls=[];const elements=new Map();const el=id=>{if(!elements.has(id))elements.set(id,{value:'',checked:true,hidden:false,disabled:false,textContent:'',handlers:{},addEventListener(type,fn){this.handlers[type]=fn},focus(){this.focused=true},scrollIntoView(){this.scrolled=true},classList:{toggle(){}}});return elements.get(id)};
 let resolveSetup;
 let harnessContext;const ctx=vm.createContext({HebrewText,externalSelection:()=>null,interactionRow:i=>harnessContext.rows[i],sentenceForSelection:ids=>harnessContext.rows.map(r=>r.map(w=>w[0]).join(' ')).join(' '),document:{getElementById:el,querySelector:()=>el('query')},localStorage:{getItem(){return null}},languageReady:null,Map,JSON,AbortController,TextDecoder,
 fetch:async(url,opts)=>{calls.push(url);return opts?.method==='POST'?new Promise(r=>{resolveSetup=r}):{ok:true,json:async()=>({configured:false})}}});
 harnessContext=ctx;ctx.readerStorage=ctx.localStorage;ctx.setTimeout=setTimeout;ctx.clearTimeout=clearTimeout;vm.runInContext(fs.readFileSync(new URL('../public/ai-availability.js',import.meta.url),'utf8'),ctx);vm.runInContext(source,ctx);
 return {ctx,el,calls,resolve:(r)=>resolveSetup(r)};
}
test('Done stays disabled while connecting; success immediately updates readiness',async()=>{
 const h=harness();await new Promise(r=>setImmediate(r));h.el('geminiKey').value='AQ.'+'x'.repeat(60);
 const pending=h.el('languageForm').handlers.submit({preventDefault(){}});
 assert.equal(h.el('settingsClose').disabled,true);assert.equal(h.el('connectLanguage').disabled,true);
 h.resolve({ok:true,json:async()=>({configured:true})});await pending;
 assert.equal(h.ctx.languageReady,true);assert.equal(h.el('geminiKey').value,'');assert.equal(h.el('languageForm').hidden,true);assert.equal(h.el('settingsClose').disabled,false);
 assert.match(h.el('languageConnection').textContent,/Connected successfully/);
});
test('failed test shows actionable error beside the button and never claims connected',async()=>{
 const h=harness();await new Promise(r=>setImmediate(r));h.el('geminiKey').value='AQ.'+'x'.repeat(60);
 const pending=h.el('languageForm').handlers.submit({preventDefault(){}});
 h.resolve({ok:false,json:async()=>({error:'Quota exhausted'})});await pending;
 assert.equal(h.ctx.languageReady,false);assert.equal(h.el('settingsClose').disabled,false);assert.match(h.el('languageFeedback').textContent,/Quota exhausted/);
 assert.equal(h.el('languageFeedback').focused,true);assert.equal(h.el('languageFeedback').scrolled,true);
});

test('client displays streamed nikud before receiving the complete result',async()=>{
 const h=harness();let controller,resolveNikud;const early=new Promise(r=>resolveNikud=r);const encoder=new TextEncoder();
 const body=new ReadableStream({start(c){controller=c}});
 const result={hint:'example'};
 const pending=h.ctx.readAssistanceResponse(new Response(body,{headers:{'Content-Type':'application/x-ndjson'}}),tokens=>resolveNikud(tokens));
 controller.enqueue(encoder.encode(JSON.stringify({type:'nikud',tokens:[{original:'עם',nikud:'עִם'}]})+'\n'));
 assert.equal((await early)[0].nikud,'עִם');
 controller.enqueue(encoder.encode(JSON.stringify({type:'result',result})+'\n'));controller.close();
 assert.equal((await pending).hint,'example');
});
test('truncated stream never counts as a completed language result',async()=>{
 const h=harness();const response=new Response(JSON.stringify({type:'status'})+'\n',{headers:{'Content-Type':'application/x-ndjson'}});
 await assert.rejects(()=>h.ctx.readAssistanceResponse(response,()=>{}),/ended early/);
});

test('prepared word tap uses local nikud and meaning without an API call',async()=>{
 const h=harness();await new Promise(r=>setImmediate(r));
 const row=[['ההתייעצויות','הַהִתְיַעֲצוּיוֹת','','','']];
 Object.assign(h.ctx,{assistEpoch:0,assistController:null,active:'0-0',selectionIds:[],rows:[row],settings:{prepareAhead:true},languageReady:true,importedMode:true,getData:()=>row[0],render(){},preparedTranslation:()=> 'the consultations',preparedSelection:async()=>[{original:row[0][0],nikud:row[0][1]}]});
 await h.ctx.requestAssistance();
 assert.equal(h.el('selectedWord').textContent,'הַהִתְיַעֲצוּיוֹת');assert.equal(h.calls.filter(url=>url==='/api/assist').length,0);
 assert.match(h.el('assistStatus').textContent,/Nikud ready/);assert.equal(h.el('translation').textContent,'the consultations');
});

test('repeated pending contextual requests share a call, cache completion, and ignore stale selections',async()=>{
 const h=harness();await new Promise(r=>setImmediate(r));
 const row=[['שלום','שָׁלוֹם','','',''],['עולם','עוֹלָם','','','']];let calls=0,finish;
 const result={confident:true,tokens:[{original:'שלום',nikud:'שָׁלוֹם'}],hint:'ברכה',translation:'hello',lemma:'שָׁלוֹם',lemmaTranslation:'hello',pronunciation:'shalom'};
 Object.assign(h.ctx,{assistEpoch:0,assistController:null,active:'0-0',selectionIds:[],rows:[row],settings:{prepareAhead:false},languageReady:true,importedMode:true,getData:id=>row[Number(id.split('-')[1])],render(){},applySettings(){},fetch:async()=>{calls++;return new Promise(r=>finish=()=>r(new Response(JSON.stringify(result),{headers:{'Content-Type':'application/json'}})))}});
 const first=h.ctx.requestAssistance(true),second=h.ctx.requestAssistance(true);await new Promise(r=>setImmediate(r));assert.equal(calls,1);
 h.ctx.cancelAssistance();h.ctx.active='0-1';h.el('selectedWord').textContent='עולם';finish();await Promise.all([first,second]);
 assert.equal(h.el('selectedWord').textContent,'עולם');
 h.ctx.active='0-0';await h.ctx.requestAssistance(true);assert.equal(calls,1);assert.equal(h.el('translation').textContent,'hello');
});

test('translation click joins pending paragraph preparation and never assembles phrase glosses',async()=>{
 const h=harness();await new Promise(r=>setImmediate(r));let finish,ready=false;
 const row=[['שלום','שָׁלוֹם','','','']];const job={queued:true,running:true,finished:false,promise:new Promise(r=>finish=r)};
 Object.assign(h.ctx,{assistEpoch:0,assistController:null,active:'0-0',selectionIds:[],rows:[row],settings:{prepareAhead:true},languageReady:true,importedMode:true,getData:()=>row[0],render(){},preparationById:new Map([['0-0',job]]),preparedTranslation:ids=>ids.length===1&&ready?'hello':null});
 h.el('translation').hidden=true;h.el('contextTranslation').hidden=true;
 const pending=h.ctx.requestAssistance(true,'translation');ready=true;finish();await pending;
 assert.equal(h.calls.filter(url=>url==='/api/assist').length,0);assert.equal(h.el('translation').textContent,'hello');assert.equal(h.el('translation').hidden,true);
});

test('using a prepared translation keeps Hebrew hint assistance available',async()=>{
 const h=harness();await new Promise(r=>setImmediate(r));const row=[['שלום','שָׁלוֹם','','','']];
 Object.assign(h.ctx,{assistEpoch:0,assistController:null,active:'0-0',selectionIds:[],rows:[row],settings:{prepareAhead:true},languageReady:true,importedMode:true,getData:()=>row[0],render(){},preparedTranslation:()=> 'hello'});
 await h.ctx.requestAssistance(true,'translation');assert.equal(vm.runInContext('assistDetailsNeeded',h.ctx),true);
});

test('successful phrase word analysis is reused for an individual word in the same complete sentence',async()=>{
 const h=harness();await new Promise(r=>setImmediate(r));let calls=0;
 const row=[['תפקידיהם','תפקידיהם','','',''],['חשובים','חשובים','','','']];const context='תפקידיהם חשובים';
 const result={confident:true,tokens:[{original:'תפקידיהם',nikud:'תַּפְקִידֵיהֶם'},{original:'חשובים',nikud:'חֲשׁוּבִים'}],hint:'העבודות שלהם חשובות',translation:'their roles are important',lemma:'',lemmaTranslation:'',pronunciation:'',words:[{original:'תפקידיהם',nikud:'תַּפְקִידֵיהֶם',translation:'their roles',lemma:'תַּפְקִיד',lemmaTranslation:'role',confident:true}]};
 Object.assign(h.ctx,{assistEpoch:0,assistController:null,active:'0-0',selectionIds:[],rows:[row],settings:{prepareAhead:true},languageReady:true,importedMode:true,getData:id=>row[Number(id.split('-')[1])],render(){},applySettings(){},fetch:async()=>{calls++;return new Response(JSON.stringify(result),{headers:{'Content-Type':'application/json'}});}});
 await h.ctx.getAssistanceResult({tokens:['תפקידיהם','חשובים'],context});await h.ctx.requestAssistance();
 assert.equal(calls,1);assert.equal(h.el('translation').textContent,'their roles');assert.equal(h.el('selectedWord').textContent,'תַּפְקִידֵיהֶם'.normalize('NFC'));
});
test('a malformed optional Hebrew lemma is withheld while valid main help is displayed and cached',async()=>{
 const h=harness();await new Promise(r=>setImmediate(r));const row=[['תפקיד','תַּפְקִיד','','','']];
 Object.assign(h.ctx,{assistEpoch:0,assistController:null,active:'0-0',selectionIds:[],rows:[row],settings:{prepareAhead:false},languageReady:true,importedMode:true,getData:()=>row[0],render(){},applySettings(){},fetch:async()=>new Response(JSON.stringify({confident:true,tokens:[{original:'תפקיד',nikud:'תַּפְקִיד'}],hint:'משרה או עבודה',translation:'role',lemma:'תַּפְקِיד',lemmaTranslation:'role',pronunciation:'tafkid'}),{headers:{'Content-Type':'application/json'}})});
 await h.ctx.requestAssistance(true);assert.equal(h.el('selectedWord').textContent,'תַּפְקִיד');assert.equal(row[0][1],'תַּפְקִיד');assert.match(h.el('assistStatus').textContent,/reusable form is not available/);assert.equal(vm.runInContext('assistCache.size',h.ctx),1);assert.equal(vm.runInContext('[...assistCache.values()][0].lemma',h.ctx),'');assert.equal(h.el('lexicalForm').textContent,'');
});
