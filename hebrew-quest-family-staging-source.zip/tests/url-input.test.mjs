import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
test('URL pointer/focus clears immediately, empty blur restores, and replacement is retained',()=>{
 const html=fs.readFileSync(new URL('../lib/reader.html',import.meta.url),'utf8');const source=html.slice(html.indexOf('const articleUrlInput='),html.indexOf("document.getElementById('importUrl').addEventListener"));
 const events={};const field={value:'https://www.ynet.co.il/old',addEventListener:(name,fn)=>events[name]=fn};
 vm.runInNewContext(source,{document:{getElementById:()=>field}});
 events.pointerdown();events.focus();assert.equal(field.value,'');events.blur();assert.equal(field.value,'https://www.ynet.co.il/old');
 events.focus();field.value='https://www.ynet.co.il/new';events.blur();assert.equal(field.value,'https://www.ynet.co.il/new');
 events.pointerdown();assert.equal(field.value,'');events.blur();assert.equal(field.value,'https://www.ynet.co.il/new');
});
