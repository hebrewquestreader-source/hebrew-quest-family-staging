import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';import {HebrewText} from '../lib/hebrew-text.js';
class Node{
 constructor(tag='div'){this.tag=tag;this.children=[];this.dataset={};this.handlers={};this.attributes={};this._text='';this.className='';this.hidden=false;this.value='';this.checked=false;this.style={setProperty(k,v){this[k]=v}};this.classList={add:(...a)=>{this.className=[...new Set([...this.className.split(' '),...a])].join(' ')},remove:(...a)=>{this.className=this.className.split(' ').filter(x=>!a.includes(x)).join(' ')},toggle:(a,b)=>{if(b??!this.className.split(' ').includes(a))this.classList.add(a);else this.classList.remove(a)}};}
 set textContent(v){this._text=String(v);this.children=[];}get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}set innerHTML(v){this.replaceChildren();}
 append(...nodes){for(const n of nodes){n.parent=this;this.children.push(n)}}replaceChildren(...nodes){this._text='';this.children=[];this.append(...nodes)}
 setAttribute(k,v){this.attributes[k]=v}addEventListener(k,fn){(this.handlers[k]??=[]).push(fn)}closest(s){if(s==='.word'&&this.className.split(' ').includes('word'))return this;if(s==='.reading .word'&&this.className.split(' ').includes('word'))return this;for(let n=this;n;n=n.parent)if(s==='[data-reading-row]'&&n.dataset.readingRow!==undefined)return n;return null;}
 querySelectorAll(s){const out=[];function visit(n){for(const c of n.children){if((s.startsWith('.')&&c.className.split(' ').includes(s.slice(1)))||(s==='[data-reading-row]'&&c.dataset.readingRow!==undefined)||(s==='p'&&c.tag==='p')||(s.startsWith('[data-id=')&&c.dataset.id===s.match(/"([^"]+)"/)[1]))out.push(c);visit(c)}}visit(this);return out;}querySelector(s){return this.querySelectorAll(s)[0]||null;}showModal(){this.open=true;}close(){this.open=false;}
}
function harness(){
 const elements=new Map(),el=id=>{if(!elements.has(id))elements.set(id,new Node());return elements.get(id)};const reading=new Node(),side=new Node(),body=new Node();reading.className='reading';side.className='side';reading.append(el('importTitle'),el('article'));body.append(reading,side);const docEvents={};let hit=null;const timers=new Map();let timer=0;const requests=[];
 const document={body,getElementById:el,querySelector:s=>s==='.reading'?reading:s==='.side'?side:el(s),createElement:tag=>new Node(tag),createTextNode:text=>{const n=new Node('text');n.textContent=text;return n},addEventListener:(k,fn)=>(docEvents[k]??=[]).push(fn),elementFromPoint:()=>hit};
 const pointed={'תפקיד':'תַּפְקִיד','חשוב':'חָשׁוּב','היום':'הַיּוֹם'};
 const c=vm.createContext({HebrewText,document,Map,Set,JSON,Date,Intl,structuredClone,AbortController,TextDecoder,Blob,URL,window:{innerHeight:800,addEventListener(){}},localStorage:{getItem(){return null},setItem(){}},setTimeout:fn=>{timers.set(++timer,fn);return timer},clearTimeout:id=>timers.delete(id),fetch:async(url,opts)=>{if(url==='/api/language/setup')return {ok:true,json:async()=>({configured:true})};if(url==='/api/reports'){requests.push({report:JSON.parse(opts.body)});return {ok:true,json:async()=>({ok:true})};}if(url==='/api/assist'){const input=JSON.parse(opts.body);requests.push(input);const result={confident:true,tokens:input.tokens.map(original=>({original,nikud:pointed[original]||original})),hint:'עבודה או משרה',translation:input.tokens.join(' ')==='תפקיד חשוב'?'an important role':input.tokens[0]==='חשוב'?'important':'role',lemma:input.tokens.join(' ')==='תפקיד חשוב'?'תַּפְקִיד חָשׁוּב':input.tokens[0]==='חשוב'?'חָשׁוּב':'תַּפְקִיד',lemmaTranslation:'role',pronunciation:'tafkid'};return {ok:true,headers:{get(){return 'application/json'}},json:async()=>result};}throw new Error('Unexpected request '+url);}});
 const html=fs.readFileSync(new URL('../lib/reader.html',import.meta.url),'utf8');for(const m of html.matchAll(/<script>([\s\S]*?)<\/script>/g))vm.runInContext(m[1],c);
 for(const file of ['ai-availability.js','expression-validator.js','expressions.js','language-client.js','vocabulary-client.js'])vm.runInContext(fs.readFileSync(new URL('../public/'+file,import.meta.url),'utf8'),c);
 return {c,el,reading,document,docEvents,timers,requests,setHit:n=>hit=n};
}
const settle=()=>new Promise(setImmediate);
test('headline word taps reveal inline nikud, tap again and close clear it, and another selection clears the previous word',async()=>{
 const h=harness();await settle();vm.runInContext('settings.prepareAhead=false;loadArticleText("תפקיד חשוב היום",["זהו תפקיד חשוב."],"https://www.ynet.co.il/news/article/example")',h.c);
 let words=h.el('importTitle').querySelectorAll('.word');assert.equal(words.length,3);assert.equal(words[0].attributes.role,'button');
 words[0].handlers.click[0]();await settle();assert.equal(words[0].textContent,'תַּפְקִיד'.normalize('NFC'));assert.equal(h.requests[0].context,'תפקיד חשוב היום');
 words[0].handlers.click[0]();assert.equal(words[0].textContent,'תפקיד');
 words[0].handlers.click[0]();await settle();words[1].handlers.click[0]();await settle();assert.equal(words[0].textContent,'תפקיד');assert.equal(words[1].textContent,'חָשׁוּב'.normalize('NFC'));
 h.el('closePanel').handlers.click[0]();assert.equal(words[1].textContent,'חשוב');
});
test('mobile touch start/hold/drag/end handlers select a headline phrase, save its exact snapshot and report it',async()=>{
 const h=harness();await settle();vm.runInContext('settings.prepareAhead=false;loadArticleText("תפקיד חשוב היום",["זהו תפקיד חשוב."],"https://www.ynet.co.il/news/article/example")',h.c);const words=h.el('importTitle').querySelectorAll('.word');
 h.docEvents.touchstart[0]({touches:[{clientX:100,clientY:100}],target:words[0]});[...h.timers.values()].at(-1)();h.setHit(words[1]);h.docEvents.touchmove[0]({touches:[{clientX:30,clientY:100}],cancelable:true,preventDefault(){}});h.docEvents.touchend[0]({});await settle();
 assert.equal(h.el('selectedWord').textContent,'תַּפְקִיד חָשׁוּב'.normalize('NFC'));const saved=h.c.vocabularySnapshot();assert.equal(saved.expression,'תפקיד חשוב');assert.equal(saved.title,'תפקיד חשוב היום');assert.equal(saved.sentence,'תפקיד חשוב היום');assert.equal(saved.url,'https://www.ynet.co.il/news/article/example');
 h.el('reportResult').handlers.click[0]();h.el('reportKind').value='nikud';h.el('reportNote').value='Test report';await h.el('sendReport').handlers.click[0]();assert.equal(h.requests.find(x=>x.report).report.selected,'תפקיד חשוב');
});
test('complete sentence context is not clipped to a 50-word window',async()=>{
 const h=harness();await settle();const sentence=Array(80).fill('מילה').join(' ')+' תפקיד חשוב.';h.c.longSentence=sentence;vm.runInContext('settings.prepareAhead=false;loadArticleText("כותרת",[longSentence+" משפט אחר."],null);active="1-80"',h.c);const request=h.c.selectionRequest();assert.equal(request.input.context,sentence);assert.deepEqual(Array.from(request.input.tokens),['תפקיד']);
});
