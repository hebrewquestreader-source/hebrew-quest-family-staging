import test from 'node:test';
import assert from 'node:assert/strict';
import {harness,settle} from './helpers/interactive-harness.mjs';

const rows=[
 ['הזכירו','לְהַזְכִּיר','to mention','verb',['לזכור','זיכרון','תזכורת','מזכרת']],
 ['כתבו','לִכְתּוֹב','to write','verb',['כתיבה','מכתב','כתבה','התכתבות']],
 ['טלפון','טֵלֵפוֹן','telephone','noun',null],
 ['טרור','טֶרוֹר','terrorism','noun',null]
];
const analysis=([selected,lemma,lemmaMeaning,category])=>({selected,lemma,lemmaMeaning,category,lemmaConfident:true,confident:true,features:[],parts:[]});
const calm=async()=>{for(let i=0;i<7;i++)await settle();};

test('all four entries have checked headwords, supported senses and valid pointed family forms',()=>{
 const h=harness();
 for(const row of rows){
  const result=h.c.WordBreakdown.checked(analysis(row),{tokens:[row[0]]});
  const entry=h.c.WordCatalogue.match(result);
  assert.ok(entry,row[0]);
  if(row[4]){
   assert.deepEqual(Array.from(entry.family,x=>x[0]),row[4]);
   for(const [plain,,pointed] of entry.family)assert.ok(h.c.HebrewText.validNikud(plain,pointed),plain);
  }else assert.ok(entry.origin);
  for(const [,url] of entry.sources)assert.equal(new URL(url).protocol,'https:');
 }
 assert.equal(h.c.WordCatalogue.version,2);
});

test('a wrong sense, uncertain lemma, root-only result or missing entry renders no catalogue match',()=>{
 const {c}=harness(), result=analysis(rows[0]);
 for(const change of [{lemmaMeaning:'a secretary'},{lemma:'',root:'זכר'},{lemmaConfident:false},{confident:false},{category:'noun'},{lemma:'לְסַפֵּר'}]){
  assert.equal(c.WordCatalogue.match({...result,...change}),undefined);
 }
});

for(const row of [rows[0],rows[2],['ספר','סֵפֶר','book','noun',null]])test('optional catalogue UI preserves Word Help for '+row[0],async()=>{
 let requests=0;
 const h=harness({fetcher:async(url,options,fallback)=>{
  if(url==='/api/assist'){requests++;return Response.json({confident:true,tokens:[{original:row[0],nikud:row[0]==='הזכירו'?'הִזְכִּירוּ':row[1]}],translation:row[2],lemma:'',lemmaTranslation:'',hint:'',pronunciation:'',analysis:analysis(row)});}
  if(url==='/api/breakdown'){requests++;throw Error('Expected cached analysis');}
  return fallback(url,options);
 }});
 await calm();
 h.c.fixture=row[0];
 h.run('window.innerWidth=360;loadArticleText("חדשות",[fixture+" היום."],"");settings.wordBreakdown=true;applySettings()');
 await h.el('article').querySelector('.word').click();await calm();
 assert.equal(h.el('contextTranslation').hidden,true);
 await h.el('wordBreakdownButton').click();await calm();
 const sections=h.el('wordBreakdownContent').querySelectorAll('details');
 assert.equal(sections.length,row[0]==='ספר'?0:1);
 if(sections.length){
  const section=sections[0];
  assert.ok(!section.open);
  assert.equal(section.dir,'ltr');
  assert.equal(section.querySelector('summary').textContent,row[4]?'Word Family':'Word Origins');
  assert.equal(section.querySelector('bdi').dir,'rtl');
  assert.ok(section.querySelector('a'));
  if(row[4]){
   const toggle=section.querySelector('button');
   assert.equal(section.querySelector('bdi').textContent,'לזכור');
   await toggle.click();
   assert.equal(toggle.getAttribute('aria-pressed'),'true');
   assert.equal(section.querySelector('bdi').textContent,'לִזְכּוֹר');
   await toggle.click();
   assert.equal(section.querySelector('bdi').textContent,'לזכור');
  }
 }
 assert.equal(requests,1);
 assert.equal(h.el('contextTranslation').hidden,true);
});

test('marked abbreviations resolve locally; unmarked forms require the matching sense',()=>{
 const {c}=harness();
 for(const [surface,expansion] of [['נדל"ן,','נכסי דלא ניידי'],['נדל״ן','נכסי דלא ניידי'],['מנכ״ל','מנהל כללי'],['דו״ח','דין וחשבון']]){
  assert.equal(c.WordCatalogue.abbreviation([surface])?.expansion,expansion);
 }
 assert.equal(c.WordCatalogue.abbreviation(['דוח']),undefined);
 assert.equal(c.WordCatalogue.match(analysis(['דוח','דּוּחַ','push','noun'])),undefined);
 assert.equal(c.WordCatalogue.match(analysis(['דוח','דּוּחַ','report','noun'])).expansion,'דין וחשבון');
});

test('Word Breakdown opens a collapsed, sourced acronym expansion without a provider request',async()=>{
 const h=harness({fetcher:async(url,opts,fallback)=>url==='/api/assist'?Response.json({error:'Unavailable'},{status:503}):fallback(url,opts)});
 await calm();
 h.run(`loadArticleText("חדשות",['שוק נדל"ן בישראל.'],"");settings.wordBreakdown=true;applySettings()`);
 await h.el('article').querySelectorAll('.word')[1].click();await calm();
 const before=h.requests.length;
 await h.el('wordBreakdownButton').click();await calm();
 const section=h.el('wordBreakdownContent').querySelector('details');
 assert.ok(section&&!section.open);
 assert.equal(section.querySelector('summary').textContent,'Word Origins');
 assert.equal(section.querySelector('bdi').textContent,'נכסי דלא ניידי');
 assert.equal(section.querySelector('bdi').dir,'rtl');
 assert.match(section.textContent,/immovable property/);
 assert.equal(h.requests.length,before);
});
