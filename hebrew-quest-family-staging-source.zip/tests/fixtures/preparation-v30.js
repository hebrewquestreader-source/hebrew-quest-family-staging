// Prepare contextual word meanings alongside nikud in one bounded reading-window request.
const preparationCacheKey='hebrew-quest-prepared-language-v5';
let preparationCache=new Map();try{const saved=JSON.parse(readerStorage.getItem(preparationCacheKey)||'[]');if(Array.isArray(saved))preparationCache=new Map(saved.slice(-100));}catch{}
let preparationInvalid=false;
let preparationGeneration=0,preparationJobs=[],preparationById=new Map(),preparedMeanings=new Map(),preparedForms=new Map(),preparationQueue=[],preparationBusy=false,preparationPaused=false,preparationRecent=[],preparationTimer=null;
function savePreparationCache(key,value){preparationCache.delete(key);preparationCache.set(key,value);while(preparationCache.size>100)preparationCache.delete(preparationCache.keys().next().value);try{readerStorage.setItem(preparationCacheKey,JSON.stringify([...preparationCache]));}catch{}}
function preparationStatus(message){const el=document.getElementById('preparationStatus');if(el)el.textContent=message;}
function updatePreparationStatus(){if(!importedMode)return;const all=rows.flat().filter(w=>/[א-ת]/.test(w[0])),ready=all.filter(w=>/[\u05b0-\u05bc\u05c1\u05c2\u05c7]/.test(w[1])).length;preparationStatus(!settings.prepareAhead?'Nikud preparation paused.':preparationPaused?`Preparation paused at a free-tier limit. ${ready} words are ready for instant taps.`:`${ready} words ready for instant nikud · meanings prepare too${preparationBusy?' · preparing nearby text…':(preparationInvalid?' · malformed results rejected; original text retained':' · nearby paragraphs prepare as you read')}`);}
function beginPreparation(){
 for(const job of preparationQueue)job.resolve(null);preparationGeneration++;const generation=preparationGeneration;preparationJobs=[];preparationById=new Map();preparedMeanings=new Map();preparedForms=new Map();preparationQueue=[];preparationPaused=false;
 if(!importedMode||!settings.prepareAhead){updatePreparationStatus();return;}
 rows.forEach((row,i)=>{
  for(let core=0;core<row.length;core+=36){
   let left=Math.max(0,core-3),right=Math.min(row.length,core+39);const ids=[],tokens=[];
   for(let j=left;j<right;j++){if(row[j][0].length<=100){ids.push(`${i}-${j}`);tokens.push(row[j][0]);}}
   while(tokens.join(' ').length>1500){tokens.pop();ids.pop();}if(!tokens.length)continue;
   const context=sentenceForSelection(ids);const cacheKey=JSON.stringify({tokens,context});let resolve;const promise=new Promise(r=>resolve=r);const job={generation,ids,tokens,context,cacheKey,promise,resolve,queued:false,finished:false};
   preparationJobs.push(job);for(const id of ids)if(!preparationById.has(id))preparationById.set(id,job);
   const cached=preparationCache.get(cacheKey);if(cached)finishPreparation(job,cached,false);
  }
 });
 if(languageReady===true){for(const job of preparationJobs.slice(0,2))queuePreparation(job);scanReadingWindow();}
 updatePreparationStatus();
}
function finishPreparation(job,result,save=true){
 if(result.rejected>0)preparationInvalid=true;
 if((result.tokens||[]).some(item=>!HebrewText.validNikud(item.original,item.nikud)))preparationInvalid=true;
 if(job.generation===preparationGeneration){
  if(typeof ExpressionUI!=='undefined')ExpressionUI.enhance(job,result);
  for(const item of result.tokens||[]){if(!Number.isInteger(item.index)||!job.ids[item.index]||item.original!==job.tokens[item.index]||typeof item.nikud!=='string'||!HebrewText.validNikud(item.original,item.nikud))continue;const [i,j]=job.ids[item.index].split('-').map(Number);const data=getData(job.ids[item.index]);if(data?.[0]===item.original){data[1]=item.nikud;if(typeof item.translation==='string'&&item.translation.length<=180&&/[A-Za-z]/.test(item.translation))preparedMeanings.set(job.ids[item.index],item.translation);if(item.lemmaChecked===true){try{const checked=HebrewText.result({confident:true,partial:true,tokens:[{original:item.original,nikud:item.nikud}],hint:'',translation:item.translation||'',pronunciation:'',lemma:item.lemma||'',lemmaTranslation:item.lemmaTranslation||'',lemmaKind:item.lemmaKind},{tokens:[item.original],context:job.context});preparedForms.set(job.ids[item.index],checked);}catch{preparationInvalid=true;}}}}
 }
 job.finished=true;job.resolve(result);if(save)savePreparationCache(job.cacheKey,result);updatePreparationStatus();
}
function queuePreparation(job,urgent=false){if(!job||job.finished||job.generation!==preparationGeneration)return;if(!job.queued){job.queued=true;if(urgent)preparationQueue.unshift(job);else preparationQueue.push(job);}else if(urgent){preparationQueue=preparationQueue.filter(j=>j!==job);preparationQueue.unshift(job);}pumpPreparation();}
async function pumpPreparation(){
 if(preparationBusy||preparationPaused||!settings.prepareAhead||languageReady!==true)return;
 preparationRecent=preparationRecent.filter(t=>Date.now()-t<60000);
 if(preparationRecent.length>=3){clearTimeout(preparationTimer);preparationTimer=setTimeout(pumpPreparation,Math.max(1000,60050-(Date.now()-preparationRecent[0])));updatePreparationStatus();return;}
 const job=preparationQueue.shift();if(!job)return;if(job.finished||job.generation!==preparationGeneration){pumpPreparation();return;}
 preparationBusy=true;preparationRecent.push(Date.now());updatePreparationStatus();
 try{const response=await fetch('/api/prepare',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tokens:job.tokens,context:job.context,...(job.helpScope?{helpScope:job.helpScope}:{})})});const result=await response.json();
  if(!response.ok){if(result.code==='invalid_result'||result.code==='invalid_hebrew')preparationInvalid=true;if(result.code==='quota'||result.code==='local_quota')preparationPaused=true;throw new Error(result.error||'Preparation unavailable.');}
  finishPreparation(job,result);
 }catch{job.finished=true;job.resolve(null);if(preparationPaused){for(const waiting of preparationQueue){waiting.finished=true;waiting.resolve(null);}preparationQueue=[];}}
 finally{preparationBusy=false;updatePreparationStatus();pumpPreparation();}
}
async function preparedSelection(ids){
 const ready=()=>ids.every(id=>HebrewText.validNikud(getData(id)[0],getData(id)[1]));
 if(ready())return ids.map(id=>({original:getData(id)[0],nikud:getData(id)[1]}));
 const jobs=[...new Set(ids.map(id=>preparationById.get(id)).filter(Boolean))];if(!jobs.length||preparationPaused)return null;
 // Keep a direct tap from waiting behind a background rate-limit timer.
 if(preparationRecent.filter(t=>Date.now()-t<60000).length>=3&&!preparationBusy)return null;
 for(const job of jobs)queuePreparation(job,true);await Promise.all(jobs.map(job=>job.promise));
 return ready()?ids.map(id=>({original:getData(id)[0],nikud:getData(id)[1]})):null;
}
function scanReadingWindow(){
 if(!importedMode||!settings.prepareAhead||languageReady!==true)return;
 const height=window.innerHeight;for(const p of readingSurface.querySelectorAll('[data-reading-row]')){const box=p.getBoundingClientRect();if(box.bottom<0||box.top>height+400)continue;
  for(const word of p.querySelectorAll('.word')){const b=word.getBoundingClientRect();if(b.bottom>=0&&b.top<=height+400)queuePreparation(preparationById.get(word.dataset.id));}
 }
}
let scanTimer;window.addEventListener('scroll',()=>{clearTimeout(scanTimer);scanTimer=setTimeout(scanReadingWindow,120);},{passive:true});

function resumePreparation(){if(typeof HebrewInteractions!=='undefined')HebrewInteractions.refreshPreparation();if(!importedMode||!settings.prepareAhead)return;if(!preparationJobs.length){beginPreparation();return;}for(const job of preparationJobs.slice(0,2))queuePreparation(job);scanReadingWindow();}
if(importedMode&&languageReady===true)beginPreparation();

function preparedTranslation(ids){return ids.length===1?preparedMeanings.get(ids[0])||null:null;}

function registerExternalPreparation(block){
 if(!settings.prepareAhead||languageReady!==true||!block.row.length||!block.element.isConnected)return;
 for(let start=0;start<block.row.length;start+=36){const ids=[],tokens=[];for(let j=start;j<Math.min(block.row.length,start+36);j++){if(block.row[j][0].length>100)return;ids.push(`${block.index}-${j}`);tokens.push(block.row[j][0]);}if(!tokens.some(t=>/[א-ת]/.test(t))||tokens.join(' ').length>1500)continue;
  const existing=preparationById.get(ids[0]);if(existing?.generation===preparationGeneration){if(block.nodes.some(n=>n.getClientRects().length))queuePreparation(existing);continue;}const metadata=externalSelection(ids);if(!metadata||metadata.context.length>16000)continue;let resolve;const promise=new Promise(r=>resolve=r),context=metadata.context,cacheKey=JSON.stringify({tokens,context,helpScope:metadata.protected?'exercise_language':''});const job={generation:preparationGeneration,ids,tokens,context,cacheKey,promise,resolve,queued:false,finished:false,helpScope:metadata.protected?'exercise_language':undefined};for(const id of ids)preparationById.set(id,job);preparationJobs.push(job);const cached=preparationCache.get(cacheKey);if(cached)finishPreparation(job,cached,false);else if(block.nodes.some(n=>{const r=n.getBoundingClientRect();return r.bottom>=0&&r.top<=window.innerHeight+400&&n.getClientRects().length;}))queuePreparation(job);
 }
}

function preparedReusable(ids){return ids.length===1?preparedForms.get(ids[0])||null:null;}
