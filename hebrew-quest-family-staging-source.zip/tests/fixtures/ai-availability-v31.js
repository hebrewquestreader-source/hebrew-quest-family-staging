// Account-scoped availability and in-flight coordination. No AI result is shared
// across users, and failed responses are never put in a successful-result cache.
globalThis.AIAvailability=(()=>{
 const key='hebrew-quest-ai-availability-v1',pending=new Map(),failures=new Map(),counts={},listeners=new Set();let hold=null,timer=null;
 try{const saved=JSON.parse(readerStorage.getItem(key)||'null');if(saved&&['quota','local_quota'].includes(saved.code)&&(!saved.retryAt||Number.isFinite(saved.retryAt)&&saved.retryAt>Date.now()))hold=saved;}catch{}
 const notice=document.getElementById('aiUnavailableNotice'),retry=document.getElementById('retryNewHelp');
 function persist(){try{if(hold)readerStorage.setItem(key,JSON.stringify(hold));else readerStorage.removeItem(key);}catch{}}
 function paused(){return !!hold&&(!hold.retryAt||Date.now()<hold.retryAt);}
 function quotaError(){return Object.assign(Error('New language help is temporarily unavailable. Previously saved help still works.'),{code:hold?.code||'local_quota',quota:hold?.quota,retryAt:hold?.retryAt,availabilityPaused:true});}
 function render(){if(notice){notice.hidden=!hold;const text=document.getElementById('aiUnavailableText');const message='New AI help paused. Saved help still works.';if(text&&text.textContent!==message)text.textContent=message;}if(retry)retry.disabled=!!hold?.retryAt&&Date.now()<hold.retryAt;clearTimeout(timer);if(hold?.retryAt&&hold.retryAt>Date.now())timer=setTimeout(render,Math.min(2147483647,hold.retryAt-Date.now()+30));}
 function observe(error){if(!['quota','local_quota'].includes(error?.code))return false;const next={code:error.code,...(Number.isFinite(error.retryAt)&&error.retryAt>Date.now()?{retryAt:error.retryAt}:{}),...(error.quota?{quota:error.quota}:{})};if(hold?.retryAt&&hold.retryAt>(next.retryAt||0))next.retryAt=hold.retryAt;hold=next;persist();render();for(const fn of listeners)fn(hold);return true;}
 function retryNow(){if(paused()&&hold.retryAt)return false;hold=null;failures.clear();persist();render();for(const fn of listeners)fn(null);return true;}
 async function run(service,input,work,{manual=false}={}){const k=JSON.stringify([service,input]);if(pending.has(k))return pending.get(k);if(manual){failures.delete(k);if(hold&&!hold.retryAt)retryNow();}if(paused())throw quotaError();if(hold){hold=null;persist();render();for(const fn of listeners)fn(null);}const failed=failures.get(k);if(failed&&Date.now()<failed.until&&!manual)throw failed.error;
  const job=(async()=>{counts[service]=(counts[service]||0)+1;try{return await work();}catch(error){if(!observe(error)){failures.set(k,{error,until:Date.now()+30000});while(failures.size>100)failures.delete(failures.keys().next().value);}throw error;}})();pending.set(k,job);job.finally(()=>{if(pending.get(k)===job)pending.delete(k);}).catch(()=>{});return job;}
 function fromUsage(usage){if(!Array.isArray(usage))return;const exhausted=usage.find(x=>x.window==='day'&&x.used>=x.limit)||usage.find(x=>x.used>=x.limit);if(exhausted)observe({code:'local_quota',retryAt:exhausted.resetAt,quota:{source:'application',...exhausted}});}
 retry?.addEventListener('click',()=>{if(!retryNow())return;if(typeof resumePreparation==='function')resumePreparation();if(active&&typeof requestAssistance==='function')requestAssistance(true);});render();
 return {run,observe,paused,retry:retryNow,fromUsage,subscribe:fn=>listeners.add(fn),snapshot:()=>({hold:hold?{...hold}:null,requests:{...counts},pending:pending.size})};
})();
