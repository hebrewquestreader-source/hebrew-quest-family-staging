import {HebrewText} from '../lib/hebrew-text.js';
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import vm from 'node:vm';
import {standardPointedSpelling} from '../lib/orthography.ts';
import {validateNikud} from '../lib/language.ts';
import {validatePreparation,prepareNikud} from '../lib/preparation.ts';
test('full spelling accepts standard pointed spelling without permitting other word changes',()=>{
 assert.equal(standardPointedSpelling('ההתייעצויות','הַהִתְיַעֲצוּיוֹת'),true);
 assert.equal(standardPointedSpelling('מילה,','מִלָּה,'),true);
 assert.equal(standardPointedSpelling('בית','בַּת'),false);
 assert.equal(standardPointedSpelling('ההתייעצויות','הַהִתְיַעֲצוּת'),false);
 assert.equal(standardPointedSpelling('מילה,','מִלָּה'),false);
 const input={tokens:['ההתייעצויות'],context:'כבר היום החלו ההתייעצויות.'};
 assert.deepEqual(validateNikud([{original:'ההתייעצויות',nikud:'הַהִתְיַעֲצוּיוֹת'}],input),[{original:'ההתייעצויות',nikud:'הַהִתְיַעֲצוּיוֹת'}]);
});
test('preparation is bounded and one doubtful word does not reject good neighbours',async()=>{
 assert.throws(()=>validatePreparation({tokens:Array(61).fill('שלום')}));
 let calls=0;const result=await prepareNikud(['ההתייעצויות','בית','שלום'],'synthetic',async()=>{calls++;return new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify({tokens:[{index:0,nikud:'הַהִתְיַעֲצוּיוֹת',confident:true,translation:'the consultations'},{index:1,nikud:'בַּת',confident:true},{index:2,nikud:'שָׁלוֹם',confident:true}]})}]}}]}));});
 assert.deepEqual(result.tokens.map(t=>t.index),[0,2]);assert.equal(calls,1);assert.equal(result.tokens[0].translation,'the consultations');
});
test('למרות זאת and its conjunction form are treated as complete expressions',()=>{
 const ctx=vm.createContext({HebrewText});vm.runInContext(fs.readFileSync(new URL('../public/expression-validator.js',import.meta.url),'utf8'),ctx);vm.runInContext('function knownExpressionResult(tokens){return ExpressionText.known(tokens)}',ctx);
 const result=ctx.knownExpressionResult(['ולמרות','זאת,']);
 assert.equal(result.lemma,'לַמְרוֹת זֹאת');assert.equal(result.translation,'and nevertheless / and despite that');assert.equal(result.tokens[1].nikud,'זֹאת,');
 assert.equal(ctx.knownExpressionResult(['למרות,','זאת']),null);
});
test('a prepared word is returned locally without an API call',async()=>{
 let calls=0;const row=[['שלום','שָׁלוֹם']];
 const ctx=vm.createContext({HebrewText,Map,Set,JSON,Date,Promise,setTimeout,clearTimeout,importedMode:false,languageReady:true,settings:{prepareAhead:true},rows:[row],getData:id=>row[Number(id.split('-')[1])],document:{addEventListener(){},getElementById(){return {textContent:''}}},window:{addEventListener(){},innerHeight:800},article:{querySelectorAll(){return []}},localStorage:{getItem(){return null}},fetch(){calls++;throw new Error('Must not be called')}});
 ctx.readerStorage=ctx.localStorage;vm.runInContext(fs.readFileSync(new URL('../public/preparation-client.js',import.meta.url),'utf8'),ctx);
 const tokens=await ctx.preparedSelection(['0-0']);assert.equal(tokens[0].nikud,'שָׁלוֹם');assert.equal(calls,0);
});

test('prepared meanings are scoped to their paragraph and never joined into phrase translations',()=>{
 const ctx=vm.createContext({HebrewText,Map,Set,JSON,Date,Promise,setTimeout,clearTimeout,importedMode:false,languageReady:true,settings:{prepareAhead:true},rows:[[['שלום','שלום']]],document:{addEventListener(){},getElementById(){return {textContent:''}}},window:{addEventListener(){},innerHeight:800},localStorage:{getItem(){return null}}});
 ctx.readerStorage=ctx.localStorage;vm.runInContext(fs.readFileSync(new URL('../public/preparation-client.js',import.meta.url),'utf8'),ctx);
 vm.runInContext("preparedMeanings.set('0-0','peace');preparedMeanings.set('1-0','hello')",ctx);
 assert.equal(ctx.preparedTranslation(['0-0']),'peace');assert.equal(ctx.preparedTranslation(['1-0']),'hello');assert.equal(ctx.preparedTranslation(['0-0','1-0']),null);
});
