import test from 'node:test';
import assert from 'node:assert/strict';
import { generateAssistance } from '../lib/language.ts';

const input = {tokens:['בטרור'],context:'המדינה נאבקת בטרור.'};
const validMeaning = 'against terrorism';
const runtime = {trace(){}};

function streamed(parts) {
  const lines = parts.map((text,index)=>'data: '+JSON.stringify({
    candidates:[{content:{parts:[{text}]},...(index===parts.length-1?{finishReason:'STOP'}:{})}]
  }));
  return new Response(lines.join('\n')+'\n');
}

test('streamed bad vowel marks do not prevent reading a later contextual translation', async()=>{
  let calls=0, early=0;
  const result=await generateAssistance(input,'synthetic',async()=>{
    calls++;
    return streamed(['{"confident":true,"tokens":[{"original":"בטרור","nikud":"בِטרור"}],',
      '"translation":"against terrorism","hint":"פעילות אלימה להפחדת הציבור","lemma":42,"lemmaTranslation":null}']);
  },()=>early++,undefined,runtime);
  assert.equal(calls,1);
  assert.equal(early,0);
  assert.equal(result.translation,validMeaning);
  assert.equal(result.tokens[0].nikud,'בטרור');
  assert.ok(result.withheldFields.includes('nikud'));
  assert.equal(result.lemma,'');
});

test('runtime provider failure makes one attempt and preserves its error category',async()=>{
  let calls=0;
  await assert.rejects(generateAssistance(input,'synthetic',async()=>{
    calls++;
    return new Response('',{status:503});
  },undefined,undefined,runtime),{code:'provider_unavailable'});
  assert.equal(calls,1);
});

test('verified בטרור example keeps ב־ as a prefix and rejects an invented verbal root',async()=>{
  const { WordBreakdown }=await import('../lib/word-breakdown.js');
  const breakdown={
    selected:'בטרור',confident:true,category:'noun',lemma:'טֵרוֹר',lemmaMeaning:'terrorism',
    lemmaConfident:true,root:'',rootConfident:false,features:[],
    parts:[
      {text:'ב',kind:'prefix',meaning:'against, with the verb fight',confident:true},
      {text:'טרור',kind:'stem',meaning:'terrorism',confident:true}
    ]
  };
  const checked=WordBreakdown.checked(breakdown,input);
  assert.equal(checked.lemma,'טֵרוֹר');
  assert.equal(checked.parts[0].kind,'prefix');
  assert.equal(checked.root,'');
  assert.throws(()=>WordBreakdown.checked({...breakdown,root:'ט־ר־ר',rootConfident:true},input),{field:'root'});
});

const envelope = value => Response.json({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(value)}]}}]});

test('להקמת keeps core meaning and the construct analysis when the noun root is rejected',async()=>{
  const {generateBreakdown}=await import('../lib/breakdown.ts');
  const request={tokens:['להקמת'],context:'הוקצה תקציב להקמת בית ספר.'};
  const base={confident:true,tokens:[{original:'להקמת',nikud:'לַהֲקָמַת'}],translation:'for the establishment of',hint:'כדי ליצור משהו חדש',lemma:'הֲקָמָה',lemmaTranslation:'establishment',lemmaConfident:true};
  const grammar={selected:'להקמת',confident:true,category:'noun',lemma:base.lemma,lemmaMeaning:base.lemmaTranslation,lemmaConfident:true,root:'ק־و־ם',rootConfident:true,features:[{name:'state',value:'construct',confident:true}]};
  const core=await generateAssistance(request,'synthetic',async()=>streamed([JSON.stringify({...base,analysis:grammar})]),()=>{},undefined,runtime);
  assert.equal(core.translation,'for the establishment of');
  assert.equal(core.tokens[0].nikud,base.tokens[0].nikud.normalize('NFC'));
  assert.equal(core.lemma,base.lemma.normalize('NFC'));
  assert.equal(core.analysis.root,'');
  let calls=0;
  const result=await generateBreakdown(request,'synthetic',async()=>{calls++;return envelope(grammar);});
  assert.equal(calls,1);assert.equal(result.lemma,core.lemma);assert.equal(result.features[0].value,'construct');assert.deepEqual(result.parts,[]);assert.deepEqual(result.withheld,['root']);
});

test('מונשט is never silently substituted with מושט in core help or Breakdown',async()=>{
  const {generateBreakdown}=await import('../lib/breakdown.ts');
  const request={tokens:['מונשט'],context:'במשפט הבדיקה מופיע מונשט כפי שנבחר.'};
  const core={confident:true,tokens:[{original:'מושט',nikud:'מוּשָׁט'}],translation:'extended',hint:'דבר שמגישים קדימה',lemma:'מוּשָׁט',lemmaTranslation:'extended'};
  await assert.rejects(()=>generateAssistance(request,'synthetic',async()=>streamed([JSON.stringify(core)]),()=>{},undefined,runtime),{code:'selection_mismatch'});
  let calls=0;
  await assert.rejects(()=>generateBreakdown(request,'synthetic',async()=>{calls++;return envelope({selected:'מושט',confident:true,category:'verb'});}),e=>e.diagnostic.field==='selected');
  assert.equal(calls,1);
});
