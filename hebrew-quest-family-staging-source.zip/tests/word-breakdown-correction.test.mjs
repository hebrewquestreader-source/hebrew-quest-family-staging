import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {WordBreakdown} from '../lib/word-breakdown.js';import {HebrewText} from '../lib/hebrew-text.js';import {generateBreakdown} from '../lib/breakdown.ts';import {harness,settle} from './helpers/interactive-harness.mjs';
const feature=(name,value)=>({name,value,confident:true}),part=(text,meaning,kind='stem')=>({text,meaning,kind,confident:true});
// Constructed raw provider response, not a captured production completion.
const adopted=()=>({selected:'שאימץ',confident:true,category:'verb',lemma:'לְאַמֵּץ',lemmaMeaning:'to adopt',lemmaConfident:true,root:'א־מ־ץ',rootConfident:true,features:[feature('binyan','Piel'),feature('tense','past'),feature('person','third'),feature('gender','masculine'),feature('number','singular')],parts:[part('שֶׁ־','that','prefix'),part('אִמֵּץ','he adopted')]});
const input={tokens:['שאימץ'],context:'האיש שאימץ את הילד סיפר על משפחתו.'};
const envelope=value=>new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(value)}]}}]}));
const grammar=r=>Object.fromEntries(r.features.map(f=>[f.name,f.value]));
test('prefixed Piel accepts standard pointed spelling, final root letter and exact complete grammatical analysis',async()=>{
 let calls=0;const result=await generateBreakdown(input,'synthetic',async(url,options)=>{calls++;const body=JSON.parse(options.body);assert.equal(JSON.parse(body.contents[0].parts[0].text).context,input.context);assert.match(body.systemInstruction.parts[0].text,/Prefixes are not root letters/);return envelope(adopted());});
 assert.equal(calls,1);assert.equal(result.selected,'שאימץ');assert.equal(result.lemma,'לְאַמֵּץ'.normalize('NFC'));assert.equal(result.root,'אמץ');assert.equal(result.rootWithheld,false);assert.deepEqual(grammar(result),{binyan:'Piel',tense:'past',person:'third',gender:'masculine',number:'singular'});assert.equal(result.parts[0].kind,'prefix');assert.equal(result.parts[0].meaning,'that');assert.equal(result.parts[1].meaning,'he adopted');assert.deepEqual(WordBreakdown.checked(result,input),result);
});
test('the alignment is general, preserves affixes and does not accept missing consonants, altered words or Arabic contamination',()=>{
 for(const prefix of ['ש','ו','ב','ל','מ','ה']){const raw=adopted();raw.selected=prefix+'אימץ';raw.parts[0].text=prefix+'־';assert.equal(WordBreakdown.checked(raw,{...input,tokens:[raw.selected]}).lemma,'לְאַמֵּץ'.normalize('NFC'));}
 for(const text of ['אִמֵּ','אִבֵּץ','אِמֵּץ']){const raw=adopted();raw.parts[1].text=text;assert.throws(()=>WordBreakdown.checked(raw,input));}
 assert.equal(HebrewText.related('שאימץ','לְאַמֵּץ'),true);assert.equal(HebrewText.related('שאימץ','לְאַבֵּד'),false);
 const raw=adopted();raw.parts=[part('שאמץ','that he adopted')];assert.throws(()=>WordBreakdown.checked(raw,input),e=>e.field==='parts.text');
});
test('invalid optional fields are withheld independently and provider failures are not retried',async()=>{
 for(const [field,mutate]of [['root',r=>r.root='א־מ־ي'],['parts',r=>r.parts[1].text='אִמֵّץ'],['lemma',r=>r.lemmaMeaning={text:'adopt'}]]){
  const raw=adopted();mutate(raw);let calls=0;
  const result=await generateBreakdown(input,'synthetic',async()=>{calls++;return envelope(raw);});
  assert.equal(calls,1);assert.deepEqual(result.withheld,[field]);assert.equal(grammar(result).tense,'past');
 }
 let calls=0;await assert.rejects(()=>generateBreakdown(input,'synthetic',async()=>{calls++;return new Response('temporary',{status:503});}),{code:'breakdown_unavailable'});assert.equal(calls,1);
});
test('all reported cases assert semantic grammatical fields, not just response success',()=>{
 const cases=JSON.parse(fs.readFileSync(new URL('./fixtures/word-help-stability.json',import.meta.url),'utf8')).cases;
 for(const f of cases){const r=WordBreakdown.checked(f.breakdown,f.input),g=grammar(r);assert.equal(r.lemma,f.breakdown.lemma.normalize('NFC'));switch(f.input.tokens.join(' ')){
 case 'הודיעה':assert.equal(r.root,'ידע');assert.deepEqual(g,{binyan:'Hifil',tense:'past',person:'third',gender:'feminine',number:'singular'});break;
 case 'נכתב':assert.equal(r.root,'כתב');assert.deepEqual(g,{binyan:'Nifal',tense:'past',person:'third',gender:'masculine',number:'singular'});break;
 case 'בעיקר':assert.equal(r.category,'adverb');assert.equal(r.lemmaMeaning,'mainly');assert.deepEqual(g,{});assert.equal(r.root,'');break;
 case 'התפקידים,':assert.equal(r.category,'noun');assert.equal(g.number,'plural');assert.equal(r.parts[0].meaning,'the');assert.equal(r.selected,'התפקידים,');break;
 case 'משפחתו':assert.equal(g.possession,'his');assert.equal(g.state,'construct');assert.equal(r.lemmaMeaning,'family');break;
 case 'מהסדרה המקורית':assert.equal(r.category,'expression');assert.deepEqual(r.parts.map(p=>p.text),['מהסדרה','המקורית']);assert.equal(r.lemmaMeaning,'original series');assert.deepEqual(g,{});break;
 }}
});
test('root checks cover seven binyanim, weak initial nun, hollow roots, quadriliterals and final-letter patterns',()=>{
 const rows=[['כתב','לִכְתּוֹב','כ־ת־ב','Paal','כָּתַב'],['נכתב','לְהִכָּתֵב','כ־ת־ב','Nifal','נִכְתַּב'],['תרגם','לְתַרְגֵּם','ת־ר־ג־ם','Piel','תִּרְגֵּם'],['דובר','','ד־ב־ר','Pual','דֻּבַּר'],['הודיעה','לְהוֹדִיעַ','י־ד־ע','Hifil','הוֹדִיעָה'],['הוכתב','','כ־ת־ב','Hufal','הֻכְתַּב'],['התכתב','לְהִתְכַּתֵּב','כ־ת־ב','Hitpael','הִתְכַּתֵּב'],['נפל','לִפּוֹל','נ־פ־ל','Paal','נָפַל'],['קם','לָקוּם','ק־ו־ם','Paal','קָם']];
 for(const [selected,lemma,root,binyan,surface] of rows){const raw={...adopted(),selected,lemma,lemmaConfident:!!lemma,root,features:[feature('binyan',binyan)],parts:[part(surface,'verb form')]};const r=WordBreakdown.checked(raw,{tokens:[selected]});assert.equal(r.root,root.replaceAll('־',''),selected);assert.equal(grammar(r).binyan,binyan);assert.equal(r.lemma,lemma.normalize('NFC'));}
});
test('adjectives are supported; uncertain proposals do not fabricate grammar',()=>{
 const r=WordBreakdown.checked({...adopted(),selected:'הגדולים',category:'adjective',lemma:'גָּדוֹל',lemmaMeaning:'big',root:'',rootConfident:false,features:[feature('gender','masculine'),feature('number','plural')],parts:[part('הגדולים','the big ones','component')]},{tokens:['הגדולים']});assert.equal(r.category,'adjective');assert.equal(grammar(r).number,'plural');assert.equal(r.root,'');assert.equal(WordBreakdown.checked({...adopted(),confident:false},input).confident,false);
});
const calm=async()=>{for(let i=0;i<5;i++)await settle();};
for(const width of [360,1280])test(`requested translation precedes reusable form at ${width}px; English stays hidden on selection and save`,async()=>{
 const h=harness({fetcher:async(url,opts,fallback)=>url==='/api/assist'?Response.json({confident:true,tokens:[{original:'שאימץ',nikud:'שֶׁאִמֵּץ'}],lemma:'לְאַמֵּץ',lemmaConfident:true,lemmaTranslation:'to adopt',translation:'that he adopted',hint:'',pronunciation:''}):fallback(url,opts)});h.c.window.innerWidth=width;await calm();h.c.articleFixture={title:'סיפור',paragraphs:[input.context],url:'https://www.ynet.co.il/news/article/test'};h.run('loadArticleText(articleFixture.title,articleFixture.paragraphs,articleFixture.url)');await h.el('article').querySelectorAll('.word')[1].click();await calm();
 const order=h.el('selectedWord').parentNode.children;assert.ok([...order].indexOf(h.el('selectedWord'))<[...order].indexOf(h.el('contextTranslation')));assert.ok([...order].indexOf(h.el('contextTranslation'))<[...order].indexOf(h.el('lexical')));assert.ok([...order].indexOf(h.el('translation'))<[...order].indexOf(h.el('lexical')));assert.equal(h.el('lexical').hidden,false);assert.equal(h.el('contextTranslation').hidden,true);assert.equal(h.el('translation').hidden,true);assert.equal(h.el('lemmaTranslation').hidden,true);
 await h.el('saveVocabulary').click();assert.equal(h.el('contextTranslation').hidden,true);assert.equal(h.c.vocabularySnapshot().expression,'שאימץ');await h.el('translationBtn').click();await calm();const visible=['contextTranslation','translation'].map(id=>h.el(id)).filter(el=>!el.hidden);assert.equal(visible.length,1);assert.equal(visible[0].textContent,'that he adopted');assert.equal(h.el('lemmaTranslation').hidden,false);assert.equal(h.el('lemmaTranslation').textContent,'to adopt');assert.equal(h.body.querySelector('.side').classList.contains('desktop-panel'),width>=1024);
});
test('invalid cached analyses are re-fetched, failed calls are not cached, and concurrent requests share one validated result',async()=>{
 let calls=0;const storageMap=new Map([['hebrew-quest-word-breakdown-v4',JSON.stringify([[JSON.stringify(input),{...adopted(),root:'ا'}]])]]);
 const h=harness({storageMap,fetcher:async(url,opts,fallback)=>{if(url==='/api/breakdown'){calls++;return calls===1?Response.json({error:'temporary',code:'breakdown_unavailable'},{status:503}):Response.json(adopted());}return fallback(url,opts);}});await calm();await assert.rejects(()=>h.c.WordBreakdownUI.get(input));h.c.AIAvailability.retry();const [one,two]=await Promise.all([h.c.WordBreakdownUI.get(input),h.c.WordBreakdownUI.get(input)]);assert.equal(calls,2);assert.equal(one.root,'אמץ');assert.equal(two.root,'אמץ');await h.c.WordBreakdownUI.get(input);assert.equal(calls,2);
});
test('phrase components preserve order and boundaries and cannot use punctuation to hide a changed word',()=>{
 const raw={...adopted(),selected:'מהסדרה המקורית',category:'expression',lemma:'סִדְרָה מְקוֹרִית',lemmaMeaning:'original series',root:'',rootConfident:false,features:[],parts:[part('מֵהַסִּדְרָה','from the series','component'),part('הַמְּקוֹרִית','the original','component')]};const request={tokens:raw.selected.split(' ')};assert.equal(WordBreakdown.checked(raw,request).selected,raw.selected);assert.throws(()=>WordBreakdown.checked({...raw,parts:raw.parts.toReversed()},request));assert.throws(()=>WordBreakdown.checked({...raw,parts:[part('מהסדרההמקורית','joined words')]},request));
});
