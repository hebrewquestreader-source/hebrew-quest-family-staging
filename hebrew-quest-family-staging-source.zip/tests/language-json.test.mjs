import test from 'node:test';import assert from 'node:assert/strict';
import {completeJsonFields} from '../lib/language-json.ts';
test('partial JSON exposes only complete top-level fields',()=>{
 assert.deepEqual(completeJsonFields('{"confident":true,"tokens":[{"original":"עם","nikud":"עִם"}]'),{confident:true,tokens:[{original:'עם',nikud:'עִם'}]});
 assert.deepEqual(completeJsonFields('{"tokens":[{"original":"broken'),{});
 assert.deepEqual(completeJsonFields('{"confident":tru'),{});
 assert.deepEqual(completeJsonFields('{"hint":"quoted \\\"confident\\\":true", "tokens":['),{hint:'quoted "confident":true'});
});
test('nested fake confidence does not authorize an early result',()=>{
 assert.equal(completeJsonFields('{"nested":{"confident":true},"tokens":[],').confident,undefined);
});
