import test from 'node:test';import assert from 'node:assert/strict';
import {extractArticle as before} from '../beta/benchmarks/importer-before.ts';
import {extractArticle as after} from '../lib/importer.ts';
const url='https://www.ynet.co.il/news/article/test';
const intro='משפט פתיחה לבדיקה השומר את כל הטקסט המקורי ואת סדר הפסקאות. '.repeat(5);
const page=body=>'<h1>כותרת &amp; מקור</h1><article><p>'+intro+'</p>'+body+'<p>סוף הכתבה.</p></article>';
for(const attribute of ['hidden','aria-hidden="true"','style="display:none"','style="display: none"','class="advert"','class="banner"','class="recommend"','class="related"','class="promo"','class="ad"','class="ads"','class="ad-container"','id="advert-1"','role="navigation"','role="complementary"','data-ad','data-ad-slot','class="before\tad\nafter"','class="before\u00a0ad\u00a0after"']){
 test('identical removal behavior: '+attribute,()=>{const html=page('<div '+attribute+'><p>תוכן בדיקה</p></div>');assert.deepEqual(after(html,url),before(html,url));});
}
for(const tag of ['script','style','nav','footer','header','aside','form','iframe','noscript','svg'])test('identical excluded element: '+tag,()=>{const html=page('<'+tag+'><p>לא לייבא</p></'+tag+'>');assert.deepEqual(after(html,url),before(html,url));});
test('preserves nested blocks, repeated paragraphs, title, entities and intentional line breaks',()=>{
 const html=page('<blockquote>לפני<p>ציטוט</p>אחרי</blockquote><ul><li>אחד<ul><li>שניים</li></ul>סיום</li></ul><div class="text_editor_paragraph">שורה<br>חדשה &amp; סוף</div><p>כן.</p><p>כן.</p>');assert.deepEqual(after(html,url),before(html,url));
});
test('all body candidates preserve longest-candidate selection and stable ties',()=>{
 const html='<h1>כותרת</h1><article><div id="articleBody"><p>'+intro+'</p></div><div itemprop="articleBody"><p>'+intro.repeat(2)+'</p></div></article>';assert.deepEqual(after(html,url),before(html,url));
});
test('subscription and oversize errors remain identical; no paywall or safety regression',()=>{
 for(const html of ['<script type="application/ld+json">{"isAccessibleForFree":false}</script>'+page(''),'<div data-premium="true"></div>'+page(''),page('<p>'+'א'.repeat(120001)+'</p>')]){
  let expected;try{before(html,url)}catch(error){expected=error.message;}assert.ok(expected);assert.throws(()=>after(html,url),error=>error.message===expected);
 }
});
test('attribute case and Unicode class whitespace preserve baseline cleanup semantics',()=>{
 for(const attr of ['ROLE="NAVIGATION"','aria-hidden="TRUE"','style="DISPLAY:NONE"','class="AD"',...['\t','\n','\f','\r',' ','\u00a0','\u2003'].flatMap(space=>['ad','text_editor_paragraph'].map(name=>'class="before'+space+name+space+'after"'))]){
  const html=page('<div '+attr+'><p>תוכן</p></div>');assert.deepEqual(after(html,url),before(html,url),attr);
 }
});
