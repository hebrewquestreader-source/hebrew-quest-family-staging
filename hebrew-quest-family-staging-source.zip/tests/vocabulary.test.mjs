import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {DatabaseSync} from 'node:sqlite';
import {validateVocabulary,vocabularyKey,saveVocabulary,listVocabulary,changeVocabulary} from '../lib/vocabulary.ts';
function adapter(sqlite){return {prepare(sql){const statement=sqlite.prepare(sql);return {bind(...args){return {first:async()=>statement.get(...args)||null,all:async()=>({results:statement.all(...args)}),run:async()=>statement.run(...args),execute:()=>statement.run(...args)}}}},async batch(statements){sqlite.exec('BEGIN');try{const results=statements.map(s=>s.execute());sqlite.exec('COMMIT');return results;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};}
const entry=(url='https://www.ynet.co.il/news/article/rkk005oepfl')=>({expression:'הבחירות',nikud:'הַבְּחִירוֹת',translation:'the elections',lemma:'בְּחִירוֹת',lemmaTranslation:'elections',status:'needs_review',createdAt:'2026-10-29T12:00:00Z',updatedAt:'2026-10-29T12:00:00Z',examples:[{expression:'הבחירות',nikud:'הַבְּחִירוֹת',translation:'the elections',sentence:'ועדת הבחירות השלימה את ספירת הקולות.',title:'Ynet article',url,savedAt:'2026-10-29T12:00:00Z'}]});
function initialize(db){for(const f of fs.readdirSync(new URL('../drizzle/',import.meta.url)).filter(f=>f.endsWith('.sql')).sort())db.exec(fs.readFileSync(new URL('../drizzle/'+f,import.meta.url),'utf8'));}
test('account vocabulary survives database reopen; duplicates retain multiple article examples and review state',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hebrew-vocab-')),file=path.join(dir,'bank.sqlite');let sqlite=new DatabaseSync(file);initialize(sqlite);let db=adapter(sqlite);
 const first=await saveVocabulary(db,'owner',validateVocabulary(entry()));await saveVocabulary(db,'owner',validateVocabulary(entry()));
 await changeVocabulary(db,'owner',first.id,'recognised');const other=entry('https://www.calcalist.co.il/article/example');other.examples[0].title='Second article';other.examples[0].sentence='תוצאות הבחירות פורסמו היום.';other.examples[0].translation='the election';await saveVocabulary(db,'owner',validateVocabulary(other));
 sqlite.close();sqlite=new DatabaseSync(file);db=adapter(sqlite);const reopened=await listVocabulary(db,'owner');assert.equal(reopened.length,1);assert.equal(reopened[0].examples.length,2);assert.equal(reopened[0].status,'recognised');assert.equal(reopened[0].lemma,'בְּחִירוֹת'.normalize('NFC'));assert.equal(reopened[0].examples.find(e=>e.title==='Second article').translation,'the election');
 assert.equal((await listVocabulary(db,'other-account')).length,0);await changeVocabulary(db,'other-account',first.id);assert.equal((await listVocabulary(db,'owner')).length,1);
 const backup=JSON.parse(JSON.stringify(reopened[0]));await changeVocabulary(db,'owner',first.id);assert.equal((await listVocabulary(db,'owner')).length,0);await saveVocabulary(db,'owner',validateVocabulary(backup));assert.equal((await listVocabulary(db,'owner'))[0].examples.length,2);
 sqlite.close();fs.rmSync(dir,{recursive:true,force:true});
});
test('normalisation merges pointed/punctuated spelling without merging different article forms',()=>{assert.equal(vocabularyKey('הַבְּחִירוֹת,'),vocabularyKey('הבחירות'));assert.notEqual(vocabularyKey('ולמרות'),vocabularyKey('למרות'));});
test('backup validation rejects executable URLs, wrong sentence, oversized records and invalid status',()=>{
 for(const modify of [e=>e.examples[0].url='javascript:alert(1)',e=>e.examples[0].sentence='משפט אחר.',e=>e.expression='x'.repeat(601),e=>e.status='unknown']){const e=entry();modify(e);assert.throws(()=>validateVocabulary(e));}
});

test('additive schema upgrade preserves previously saved vocabulary and only withholds corrupt display fields',async()=>{
 const sqlite=new DatabaseSync(':memory:');sqlite.exec(fs.readFileSync(new URL('../drizzle/0001_kind_ted_forrester.sql',import.meta.url),'utf8'));
 sqlite.prepare('INSERT INTO vocabulary_entries VALUES (?,?,?,?,?,?,?,?,?,?)').run('old-id','owner','גילום','גִּלּוּם','portrayal','','','needs_review','2026-10-30T04:09:31.267Z','2026-10-30T04:09:32.845Z');
 sqlite.exec(fs.readFileSync(new URL('../drizzle/0002_moaning_leopardon.sql',import.meta.url),'utf8'));sqlite.exec(fs.readFileSync(new URL('../drizzle/0004_far_major_mapleleaf.sql',import.meta.url),'utf8'));const result=await listVocabulary(adapter(sqlite),'owner');assert.equal(result.length,1);assert.equal(result[0].id,'old-id');assert.equal(result[0].expression,'גילום');assert.equal(result[0].translation,'portrayal');assert.equal(result[0].incomplete,false);assert.equal(sqlite.prepare('SELECT nikud FROM vocabulary_entries').get().nikud,'גִּלּוּם');sqlite.close();
});
