import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {HebrewText} from '../lib/hebrew-text.js';import {validateAssistance,generateAssistance,validateNikud} from '../lib/language.ts';import {validateVocabulary} from '../lib/vocabulary.ts';
const role={confident:true,tokens:[{original:'תפקיד',nikud:'תַּפְקִיד'}],hint:'עבודה או משרה',translation:'role',lemma:'תַּפְקִיד',lemmaTranslation:'role',pronunciation:'tafkid'};
const input={tokens:['תפקיד'],context:'זהו תפקיד חשוב.'};
test('Arabic kasra in an optional lemma is rejected whole while checked main help is retained',async()=>{
 const raw={...role,lemma:'תַּפְקِיד'};assert.equal(raw.lemma.normalize('NFC').includes('\u0650'),true);
 assert.throws(()=>HebrewText.validate(raw.lemma),/U\+0650/);const checked=validateAssistance(raw,input);assert.equal(checked.lemma,'');assert.ok(checked.withheldFields.includes('lemma'));assert.equal(checked.tokens[0].nikud,'תַּפְקִיד'.normalize('NFC'));
 const result=await generateAssistance(input,'synthetic',async()=>new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(raw)}]}}]})));assert.equal(result.lemma,'');assert.equal(result.translation,'role');assert.ok(result.withheldFields.includes('lemma'));
});
test('Hebrew marks attach to Hebrew bases, preserve quotes, and foreign names must be copied exactly',()=>{
 for(const word of ['תַּפְקִיד','תַּפְקִידֵיהֶם','ז׳אן־לוק','צה״ל'])assert.equal(HebrewText.validate(word),word.normalize('NFC'));
 for(const bad of ['תפק\u0650יד','תפقיד','\u05b4תפקיד','תפקיד.\u05b4','תפקידA\u05b4','ת\u05b4\u05b7פקיד','ת\u05c1פקיד','ש\u05c1\u05c2'])assert.throws(()=>HebrewText.validate(bad));
 const original="ז'אן-לוק Jean-Luc Picard François أحمد مُحَمَّد Nguyễn";assert.equal(HebrewText.validate(original,{source:original,mixed:true}),original.normalize('NFC'));
 assert.throws(()=>validateNikud([{original:'תפקיד',nikud:'תַּפְקִיר'}],input));
 assert.equal(HebrewText.validNikud('תפקיד','תַּפְקِיד'),false);assert.throws(()=>HebrewText.validate('תפقיד',{source:'תפقיד',mixed:true}));
});
test('four requested readings and contextual meanings pass the provider response boundary with selected and dictionary forms separate',()=>{
 const cases=[
  {tokens:['תפקיד'],context:'זהו תפקיד חשוב.',nikud:['תַּפְקִיד'],translation:'role',lemma:'תַּפְקִיד'},
  {tokens:['תפקידיהם'],context:"תפקידיהם של קפטן ז'אן-לוק וחבריו היו מרכזיים.",nikud:['תַּפְקִידֵיהֶם'],translation:'their roles',lemma:'תַּפְקִיד'},
  {tokens:['הלך','לעולמו'],context:'השחקן הלך לעולמו אתמול.',nikud:['הָלַךְ','לְעוֹלָמוֹ'],translation:'passed away',lemma:'הָלַךְ לְעוֹלָמוֹ'},
  {tokens:['גילום'],context:'הוא זכה בפרס על גילום הדמות.',nikud:['גִּלּוּם'],translation:'portrayal / acting a role',lemma:'גִּלּוּם'},
 ];
 for(const c of cases){const out=validateAssistance({...role,tokens:c.tokens.map((original,i)=>({original,nikud:c.nikud[i]})),translation:c.translation,lemma:c.lemma},c);assert.equal(out.translation,c.translation);assert.equal(out.lemma,c.lemma.normalize('NFC'));assert.deepEqual(out.tokens.map(t=>t.original),c.tokens);}
 assert.equal(HebrewText.related('תפקידיהם','פָּקִיד'),false);
 const unrelated=validateAssistance({...role,lemma:'תַּפּוּחַ'},input);assert.equal(unrelated.lemma,'');assert.equal(unrelated.lemmaWithheld,true);
});
test('shared browser validator exactly matches its generated source',()=>{assert.equal(fs.readFileSync(new URL('../public/hebrew-text-client.js',import.meta.url),'utf8'),fs.readFileSync(new URL('../lib/hebrew-text.js',import.meta.url),'utf8').replace('export const HebrewText','const HebrewText'));});
test('bank rejects corrupt new help and safely withholds old corrupt fields without mutating the saved record',()=>{
 const e={expression:'תפקיד',nikud:'תַּפְקִיד',translation:'role',lemma:'תַּפְקِיד',lemmaTranslation:'role',status:'needs_review',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),examples:[{expression:'תפקיד',nikud:'תַּפְקִיד',translation:'role',sentence:'זהו תפקיד חשוב.',title:'Article',url:'https://www.ynet.co.il/',savedAt:new Date().toISOString()}]};
 assert.throws(()=>validateVocabulary(e));const shown=HebrewText.vocabulary(e);assert.equal(shown.lemma,'');assert.equal(shown.incomplete,true);assert.equal(e.lemma,'תַּפְקِיד');assert.equal(shown.expression,'תפקיד');assert.equal(shown.quarantined.lemma,e.lemma);
});
