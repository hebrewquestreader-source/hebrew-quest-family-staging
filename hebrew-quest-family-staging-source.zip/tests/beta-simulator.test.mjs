import test from 'node:test';
import assert from 'node:assert/strict';
import {mockGemini} from '../lib/beta-mock.ts';
import {generateAssistance} from '../lib/language.ts';
import {generateBreakdown} from '../lib/breakdown.ts';
for(const word of ['נשענים','ליחידות'])for(const operation of [generateAssistance,generateBreakdown]){
 test(operation.name+' missing simulator selection '+word,async()=>{
  let calls=0;
  const fetcher=async(...args)=>{calls++;return mockGemini(...args);};
  await assert.rejects(()=>operation({tokens:[word],context:'משפט בדיקה.'},'synthetic',fetcher),error=>{
   assert.equal(error.code,'simulator_missing');
   assert.match(error.message,/simulated help/);
   assert.doesNotMatch(error.message,/key|rejected/i);
   return true;
  });
  assert.equal(calls,1);
 });
}

import {harness,settle} from './helpers/interactive-harness.mjs';
const calm=async()=>{for(let i=0;i<6;i++)await settle();};
test('missing simulator output shows staging message without settings or retry, including Breakdown',async()=>{
 const message='This staging test has no simulated help for this selection. Live language assistance is disabled.';
 const h=harness({fetcher:async(url,options,fallback)=>['/api/assist','/api/breakdown'].includes(url)?Response.json({code:'simulator_missing',error:message},{status:422}):fallback(url,options)});
 await calm();h.run('loadArticleText("בדיקה",["נשענים על הקיר."],"")');
 await h.el('article').querySelector('.word').click();await calm();
 assert.equal(h.el('assistStatus').textContent,message);assert.equal(h.el('assistRetry').hidden,true);assert.equal(h.el('assistSettings').hidden,true);
 h.run('settings.wordBreakdown=true;WordBreakdownUI.updateSetting()');await h.el('wordBreakdownButton').click();await calm();
 assert.equal(h.el('wordBreakdownStatus').textContent,message);assert.equal(h.el('wordBreakdownRetry').hidden,true);
 assert.equal(h.requests.filter(r=>r.url==='/api/assist').length,1);assert.equal(h.requests.filter(r=>r.url==='/api/breakdown').length,1);
});
