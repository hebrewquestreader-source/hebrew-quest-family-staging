// Browser-only regression. Run in a signed-in Site browser console by importing
// this file in the browser test runner. Not a simulated-layout assertion.
export async function measureWordHelpStability(document,window){
 if(window.innerWidth<1024)throw Error('Use a desktop viewport of at least 1024px.');
 const article=document.querySelector('.reading'),text=document.getElementById('article'),close=document.getElementById('closePanel'),word=text.querySelector('.word');if(!word)throw Error('Import an article first.');
 const frame=()=>new Promise(resolve=>window.requestAnimationFrame(()=>window.requestAnimationFrame(resolve)));
 if(document.querySelector('.side').classList.contains('open')){close.click();await frame();}
 const snapshot=()=>{const rect=article.getBoundingClientRect(),lines=[...text.querySelectorAll('.word')].map(node=>{const r=node.getBoundingClientRect();return {id:node.dataset.id,left:r.left,top:r.top,width:r.width};});return {left:rect.left,width:rect.width,scrollX:window.scrollX,scrollY:window.scrollY,lines};};
 const before=snapshot();word.click();await frame();const open=snapshot();close.click();await frame();const after=snapshot();
 const failures=[];for(const [phase,state]of [['open',open],['closed',after]]){for(const k of ['left','width','scrollX','scrollY'])if(Math.abs(before[k]-state[k])>.5)failures.push(`${phase}: ${k} changed from ${before[k]} to ${state[k]}`);for(let i=0;i<before.lines.length;i++){const a=before.lines[i],b=state.lines[i];if(!b||a.id!==b.id||Math.abs(a.top-b.top)>.5)failures.push(`${phase}: line wrapping/position changed at ${a.id}`);}}
 if(failures.length)throw Error(failures.join('\n'));return {passed:true,before,open,after};
}
