import test from 'node:test';
import assert from 'node:assert/strict';
import {validateSelection,validateAssistance,generateAssistance,LANGUAGE_MODEL,normalizeApiKey} from '../lib/language.ts';
import {encryptKey,decryptKey} from '../lib/language-crypto.ts';
import {boundedJson} from '../lib/language-http.ts';

const input={tokens:['משתקפת,'],context:'התוצאה משתקפת, כפי שאפשר לראות בטבלה.'};
const result={tokens:[{original:'משתקפת,',nikud:'מִשְׁתַּקֶּפֶת,'}],hint:'אפשר לראות אותה דרך משהו אחר',translation:'is reflected',lemma:'לְהִשְׁתַּקֵּף',lemmaTranslation:'to be reflected',pronunciation:'mish-ta-KE-fet',confident:true};
const response=r=>new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(r)}]}}]}));

test('requires Hebrew, bounded context containing the exact selected text',()=>{
 assert.deepEqual(validateSelection(input),input);
 for(const invalid of [{...input,context:'different'}, {...input,tokens:Array(21).fill('שלום')}, {...input,context:'א'.repeat(16001)},{tokens:['abc'],context:'abc'}])assert.throws(()=>validateSelection(invalid));
});
test('nikud may add marks but cannot change letters or punctuation',()=>{
 assert.deepEqual(validateAssistance(result,input),result);
 assert.equal(validateAssistance({...result,tokens:[{original:'משתקפת,',nikud:'מִשְׁתַּקֶּפֶת'}]},input).tokens[0].nikud,'מִשְׁתַּקֶּפֶת,'.normalize('NFC'));
 for(const bad of ['מִשְׁתַּקֶּפֶת.','משתקפות,','מִשְׁתַּקֶּפֶת, <img>'])assert.throws(()=>validateAssistance({...result,tokens:[{original:'משתקפת,',nikud:bad}]},input));
 assert.throws(()=>validateAssistance({...result,confident:false},input));
 assert.throws(()=>validateAssistance({...result,tokens:[{original:'משתקפת,',nikud:'משתקפת,'}]},input));
});
test('multi-word assistance preserves exact token order',()=>{
 const phrase={tokens:['עם','זאת,'],context:'עם זאת, אפשר להמשיך.'};
 const r={...result,tokens:[{original:'עם',nikud:'עִם'},{original:'זאת,',nikud:'זֹאת,'}],translation:'nevertheless'};
 assert.equal(validateAssistance(r,phrase).translation,'nevertheless');
 assert.throws(()=>validateAssistance({...r,tokens:r.tokens.toReversed()},phrase));
});
test('sends only selected text/context to fixed provider, with key in a header',async()=>{
 let calls=0;
 const r=await generateAssistance(input,'test-key',async(url,opts)=>{
  calls++;assert.equal(url,`https://generativelanguage.googleapis.com/v1beta/models/${LANGUAGE_MODEL}:generateContent`);
  assert.equal(opts.headers['x-goog-api-key'],'test-key');
  const body=JSON.parse(opts.body);assert.deepEqual(JSON.parse(body.contents[0].parts[0].text),input);
  assert.equal(body.tools,undefined);assert.equal(body.generationConfig.responseMimeType,'application/json');assert.deepEqual(body.generationConfig.responseSchema.propertyOrdering.slice(0,2),['confident','tokens']);
  return response(result);
 });assert.equal(calls,1);assert.deepEqual(r,result);
});
test('quota/access failures do not retry; transient provider failures retry at most once without fallback or secrets',async()=>{
 for(const status of [429,403,404,500]){
  let calls=0;await assert.rejects(()=>generateAssistance(input,'secret',async()=>{calls++;return new Response('secret upstream detail',{status});}),e=>!e.message.includes('secret'));
  assert.equal(calls,status===500?2:1);
 }
});
test('blocks changed model text and malformed/incomplete output',async()=>{
 await assert.rejects(()=>generateAssistance(input,'key',async()=>response({...result,tokens:[{original:'משתקפת,',nikud:'שונה'}]})));
 await assert.rejects(()=>generateAssistance(input,'key',async()=>new Response('not-json')));
 await assert.rejects(()=>generateAssistance(input,'key',async()=>new Response(JSON.stringify({candidates:[{finishReason:'MAX_TOKENS'}]}))));
});
test('API keys encrypted at rest with random IV and authenticated ciphertext',async()=>{
 const secret='ab'.repeat(32),key='AIza-test-key-not-real';
 const a=await encryptKey(key,secret),b=await encryptKey(key,secret);assert.notEqual(a,b);assert.ok(!a.includes(key));assert.equal(await decryptKey(a,secret),key);
 await assert.rejects(()=>decryptKey(a,'cd'.repeat(32)));
});
test('request size limit applies even without Content-Length',async()=>{
 const request=new Request('https://reader.example/api/assist',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:'a'.repeat(20000)})});
 await assert.rejects(()=>boundedJson(request,1000));
});

// Deliberately synthetic key strings: never use real credentials in fixtures.
test('accepts both Google key formats and defers authentication to Google',()=>{
 const old='AIza'+'x'.repeat(35),modern='AQ.'+'x'.repeat(60);
 assert.equal(normalizeApiKey(old),old);assert.equal(normalizeApiKey('  '+modern+'  '),modern);
 for(const bad of ['', 'truncated', 'AQ.'+'x'.repeat(10)+'\r\nInjected: bad', 'AQ.'+'x'.repeat(12)+' embedded space', 'x'.repeat(1025), null])assert.throws(()=>normalizeApiKey(bad));
});

test('streams validated nikud before meanings finish, using only one provider call',async()=>{
 let streamController,calls=0,releaseNikud;const ready=new Promise(r=>releaseNikud=r);
 const encoder=new TextEncoder();
 const upstream=new ReadableStream({start(c){streamController=c;}});
 const emit=(text,finishReason)=>streamController.enqueue(encoder.encode('data: '+JSON.stringify({candidates:[{...(finishReason?{finishReason}:{}),content:{parts:[{text}]}}]})+'\n\n'));
 const promise=generateAssistance(input,'key',async(url,options)=>{calls++;assert.match(url,/streamGenerateContent\?alt=sse$/);assert.equal(JSON.parse(options.body).generationConfig.thinkingConfig.thinkingLevel,'minimal');return new Response(upstream);},tokens=>releaseNikud(tokens));
 emit('{"confident":true,"tokens":'+JSON.stringify(result.tokens)+',');
 assert.deepEqual(await ready,result.tokens);
 const details=Object.fromEntries(Object.entries(result).filter(([k])=>!['tokens','confident'].includes(k)));
 emit(JSON.stringify(details).slice(1),'STOP');streamController.close();
 assert.deepEqual(await promise,result);assert.equal(calls,1);
});
