declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BETA_STAGING_ORIGIN?: string;
    LANGUAGE_WRAPPING_KEY?: string;
    LANGUAGE_OWNER_EMAIL?: string;
    BUCKET?: R2Bucket;
  }
}
